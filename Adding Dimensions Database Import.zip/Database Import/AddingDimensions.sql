--
-- PostgreSQL database dump
--

\restrict aqGS4kXTRgu6izbZdatioKkpqj4YxMEV4jjEVsD54tbXRxXcOtFj6aBLIC60Cwl

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: portal_audience_metrics(bigint, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.portal_audience_metrics(p_batch_id bigint, p_audience text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
WITH participants AS (
    SELECT e.enrollment_id,e.approval_status,
        EXISTS(SELECT 1 FROM public.attendance a WHERE a.enrollment_id=e.enrollment_id AND NOT a.portal_deleted AND a.status='PRESENT') AS attended,
        EXISTS(SELECT 1 FROM public.completion_review c WHERE c.enrollment_id=e.enrollment_id AND c.is_eligible) AS completed,
        EXISTS(SELECT 1 FROM public.certificate_record c WHERE c.enrollment_id=e.enrollment_id AND NOT c.portal_deleted
            AND COALESCE(c.ui_data->>'status','Issued') NOT IN ('Revoked','Superseded')) AS certified
    FROM public.batch_enrollment e JOIN public.trainee t ON t.trainee_id=e.trainee_id
    WHERE e.batch_id=p_batch_id AND NOT e.portal_deleted AND e.approval_status NOT IN ('REJECTED','WITHDRAWN')
        AND lower(COALESCE(t.ui_data->>'category','Teacher'))=lower(p_audience)
), totals AS (
    SELECT count(*) registered,count(*) FILTER(WHERE approval_status='APPROVED') approved,
        count(*) FILTER(WHERE attended) attended,count(*) FILTER(WHERE completed) completed,count(*) FILTER(WHERE certified) certified
    FROM participants
), marks AS (
    SELECT count(*) marked,count(*) FILTER(WHERE a.status='PRESENT') present
    FROM public.attendance a JOIN participants p ON p.enrollment_id=a.enrollment_id WHERE NOT a.portal_deleted
)
SELECT jsonb_build_object('planned',CASE WHEN COALESCE(p.ui_data->'beneficiaries','["Teacher"]') ? p_audience THEN b.capacity ELSE 0 END,
    'registered',x.registered,'approved',x.approved,'attended',x.attended,'completed',x.completed,'certified',x.certified,
    'attendanceMarked',m.marked,'attendancePresent',m.present,
    'attendanceRate',COALESCE(100.0*m.present/NULLIF(m.marked,0),0),
    'completionRate',COALESCE(100.0*x.completed/NULLIF(x.registered,0),0))
FROM totals x CROSS JOIN marks m CROSS JOIN public.training_batch b JOIN public.training_plan p ON p.plan_id=b.plan_id WHERE b.batch_id=p_batch_id;
$$;


--
-- Name: portal_project_access(bigint, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.portal_project_access(p_user_id bigint, p_project_id integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.app_user u JOIN public.m_role r ON r.role_id=u.role_id
        WHERE u.user_id=p_user_id AND u.is_active AND r.is_active
        AND (r.data_scope='ALL' OR EXISTS (
            SELECT 1 FROM public.user_access_scope s
            WHERE s.user_id=u.user_id AND s.is_active
            AND (s.project_id IS NULL OR s.project_id=p_project_id)
            AND (s.valid_from IS NULL OR s.valid_from<=CURRENT_DATE)
            AND (s.valid_to IS NULL OR s.valid_to>=CURRENT_DATE)
        ))
        AND (u.stakeholder_id IS NULL OR p_project_id IS NULL OR EXISTS (
            SELECT 1 FROM public.project p WHERE p.project_id=p_project_id AND p.stakeholder_id=u.stakeholder_id
        ))
    );
$$;


--
-- Name: portal_row_access(bigint, integer, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.portal_row_access(p_user_id bigint, p_project_id integer, p_owner_id bigint, p_batch_id bigint) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE current_user_record public.app_user; actor_role_code text;
BEGIN
    SELECT * INTO current_user_record FROM public.app_user WHERE user_id=p_user_id AND is_active;
    IF NOT FOUND THEN RETURN false; END IF;
    SELECT role_code INTO actor_role_code FROM public.m_role WHERE role_id=current_user_record.role_id AND is_active;
    IF actor_role_code='schoolnet-super-admin' THEN RETURN true; END IF;
    IF actor_role_code='trainee' THEN
        RETURN (p_owner_id IS NULL AND p_batch_id IS NULL AND p_project_id IS NULL) OR p_owner_id=p_user_id OR (p_batch_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.batch_enrollment e WHERE e.batch_id=p_batch_id
            AND e.trainee_id=current_user_record.trainee_id AND NOT e.portal_deleted
        )) OR (p_batch_id IS NULL AND p_project_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.batch_enrollment e JOIN public.training_batch b ON b.batch_id=e.batch_id
            WHERE e.trainee_id=current_user_record.trainee_id AND b.project_id=p_project_id AND NOT e.portal_deleted
        ));
    END IF;
    IF actor_role_code='trainer' AND p_batch_id IS NOT NULL THEN
        RETURN EXISTS (SELECT 1 FROM public.training_batch b WHERE b.batch_id=p_batch_id
            AND b.trainer_id=current_user_record.trainer_id AND NOT b.portal_deleted);
    END IF;
    IF p_project_id IS NULL THEN RETURN true; END IF;
    IF NOT public.portal_project_access(p_user_id,p_project_id) THEN RETURN false; END IF;
    IF p_batch_id IS NULL THEN RETURN true; END IF;
    RETURN EXISTS (
        SELECT 1 FROM public.training_batch b JOIN public.m_school school ON school.school_id=b.school_id
        JOIN public.user_access_scope s ON s.user_id=p_user_id AND s.is_active
        WHERE b.batch_id=p_batch_id AND (s.project_id IS NULL OR s.project_id=b.project_id)
        AND (s.valid_from IS NULL OR s.valid_from<=CURRENT_DATE) AND (s.valid_to IS NULL OR s.valid_to>=CURRENT_DATE)
        AND (s.state_id IS NULL OR s.state_id=school.state_id)
        AND (s.district_id IS NULL OR s.district_id=school.district_id)
        AND (s.block_id IS NULL OR s.block_id=school.block_id)
        AND (s.cluster_id IS NULL OR s.cluster_id=school.cluster_id)
        AND (s.school_id IS NULL OR s.school_id=school.school_id)
    );
END;
$$;


--
-- Name: trg_set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: trg_validate_assessment_attempt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_validate_assessment_attempt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE form_data jsonb; question jsonb; given_answer text; total numeric:=0; maximum numeric:=0; limit_count integer; start_record public.assessment_start;
BEGIN
    PERFORM 1 FROM public.batch_enrollment WHERE enrollment_id=NEW.enrollment_id FOR UPDATE;
    IF NOT EXISTS(SELECT 1 FROM public.batch_enrollment e JOIN public.app_user u ON u.trainee_id=e.trainee_id
        WHERE e.enrollment_id=NEW.enrollment_id AND u.user_id=NEW.portal_owner_user_id
        AND e.approval_status='APPROVED' AND NOT e.portal_deleted) THEN
        RAISE EXCEPTION 'Only the approved trainee may submit this attempt.' USING ERRCODE='42501';
    END IF;
    SELECT ui_data INTO form_data FROM public.learning_resource WHERE resource_id=NEW.resource_id AND NOT portal_deleted;
    limit_count:=COALESCE((form_data->>'attemptLimit')::integer,1);
    IF (SELECT count(*) FROM public.assessment_attempt WHERE enrollment_id=NEW.enrollment_id AND resource_id=NEW.resource_id)>=limit_count THEN
        RAISE EXCEPTION 'The attempt limit has been reached.' USING ERRCODE='22023';
    END IF;
    IF COALESCE((form_data->>'timeLimit')::integer,0)>0 THEN
        SELECT * INTO start_record FROM public.assessment_start
        WHERE start_id=(NEW.ui_data->>'attemptToken')::uuid AND enrollment_id=NEW.enrollment_id
        AND resource_id=NEW.resource_id AND user_id=NEW.portal_owner_user_id FOR UPDATE;
        IF NOT FOUND OR start_record.consumed_at IS NOT NULL OR start_record.expires_at<now() THEN
            RAISE EXCEPTION 'The attempt time limit has expired or this attempt was not started.' USING ERRCODE='22023';
        END IF;
        UPDATE public.assessment_start SET consumed_at=now() WHERE start_id=start_record.start_id;
    END IF;
    FOR question IN SELECT value FROM jsonb_array_elements(COALESCE(form_data->'questions','[]')) LOOP
        given_answer:=NEW.answers->>(question->>'id');
        IF COALESCE((form_data->>'allowUnanswered')::boolean,false)=false AND COALESCE(trim(given_answer),'')='' THEN
            RAISE EXCEPTION 'Answer all required questions.' USING ERRCODE='22023';
        END IF;
        maximum:=maximum+COALESCE((question->>'points')::numeric,1);
        IF given_answer=question->>'correctIndex' THEN total:=total+COALESCE((question->>'points')::numeric,1); END IF;
    END LOOP;
    IF NEW.kind='assessment' AND form_data->>'grading'='graded' THEN
        NEW.score:=total;NEW.max_marks:=maximum;NEW.passed:=total>=COALESCE((form_data->>'passMarks')::numeric,0);
        NEW.ui_data:=NEW.ui_data||jsonb_build_object('score',NEW.score,'maxMarks',NEW.max_marks,'passed',NEW.passed);
    ELSE
        NEW.score:=NULL;NEW.max_marks:=NULL;NEW.passed:=NULL;
        NEW.ui_data:=NEW.ui_data||jsonb_build_object('score',NULL,'maxMarks',NULL,'passed',NULL);
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: usp_check_database_health(jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_check_database_health(INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM 1 FROM public.teachers LIMIT 1;
    PERFORM 1 FROM public.teacher_auth_tokens LIMIT 1;
    p_result := jsonb_build_array(jsonb_build_object('is_healthy', true));
END;
$$;


--
-- Name: usp_delete_teacher(integer, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_delete_teacher(IN p_teacher_id integer, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE
    affected_count integer;
BEGIN
    DELETE FROM public.teachers WHERE id = p_teacher_id;
    GET DIAGNOSTICS affected_count = ROW_COUNT;
    p_result := jsonb_build_array(jsonb_build_object('affected_count', affected_count));
END;
$$;


--
-- Name: usp_get_login_user(character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_get_login_user(IN p_email character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    SELECT COALESCE(jsonb_agg(to_jsonb(result)), '[]'::jsonb) INTO p_result
    FROM
    (
        SELECT id, first_name, last_name, email, subject, phone_number,
               role, is_active, created_at, password_hash
        FROM public.teachers WHERE lower(email) = lower(trim(p_email))
    ) result;
END;
$$;


--
-- Name: usp_get_teacher_by_id(integer, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_get_teacher_by_id(IN p_teacher_id integer, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    SELECT COALESCE(jsonb_agg(to_jsonb(result)), '[]'::jsonb) INTO p_result
    FROM
    (
        SELECT id, first_name, last_name, email, subject, phone_number, role, is_active, created_at
        FROM public.teachers WHERE id = p_teacher_id
    ) result;
END;
$$;


--
-- Name: usp_get_teachers_list(integer, integer, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_get_teachers_list(IN p_page_number integer, IN p_page_size integer, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF p_page_number < 1 OR p_page_size < 1 OR p_page_size > 100 THEN
        RAISE EXCEPTION 'Invalid pagination.' USING ERRCODE = '22023';
    END IF;
    SELECT COALESCE(jsonb_agg(to_jsonb(result) ORDER BY result.id), '[]'::jsonb) INTO p_result
    FROM
    (
        SELECT id, first_name, last_name, email, subject, phone_number,
               role, is_active, created_at, count(*) OVER () AS total_count
        FROM public.teachers ORDER BY id
        LIMIT p_page_size OFFSET ((p_page_number::bigint - 1) * p_page_size)
    ) result;
END;
$$;


--
-- Name: usp_get_user_auth_token(integer, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_get_user_auth_token(IN p_teacher_id integer, IN p_token_id character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    p_result := jsonb_build_array(jsonb_build_object('is_active', EXISTS
    (
        SELECT 1 FROM public.teacher_auth_tokens a
        INNER JOIN public.teachers t ON t.id = a.teacher_id
        WHERE a.teacher_id = p_teacher_id AND a.token_id = p_token_id
          AND a.expires_at > now() AND t.is_active
    )));
END;
$$;


--
-- Name: usp_portal_apply(bigint, character varying, jsonb, jsonb, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_apply(IN p_user_id bigint, IN p_collection character varying, IN p_rows jsonb, IN p_deletes jsonb, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $_$
DECLARE config public.portal_collection; actor_role_code text; row_input jsonb; row_values jsonb;
    old_row jsonb; returned_id bigint; col_names text; col_values text; update_values text;
    ext_id text; old_version bigint; delete_input jsonb; project_id integer; owner_id bigint; batch_id bigint;
BEGIN
    SELECT * INTO config FROM public.portal_collection WHERE collection_key=p_collection;
    SELECT r.role_code INTO actor_role_code FROM public.app_user u JOIN public.m_role r ON r.role_id=u.role_id
    WHERE u.user_id=p_user_id AND u.is_active AND r.is_active;
    IF config.collection_key IS NULL OR actor_role_code IS NULL OR NOT(actor_role_code=ANY(config.write_roles)) THEN
        RAISE EXCEPTION 'You do not have permission to change these records.' USING ERRCODE='42501';
    END IF;
    IF jsonb_typeof(p_rows)<>'array' OR jsonb_array_length(p_rows)>2000 THEN
        RAISE EXCEPTION 'Invalid change set.' USING ERRCODE='22023';
    END IF;
    FOR row_input IN SELECT value FROM jsonb_array_elements(p_rows) LOOP
        ext_id:=row_input->>'id';
        IF ext_id IS NULL OR length(ext_id)>100 THEN RAISE EXCEPTION 'Invalid record identifier.' USING ERRCODE='22023'; END IF;
        EXECUTE format('SELECT to_jsonb(t) FROM public.%I t WHERE external_id=$1 FOR UPDATE',config.table_name)
        INTO old_row USING ext_id;
        project_id:=(row_input->>'projectId')::integer;
        owner_id:=(row_input->>'ownerId')::bigint;
        batch_id:=(row_input->>'batchId')::bigint;
        IF old_row IS NOT NULL AND (old_row->>'portal_collection') IS DISTINCT FROM p_collection THEN
            RAISE EXCEPTION 'Record belongs to another collection.' USING ERRCODE='22023';
        END IF;
        IF NOT public.portal_row_access(p_user_id,project_id,owner_id,batch_id) OR
            (old_row IS NOT NULL AND NOT public.portal_row_access(p_user_id,
                (old_row->>'portal_project_id')::integer,(old_row->>'portal_owner_user_id')::bigint,
                (old_row->>'portal_batch_id')::bigint)) THEN
            RAISE EXCEPTION 'Record is outside your assigned scope.' USING ERRCODE='42501';
        END IF;
        old_version:=(old_row->>'row_version')::bigint;
        IF old_row IS NOT NULL AND COALESCE((row_input->>'version')::bigint,0)<>old_version THEN
            RAISE EXCEPTION 'This record changed. Reload and try again.' USING ERRCODE='40001';
        END IF;
        IF config.table_name='audit_log' AND old_row IS NOT NULL THEN
            RAISE EXCEPTION 'Audit records cannot be changed.' USING ERRCODE='42501';
        END IF;
        row_values:=(row_input->'values')||jsonb_build_object('external_id',ext_id,'ui_data',row_input->'data',
            'portal_collection',p_collection,'portal_project_id',project_id,'portal_owner_user_id',owner_id,
            'portal_batch_id',batch_id,'portal_deleted',false,'row_version',COALESCE(old_version,0)+1);
        -- Column identifiers come from actual database metadata, never from SQL supplied by a client.
        IF EXISTS (SELECT 1 FROM jsonb_object_keys(row_values) k WHERE NOT EXISTS (
            SELECT 1 FROM information_schema.columns c WHERE c.table_schema='public'
            AND c.table_name=config.table_name AND c.column_name=k AND c.is_identity='NO')) THEN
            RAISE EXCEPTION 'Invalid record columns.' USING ERRCODE='22023';
        END IF;
        SELECT string_agg(format('%I',key),','),string_agg(format('r.%I',key),','),
            string_agg(format('%I=EXCLUDED.%I',key,key),',')
        INTO col_names,col_values,update_values FROM jsonb_object_keys(row_values) key;
        IF old_row IS NULL THEN
            EXECUTE format('INSERT INTO public.%I (%s) SELECT %s FROM jsonb_populate_record(NULL::public.%I,$1) r RETURNING %I',
                config.table_name,col_names,col_values,config.table_name,config.pk_column) INTO returned_id USING row_values;
        ELSE
            SELECT string_agg(format('%I=r.%I',key,key),',') INTO update_values FROM jsonb_object_keys(row_values) key;
            EXECUTE format('UPDATE public.%I target SET %s FROM jsonb_populate_record(NULL::public.%I,$1) r '
                'WHERE target.external_id=$2 RETURNING target.%I',config.table_name,update_values,config.table_name,config.pk_column)
                INTO returned_id USING row_values,ext_id;
        END IF;
        IF config.table_name<>'audit_log' THEN
            INSERT INTO public.audit_log(actor_user_id,action,entity_type,entity_id,project_id,before_json,after_json)
            VALUES(p_user_id,CASE WHEN old_row IS NULL THEN 'CREATE' ELSE 'UPDATE' END,
                config.table_name,returned_id::text,project_id,
                CASE WHEN old_row IS NULL THEN NULL ELSE jsonb_build_object('id',ext_id,'version',old_version) END,
                jsonb_build_object('id',ext_id,'version',COALESCE(old_version,0)+1));
        END IF;
        CALL public.usp_portal_sync_children(p_user_id,p_collection,returned_id,row_input->'data');
    END LOOP;
    FOR delete_input IN SELECT value FROM jsonb_array_elements(p_deletes) LOOP
        ext_id:=delete_input->>'id';
        EXECUTE format('SELECT to_jsonb(t) FROM public.%I t WHERE external_id=$1 AND NOT portal_deleted FOR UPDATE',config.table_name)
        INTO old_row USING ext_id;
        IF old_row IS NULL THEN CONTINUE; END IF;
        IF config.table_name='audit_log' OR (old_row->>'portal_collection') IS DISTINCT FROM p_collection OR
            NOT public.portal_row_access(p_user_id,(old_row->>'portal_project_id')::integer,
                (old_row->>'portal_owner_user_id')::bigint,(old_row->>'portal_batch_id')::bigint) THEN
            RAISE EXCEPTION 'You do not have permission to remove this record.' USING ERRCODE='42501';
        END IF;
        IF COALESCE((delete_input->>'version')::bigint,0)<>(old_row->>'row_version')::bigint THEN
            RAISE EXCEPTION 'This record changed. Reload and try again.' USING ERRCODE='40001';
        END IF;
        returned_id:=(old_row->>config.pk_column)::bigint;
        IF config.table_name='training_batch' AND EXISTS(SELECT 1 FROM public.batch_enrollment e WHERE e.batch_id=returned_id AND NOT e.portal_deleted) THEN
            RAISE EXCEPTION 'A batch with registrations cannot be deleted; cancel it instead.' USING ERRCODE='22023';
        END IF;
        IF config.table_name='project' AND EXISTS(SELECT 1 FROM public.training_batch b WHERE b.project_id=returned_id AND NOT b.portal_deleted) THEN
            RAISE EXCEPTION 'A project with batches cannot be deleted.' USING ERRCODE='22023';
        END IF;
        IF config.table_name='training_plan' AND EXISTS(SELECT 1 FROM public.training_batch b WHERE b.plan_id=returned_id AND NOT b.portal_deleted) THEN
            RAISE EXCEPTION 'A plan with batches cannot be deleted.' USING ERRCODE='22023';
        END IF;
        EXECUTE format('UPDATE public.%I SET portal_deleted=true,row_version=row_version+1 WHERE external_id=$1',config.table_name) USING ext_id;
        INSERT INTO public.audit_log(actor_user_id,action,entity_type,entity_id,project_id)
        VALUES(p_user_id,'DELETE',config.table_name,returned_id::text,(old_row->>'portal_project_id')::integer);
    END LOOP;
    CALL public.usp_portal_snapshot(p_user_id,p_result);
END;
$_$;


--
-- Name: usp_portal_begin_assessment(bigint, character varying, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_begin_assessment(IN p_user_id bigint, IN p_form_id character varying, IN p_batch_id character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE enrollment_key bigint; form_key bigint; limit_count integer; minutes integer; existing_start public.assessment_start;
    form_data jsonb; batch_data jsonb; business_today date:=(now() AT TIME ZONE 'Asia/Kolkata')::date;
BEGIN
    SELECT e.enrollment_id INTO enrollment_key FROM public.batch_enrollment e JOIN public.training_batch b ON b.batch_id=e.batch_id
    JOIN public.app_user u ON u.trainee_id=e.trainee_id WHERE u.user_id=p_user_id AND b.external_id=p_batch_id
    AND e.approval_status='APPROVED' AND NOT e.portal_deleted FOR UPDATE OF e;
    SELECT resource_id,COALESCE((ui_data->>'attemptLimit')::integer,1),COALESCE((ui_data->>'timeLimit')::integer,0)
    INTO form_key,limit_count,minutes FROM public.learning_resource WHERE external_id=p_form_id AND NOT portal_deleted;
    IF enrollment_key IS NULL OR form_key IS NULL THEN RAISE EXCEPTION 'This form or registration is unavailable.' USING ERRCODE='42501'; END IF;
    SELECT ui_data INTO form_data FROM public.learning_resource WHERE resource_id=form_key;
    SELECT ui_data INTO batch_data FROM public.training_batch WHERE external_id=p_batch_id;
    IF COALESCE(form_data->>'planCode','*') NOT IN ('*',batch_data->>'trainingPlanCode') THEN
        RAISE EXCEPTION 'This form is not assigned to the batch plan.' USING ERRCODE='42501';
    END IF;
    IF COALESCE((form_data->>'day')::integer,0)<1 OR
        (form_data->>'day')::integer>jsonb_array_length(COALESCE(batch_data->'trainingDates','[]')) OR
        (batch_data->'trainingDates'->>((form_data->>'day')::integer-1))::date>business_today OR
        NULLIF(form_data->>'availableFrom','')::date>business_today OR
        NULLIF(form_data->>'availableUntil','')::date<business_today THEN
        RAISE EXCEPTION 'This form is outside its availability window.' USING ERRCODE='22023';
    END IF;
    SELECT * INTO existing_start FROM public.assessment_start WHERE user_id=p_user_id AND enrollment_id=enrollment_key
        AND resource_id=form_key AND consumed_at IS NULL AND expires_at>now() ORDER BY started_at DESC LIMIT 1;
    IF NOT FOUND THEN
        IF (SELECT count(*) FROM public.assessment_start WHERE enrollment_id=enrollment_key AND resource_id=form_key)>=limit_count THEN
            RAISE EXCEPTION 'The attempt limit has been reached.' USING ERRCODE='22023';
        END IF;
        INSERT INTO public.assessment_start(user_id,enrollment_id,resource_id,expires_at)
        VALUES(p_user_id,enrollment_key,form_key,now()+make_interval(mins=>CASE WHEN minutes>0 THEN minutes ELSE 1440 END))
        RETURNING * INTO existing_start;
    END IF;
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('attemptToken',existing_start.start_id,
        'startedAt',existing_start.started_at,'expiresAt',existing_start.expires_at)::text));
END;
$$;


--
-- Name: usp_portal_bootstrap(jsonb, jsonb, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_bootstrap(IN p_users jsonb, IN p_schools jsonb, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE item jsonb; role_number integer; state_number integer; state_key integer; district_key integer; block_key integer; target_role_id integer;
    role_names text[]:=ARRAY['schoolnet-super-admin','sponsor-admin','schoolnet-project-admin','state-admin','school-admin','trainer','trainee','reporting-audit-user'];
BEGIN
    FOR role_number IN 1..array_length(role_names,1) LOOP
        INSERT INTO public.m_role(role_code,role_name,role_rank,role_category,data_scope)
        VALUES(role_names[role_number],initcap(replace(role_names[role_number],'-',' ')),role_number,
            CASE WHEN role_names[role_number]='trainer' THEN 'TRAINER' WHEN role_names[role_number]='trainee' THEN 'TRAINEE' ELSE 'MANAGEMENT' END,
            CASE WHEN role_names[role_number]='schoolnet-super-admin' THEN 'ALL' WHEN role_names[role_number]='trainee' THEN 'SELF' ELSE 'GRANT' END)
        ON CONFLICT(role_code) DO NOTHING;
    END LOOP;
    FOR item IN SELECT value FROM jsonb_array_elements(p_users) LOOP
        SELECT role_id INTO target_role_id FROM public.m_role WHERE role_code=item->>'role';
        INSERT INTO public.app_user(login_id,full_name,role_id,password_hash,must_change_password,external_id,
            portal_collection,ui_data)
        VALUES(item->>'userId',item->>'userId',target_role_id,item->>'passwordHash',false,item->>'userId',
            'teacher-training-users',jsonb_build_object('id',item->>'userId','userId',item->>'userId','role',item->>'role','active',true))
        ON CONFLICT(login_id) DO NOTHING;
    END LOOP;
    UPDATE public.app_user SET portal_owner_user_id=user_id WHERE portal_owner_user_id IS NULL;
    FOR item IN SELECT value FROM jsonb_array_elements(p_schools) LOOP
        SELECT state_id INTO state_key FROM public.m_state WHERE state_name=item->>'state';
        IF state_key IS NULL THEN
            SELECT count(*)+1 INTO state_number FROM public.m_state;
            INSERT INTO public.m_state(state_code,state_name) VALUES('S'||state_number,item->>'state') RETURNING state_id INTO state_key;
        END IF;
        SELECT district_id INTO district_key FROM public.m_district WHERE state_id=state_key AND district_name=item->>'district';
        IF district_key IS NULL THEN
            INSERT INTO public.m_district(state_id,district_name) VALUES(state_key,item->>'district') RETURNING district_id INTO district_key;
        END IF;
        block_key:=NULL;
        IF COALESCE(item->>'block','')<>'' THEN
            SELECT block_id INTO block_key FROM public.m_block WHERE district_id=district_key AND block_name=item->>'block';
            IF block_key IS NULL THEN
                INSERT INTO public.m_block(district_id,block_name) VALUES(district_key,item->>'block') RETURNING block_id INTO block_key;
            END IF;
        END IF;
        INSERT INTO public.m_school(udise_code,school_name,state_id,district_id,block_id,actual_location,external_id,portal_collection,ui_data)
        VALUES(item->>'udise',item->>'school',state_key,district_key,block_key,item->>'school',item->>'udise','teacher-training-schools',item||jsonb_build_object('id',item->>'udise'))
        ON CONFLICT(udise_code) DO NOTHING;
    END LOOP;
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('adminId',
        (SELECT user_id FROM public.app_user WHERE login_id='Demo2'))::text));
END;
$$;


--
-- Name: usp_portal_check_session(bigint, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_check_session(IN p_user_id bigint, IN p_token_id character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    p_result:=jsonb_build_array(jsonb_build_object('is_active',EXISTS (
        SELECT 1 FROM public.app_auth_session s JOIN public.app_user u ON u.user_id=s.user_id
        JOIN public.m_role r ON r.role_id=u.role_id WHERE s.user_id=p_user_id AND s.token_id=p_token_id
        AND s.expires_at>now() AND u.is_active AND r.is_active AND s.role_code=r.role_code
    )));
END;
$$;


--
-- Name: usp_portal_create_otp(uuid, character varying, bigint, character varying, character varying, jsonb, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_create_otp(IN p_id uuid, IN p_purpose character varying, IN p_user_id bigint, IN p_recipient_hash character varying, IN p_otp_hash character varying, IN p_payload jsonb, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Serialize requests for the same recipient, including requests from different application instances.
    PERFORM pg_advisory_xact_lock(hashtextextended(p_recipient_hash,0));
    IF EXISTS (SELECT 1 FROM public.portal_otp_challenge WHERE recipient_hash=p_recipient_hash AND locked_until>now()) THEN
        RAISE EXCEPTION 'Verification is locked for 15 minutes after three incorrect codes.' USING ERRCODE='22023';
    END IF;
    IF (SELECT count(*) FROM public.portal_otp_challenge WHERE recipient_hash=p_recipient_hash
        AND created_at>now()-interval '15 minutes' AND (consumed_at IS NULL OR attempt_count=0))>=10 THEN
        RAISE EXCEPTION 'Too many verification requests. Please try again in 15 minutes.' USING ERRCODE='22023';
    END IF;
    UPDATE public.portal_otp_challenge SET consumed_at=now()
        WHERE recipient_hash=p_recipient_hash AND purpose=p_purpose AND consumed_at IS NULL;
    INSERT INTO public.portal_otp_challenge(challenge_id,purpose,user_id,recipient_hash,otp_hash,protected_payload,expires_at)
        VALUES(p_id,p_purpose,p_user_id,p_recipient_hash,p_otp_hash,p_payload,now()+interval '5 minutes');
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('challengeId',p_id,
        'expiresAt',now()+interval '5 minutes')::text));
END;
$$;


--
-- Name: usp_portal_dashboard(bigint, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_dashboard(IN p_user_id bigint, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE result jsonb;
BEGIN
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'index',b.batch_id,'id',b.batch_code,'batch',b.batch_code,'externalId',b.external_id,
        'status',CASE WHEN b.ui_data->>'status'='Completed' THEN 'completed' WHEN CURRENT_DATE<b.start_date THEN 'upcoming' ELSE 'ongoing' END,
        'phaseNumber',COALESCE((SELECT sequence_number FROM public.project_phase WHERE external_id=b.ui_data->>'phaseId'),1),
        'project',(SELECT project_name FROM public.project WHERE project_id=b.project_id),
        'phase',b.plan_name,'plan',b.plan_name,'state',b.state_name,'district',b.district_name,'block',COALESCE(b.block_name,''),
        'school',b.school_name,'udise',b.udise_code,'trainer',b.trainer_name,'location',b.district_name||', '||b.state_name,
        'date',to_char(b.start_date,'DD-Mon-YYYY'),'startDate',b.start_date,'endDate',b.end_date,
        'capacity',b.capacity,'teacherParticipants',b.capacity,'studentParticipants',0,'participants',b.registered_count,
        'teacherMetrics',public.portal_audience_metrics(b.batch_id,'Teacher'),
        'studentMetrics',public.portal_audience_metrics(b.batch_id,'Student'),
        'attendanceDays',(SELECT COALESCE(jsonb_agg(to_jsonb(d) ORDER BY d.date),'[]') FROM (
            SELECT a.attendance_date AS date,COALESCE(t.ui_data->>'category','Teacher') AS audience,
                count(*) AS marked,count(*) FILTER(WHERE a.status='PRESENT') AS present
            FROM public.attendance a JOIN public.batch_enrollment e ON e.enrollment_id=a.enrollment_id
            JOIN public.trainee t ON t.trainee_id=e.trainee_id
            WHERE e.batch_id=b.batch_id AND NOT a.portal_deleted AND NOT e.portal_deleted
            GROUP BY a.attendance_date,COALESCE(t.ui_data->>'category','Teacher')) d),
        'registered',b.registered_count,'approved',b.approved_count,'attended',b.attended_count,'completed',b.completed_count,
        'certified',b.certified_count,'attendance',round(b.attendance_pct,1),
        'completion',CASE WHEN b.registered_count=0 THEN 0 ELSE round(100.0*b.completed_count/b.registered_count,1) END,
        'participantRows',(SELECT COALESCE(jsonb_agg(jsonb_build_object('name',t.full_name,
            'type',COALESCE(t.ui_data->>'category','Teacher'),'status',initcap(e.approval_status),'school',b.school_name,
            'id',t.trainee_code)),'[]') FROM public.batch_enrollment e JOIN public.trainee t ON t.trainee_id=e.trainee_id
            WHERE e.batch_id=b.batch_id AND NOT e.portal_deleted)
    ) ORDER BY b.batch_id),'[]') INTO result FROM public.v_batch_progress b
    WHERE public.portal_row_access(p_user_id,b.project_id,NULL,b.batch_id);
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('batches',result,
        'phases',(SELECT COALESCE(jsonb_agg(jsonb_build_object('name',phase_name,'number',sequence_number,
            'startDate',start_date,'endDate',end_date,'status',status) ORDER BY sequence_number),'[]')
            FROM public.project_phase WHERE NOT portal_deleted AND public.portal_project_access(p_user_id,project_id)))::text));
END;
$$;


--
-- Name: usp_portal_login_lookup(character varying, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_login_lookup(IN p_login_id character varying, IN p_contact_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    SELECT COALESCE(jsonb_agg(jsonb_build_object('user_id',u.user_id,'login_id',u.login_id,
        'password_hash',u.password_hash,'role',r.role_code,'is_active',u.is_active AND r.is_active,
        'locked_until',u.locked_until,'failed_login_count',u.failed_login_count,
        'contact_data',COALESCE((SELECT t.ui_data FROM public.trainee t WHERE t.trainee_id=u.trainee_id),
            (SELECT t.ui_data FROM public.trainer t WHERE t.trainer_id=u.trainer_id),u.ui_data)::text)), '[]'::jsonb)
    INTO p_result FROM public.app_user u JOIN public.m_role r ON r.role_id=u.role_id
    WHERE NOT u.portal_deleted AND (lower(u.login_id)=lower(trim(p_login_id)) OR
        (position('@' IN p_login_id)>0 OR length(regexp_replace(p_login_id,'[^0-9]','','g'))>=10) AND (
            u.email_hash=p_contact_hash OR u.mobile_hash=p_contact_hash OR
            u.ui_data->'_contacts'->'email'->>'hash'=p_contact_hash OR
            u.ui_data->'_contacts'->'phone'->>'hash'=p_contact_hash OR
            EXISTS(SELECT 1 FROM public.trainee t WHERE t.trainee_id=u.trainee_id AND NOT t.is_erased AND
                (t.email_hash=p_contact_hash OR t.mobile_hash=p_contact_hash)) OR
            EXISTS(SELECT 1 FROM public.trainer t WHERE t.trainer_id=u.trainer_id AND
                (t.email_hash=p_contact_hash OR t.mobile_hash=p_contact_hash))));
END;
$$;


--
-- Name: usp_portal_login_result(bigint, boolean, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_login_result(IN p_user_id bigint, IN p_success boolean, IN p_login_id character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF p_user_id IS NOT NULL THEN
        UPDATE public.app_user SET failed_login_count=CASE WHEN p_success THEN 0 ELSE failed_login_count+1 END,
            locked_until=CASE WHEN p_success THEN NULL WHEN failed_login_count+1>=3
                THEN now()+interval '15 minutes' ELSE locked_until END,
            last_login_at=CASE WHEN p_success THEN now() ELSE last_login_at END
        WHERE user_id=p_user_id;
    END IF;
    INSERT INTO public.user_activity_log(user_id,login_id_tried,activity_type,result)
    VALUES(p_user_id,left(p_login_id,30),'LOGIN',CASE WHEN p_success THEN 'SUCCESS' ELSE 'FAILED' END);
    p_result:='[{"is_success":true}]'::jsonb;
END;
$$;


--
-- Name: usp_portal_public_data(jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_public_data(INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE snapshot jsonb;
BEGIN
    snapshot:=jsonb_build_object('teacher-training-batch-plan-uses',
        (SELECT COALESCE(jsonb_agg(ui_data-'_contacts'),'[]') FROM public.training_batch WHERE NOT portal_deleted),
        'teacher-training-schools',(SELECT COALESCE(jsonb_agg(ui_data),'[]') FROM public.m_school WHERE NOT portal_deleted),
        'teacher-training-plans',(SELECT COALESCE(jsonb_agg(jsonb_build_object('id',external_id,'code',plan_code,'name',plan_name)),'[]') FROM public.training_plan WHERE NOT portal_deleted));
    p_result:=jsonb_build_array(jsonb_build_object('payload',snapshot::text));
END;
$$;


--
-- Name: usp_portal_public_register(character varying, jsonb, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_public_register(IN p_batch_code character varying, IN p_person jsonb, IN p_password_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE batch_row public.training_batch; person_row public.trainee; email_person bigint; phone_person bigint;
    registration_id text; person_id bigint; reg_id bigint; person_external text; local_today date; created_account boolean:=false;
BEGIN
    SELECT * INTO batch_row FROM public.training_batch WHERE NOT portal_deleted AND
        (external_id=p_batch_code OR lower(batch_code)=lower(p_batch_code)) FOR UPDATE;
    IF NOT FOUND OR NOT batch_row.open_registration OR batch_row.is_closed OR
        COALESCE(batch_row.ui_data->>'status','') IN ('Cancelled','Archived','Completed') THEN
        RAISE EXCEPTION 'This batch is not accepting registrations.' USING ERRCODE='22023';
    END IF;
    local_today:=(now() AT TIME ZONE 'Asia/Kolkata')::date;
    IF local_today<batch_row.start_date-COALESCE((batch_row.ui_data->>'registrationWindowBeforeDays')::integer,0) OR
        local_today>batch_row.start_date+COALESCE((batch_row.ui_data->>'registrationWindowAfterDays')::integer,0) THEN
        RAISE EXCEPTION 'The registration window is closed.' USING ERRCODE='22023';
    END IF;
    IF (SELECT count(*) FROM public.batch_enrollment WHERE batch_id=batch_row.batch_id AND NOT portal_deleted AND approval_status<>'REJECTED')>=batch_row.capacity THEN
        RAISE EXCEPTION 'This batch has reached its registration capacity.' USING ERRCODE='22023';
    END IF;
    SELECT trainee_id INTO email_person FROM public.trainee WHERE email_hash=p_person->>'emailHash' AND NOT is_erased;
    SELECT trainee_id INTO phone_person FROM public.trainee WHERE mobile_hash=p_person->>'phoneHash' AND NOT is_erased;
    IF email_person IS NULL AND phone_person IS NOT NULL AND p_person->>'emailHash' IS NOT NULL THEN
        RAISE EXCEPTION 'Use the email registered to your trainee record, or verify with your registered mobile number only.' USING ERRCODE='22023';
    END IF;
    IF email_person IS NOT NULL AND phone_person IS NOT NULL AND email_person<>phone_person THEN
        RAISE EXCEPTION 'The contact details match different trainee records. Contact an administrator.' USING ERRCODE='22023';
    END IF;
    person_id:=COALESCE(email_person,phone_person);
    IF person_id IS NULL THEN
        created_account:=true;
        person_external:=p_person->>'id';
        INSERT INTO public.trainee(trainee_code,full_name,email_hash,mobile_hash,email_enc,mobile_enc,email_mask,mobile_mask,
            external_id,ui_data,portal_collection,portal_project_id)
        VALUES(person_external,p_person->>'name',p_person->>'emailHash',p_person->>'phoneHash',
            decode(p_person->>'emailHex','hex'),decode(p_person->>'phoneHex','hex'),p_person->>'emailMask',p_person->>'phoneMask',
            person_external,p_person->'data','teacher-training-trainees',batch_row.project_id) RETURNING trainee_id INTO person_id;
    ELSE
        SELECT external_id INTO person_external FROM public.trainee WHERE trainee_id=person_id;
    END IF;
    -- Imported people may already exist without an application account.
    IF NOT EXISTS(SELECT 1 FROM public.app_user WHERE trainee_id=person_id) THEN
        created_account:=true;
        INSERT INTO public.app_user(login_id,full_name,role_id,password_hash,must_change_password,trainee_id,external_id,ui_data,portal_collection)
        SELECT t.trainee_code,t.full_name,r.role_id,p_password_hash,true,person_id,
            'ACCOUNT-'||md5(person_id::text),jsonb_build_object('id',t.trainee_code,'userId',t.trainee_code,'role','trainee','active',true),'teacher-training-users'
        FROM public.m_role r CROSS JOIN public.trainee t WHERE r.role_code='trainee' AND t.trainee_id=person_id;
        UPDATE public.trainee SET portal_owner_user_id=(SELECT user_id FROM public.app_user WHERE trainee_id=person_id),
            ui_data=ui_data||jsonb_build_object('userId',(SELECT login_id FROM public.app_user WHERE trainee_id=person_id)) WHERE trainee_id=person_id;
        UPDATE public.app_user SET portal_owner_user_id=user_id WHERE trainee_id=person_id;
    END IF;
    IF EXISTS(SELECT 1 FROM public.batch_enrollment WHERE batch_id=batch_row.batch_id AND trainee_id=person_id AND NOT portal_deleted) THEN
        RAISE EXCEPTION 'A registration already exists for this trainee and batch.' USING ERRCODE='23505';
    END IF;
    registration_id:='REG-'||md5(random()::text||clock_timestamp()::text);
    INSERT INTO public.batch_enrollment(batch_id,trainee_id,registration_mode,approval_status,external_id,portal_collection,
        portal_project_id,portal_batch_id,portal_owner_user_id,ui_data)
    VALUES(batch_row.batch_id,person_id,'SELF','PENDING',registration_id,'teacher-training-registrations',batch_row.project_id,
        batch_row.batch_id,(SELECT user_id FROM public.app_user WHERE trainee_id=person_id),
        (p_person->'data')||jsonb_build_object('id',registration_id,'traineeId',person_external,'batchId',batch_row.external_id,
            'userId',(SELECT login_id FROM public.app_user WHERE trainee_id=person_id),
            'batchCode',batch_row.batch_code,'projectId',(SELECT external_id FROM public.project WHERE project_id=batch_row.project_id),
            'traineeName',p_person->>'name','status','Pending','registrationStatus','Pending','submittedAt',now()))
    RETURNING enrollment_id INTO reg_id;
    INSERT INTO public.audit_log(action,entity_type,entity_id,project_id,after_json)
    VALUES('SELF_REGISTER','batch_enrollment',reg_id::text,batch_row.project_id,jsonb_build_object('registrationId',registration_id));
    INSERT INTO public.consent_record(trainee_id,purpose,notice_version,channel,given_by)
        VALUES(person_id,'TRAINING_REGISTRATION','1.0','WEB','SELF');
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('traineeId',person_external,
        'registrationId',registration_id,'newAccount',created_account,'message','Registration request submitted. The trainer or administrator must review it before your place is confirmed.')::text));
END;
$$;


--
-- Name: usp_portal_recovery_lookup(character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_recovery_lookup(IN p_contact_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('traineeIds',
        (SELECT COALESCE(jsonb_agg(trainee_code),'[]') FROM public.trainee WHERE NOT is_erased AND is_active AND
            (email_hash=p_contact_hash OR mobile_hash=p_contact_hash)))::text));
END;
$$;


--
-- Name: usp_portal_request_recovery(uuid, character varying, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_request_recovery(IN p_request_id uuid, IN p_contact_hash character varying, IN p_otp_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE person_id bigint;
BEGIN
    SELECT trainee_id INTO person_id FROM public.trainee WHERE NOT is_erased AND is_active AND
        (email_hash=p_contact_hash OR mobile_hash=p_contact_hash);
    INSERT INTO public.portal_recovery_request(request_id,trainee_id,otp_hash,expires_at)
    VALUES(p_request_id,person_id,p_otp_hash,now()+interval '5 minutes');
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('matched',person_id IS NOT NULL)::text));
END;
$$;


--
-- Name: usp_portal_reset_password(bigint, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_reset_password(IN p_user_id bigint, IN p_password_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    UPDATE public.app_user SET password_hash=p_password_hash,must_change_password=false,failed_login_count=0,
        locked_until=NULL WHERE user_id=p_user_id AND is_active AND NOT portal_deleted AND login_id !~* '^Demo[1-8]$';
    IF NOT FOUND THEN RAISE EXCEPTION 'The password cannot be reset for this account.' USING ERRCODE='22023'; END IF;
    DELETE FROM public.app_auth_session WHERE user_id=p_user_id;
    UPDATE public.portal_otp_challenge SET consumed_at=now() WHERE user_id=p_user_id AND consumed_at IS NULL;
    INSERT INTO public.user_activity_log(user_id,activity_type,result) VALUES(p_user_id,'PASSWORD_RESET','SUCCESS');
    p_result:='[{"is_success":true}]';
END;
$_$;


--
-- Name: usp_portal_resource_access(bigint, bigint, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_resource_access(IN p_user_id bigint, IN p_resource_id bigint, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO public.resource_access_log(resource_id,user_id) VALUES(p_resource_id,p_user_id);
    p_result:='[{"is_success":true}]';
END;
$$;


--
-- Name: usp_portal_revoke_session(bigint, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_revoke_session(IN p_user_id bigint, IN p_token_id character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM public.app_auth_session WHERE user_id=p_user_id AND token_id=p_token_id;
    INSERT INTO public.user_activity_log(user_id,activity_type,result) VALUES(p_user_id,'LOGOUT','SUCCESS');
    p_result:='[{"is_success":true}]'::jsonb;
END;
$$;


--
-- Name: usp_portal_save_session(bigint, character varying, timestamp with time zone, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_save_session(IN p_user_id bigint, IN p_token_id character varying, IN p_expires_at timestamp with time zone, IN p_role character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO public.app_auth_session(user_id,token_id,expires_at,role_code)
    VALUES(p_user_id,p_token_id,p_expires_at,p_role)
    ON CONFLICT(user_id) DO UPDATE SET token_id=excluded.token_id,expires_at=excluded.expires_at,role_code=excluded.role_code;
    p_result:='[{"is_success":true}]'::jsonb;
END;
$$;


--
-- Name: usp_portal_seed_scopes(integer, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_seed_scopes(IN p_project_id integer, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE target record;
BEGIN
    FOR target IN SELECT user_id FROM public.app_user WHERE login_id IN ('Demo1','Demo3','Demo4','Demo5','Demo6','Demo8') LOOP
        IF NOT EXISTS(SELECT 1 FROM public.user_access_scope WHERE user_id=target.user_id AND project_id=p_project_id) THEN
            INSERT INTO public.user_access_scope(user_id,project_id) VALUES(target.user_id,p_project_id);
        END IF;
    END LOOP;
    p_result:='[{"is_success":true}]';
END;
$$;


--
-- Name: usp_portal_snapshot(bigint, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_snapshot(IN p_user_id bigint, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $_$
DECLARE collection record; actor_role_code text; rows_json jsonb; snapshot jsonb:='{}';
BEGIN
    SELECT r.role_code INTO actor_role_code FROM public.app_user u JOIN public.m_role r ON r.role_id=u.role_id
    WHERE u.user_id=p_user_id AND u.is_active AND r.is_active;
    IF actor_role_code IS NULL THEN RAISE EXCEPTION 'Authentication is required.' USING ERRCODE='42501'; END IF;
    FOR collection IN SELECT * FROM public.portal_collection ORDER BY collection_key LOOP
        IF NOT (actor_role_code=ANY(collection.read_roles)) THEN
            snapshot:=snapshot||jsonb_build_object(collection.collection_key,'[]'::jsonb);
            CONTINUE;
        END IF;
        EXECUTE format('SELECT COALESCE(jsonb_agg(ui_data || jsonb_build_object(''_dbId'',%I,''_version'',row_version,''_ownerId'',portal_owner_user_id) ORDER BY %I),''[]''::jsonb) '
            'FROM public.%I WHERE portal_collection=$1 AND NOT portal_deleted '
            'AND public.portal_row_access($2,portal_project_id,portal_owner_user_id,portal_batch_id) '
            'AND ($3<>''trainee'' OR $4 NOT IN (''trainee'',''batch_enrollment'',''attendance'',''assessment_attempt'',''certificate_record'',''resource_progress'',''external_course_record'') OR portal_owner_user_id=$2)',
            collection.pk_column,collection.pk_column,collection.table_name)
        INTO rows_json USING collection.collection_key,p_user_id,actor_role_code,collection.table_name::text;
        snapshot:=snapshot||jsonb_build_object(collection.collection_key,rows_json);
    END LOOP;
    snapshot:=snapshot||jsonb_build_object('_roles',(SELECT COALESCE(jsonb_agg(jsonb_build_object('id',role_id,'role',role_code)),'[]') FROM public.m_role WHERE is_active),
        '_states',(SELECT COALESCE(jsonb_agg(jsonb_build_object('id',state_id,'name',state_name)),'[]') FROM public.m_state),
        '_districts',(SELECT COALESCE(jsonb_agg(jsonb_build_object('id',d.district_id,'name',d.district_name,'state',s.state_name)),'[]') FROM public.m_district d JOIN public.m_state s ON s.state_id=d.state_id),
        '_current',(SELECT jsonb_build_object('id',user_id,'userId',login_id,'role',actor_role_code) FROM public.app_user WHERE user_id=p_user_id));
    p_result:=jsonb_build_array(jsonb_build_object('payload',snapshot::text));
END;
$_$;


--
-- Name: usp_portal_sync_children(bigint, character varying, bigint, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_sync_children(IN p_user_id bigint, IN p_collection character varying, IN p_record_id bigint, IN p_data jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE item jsonb; day_number integer; child_id bigint; target_id bigint;
BEGIN
    CASE p_collection
    WHEN 'teacher-training-projects' THEN
        UPDATE public.project SET portal_project_id=p_record_id WHERE project_id=p_record_id;
        FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(p_data->'phases','[]')) LOOP
            INSERT INTO public.project_phase(project_id,phase_name,sequence_number,start_date,end_date,status,external_id,ui_data,portal_project_id)
            VALUES(p_record_id,item->>'name',(item->>'sequence')::integer,(item->>'startDate')::date,
                (item->>'endDate')::date,item->>'status',item->>'id',item,p_record_id)
            ON CONFLICT(external_id) DO UPDATE SET phase_name=excluded.phase_name,sequence_number=excluded.sequence_number,
                start_date=excluded.start_date,end_date=excluded.end_date,status=excluded.status,ui_data=excluded.ui_data;
        END LOOP;
        UPDATE public.user_access_scope SET is_active=false
        WHERE project_id=p_record_id AND portal_collection='project-assignment';
        FOR target_id IN SELECT user_id FROM public.app_user WHERE login_id IN
            (SELECT jsonb_array_elements_text(COALESCE(p_data->'assignedUsers','[]'))) OR user_id=p_user_id LOOP
            IF EXISTS(SELECT 1 FROM public.user_access_scope WHERE user_id=target_id AND project_id=p_record_id AND portal_collection='project-assignment') THEN
                UPDATE public.user_access_scope SET is_active=true WHERE user_id=target_id AND project_id=p_record_id AND portal_collection='project-assignment';
            ELSE
                INSERT INTO public.user_access_scope(user_id,project_id,created_by,portal_collection)
                VALUES(target_id,p_record_id,p_user_id,'project-assignment');
            END IF;
        END LOOP;
    WHEN 'teacher-training-plans' THEN
        FOR day_number IN 1..(p_data->>'days')::integer LOOP
            INSERT INTO public.training_plan_day(plan_id,day_no,day_title,created_by)
            VALUES(p_record_id,day_number,'Day '||day_number,p_user_id)
            ON CONFLICT(plan_id,day_no) DO NOTHING;
        END LOOP;
    WHEN 'teacher-training-batch-plan-uses' THEN
        UPDATE public.training_batch SET portal_batch_id=p_record_id WHERE batch_id=p_record_id;
        day_number:=0;
        FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(p_data->'trainingDates','[]')) LOOP
            day_number:=day_number+1;
            INSERT INTO public.batch_day(batch_id,day_no,day_date,day_title)
            VALUES(p_record_id,day_number,(item#>>'{}')::date,'Day '||day_number)
            ON CONFLICT(batch_id,day_no) DO UPDATE SET day_date=excluded.day_date;
        END LOOP;
    WHEN 'teacher-training-trainer-profiles' THEN
        UPDATE public.app_user SET trainer_id=p_record_id WHERE login_id=p_data->>'userId';
    WHEN 'teacher-training-trainees' THEN
        UPDATE public.app_user SET trainee_id=p_record_id WHERE login_id=p_data->>'userId';
    WHEN 'teacher-training-users' THEN
        UPDATE public.app_user SET portal_owner_user_id=p_record_id WHERE user_id=p_record_id;
    WHEN 'teacher-training-assessment-form-master' THEN
        UPDATE public.form_question SET is_active=false WHERE resource_id=p_record_id;
        day_number:=0;
        FOR item IN SELECT value FROM jsonb_array_elements(COALESCE(p_data->'questions','[]')) LOOP
            day_number:=day_number+1;
            INSERT INTO public.form_question(resource_id,question_text,expected_answer,options_json,marks,sort_order,
                external_id,ui_data,created_by)
            VALUES(p_record_id,item->>'prompt',item->>'correctIndex',item->'options',COALESCE((item->>'points')::numeric,1),
                day_number,left((p_data->>'id')||':'||(item->>'id'),100),item,p_user_id)
            ON CONFLICT(external_id) DO UPDATE SET question_text=excluded.question_text,expected_answer=excluded.expected_answer,
                options_json=excluded.options_json,marks=excluded.marks,sort_order=excluded.sort_order,is_active=true,ui_data=excluded.ui_data;
        END LOOP;
    WHEN 'teacher-training-registrations' THEN
        IF COALESCE((p_data->>'consentProvided')::boolean,false) THEN
            INSERT INTO public.consent_record(trainee_id,purpose,notice_version,channel)
            SELECT trainee_id,'TRAINING_ENROLMENT','1.0',CASE WHEN p_data->>'source' LIKE '%Excel%' THEN 'EXCEL' ELSE 'ADMIN' END
            FROM public.batch_enrollment e WHERE e.enrollment_id=p_record_id
            AND NOT EXISTS(SELECT 1 FROM public.consent_record c WHERE c.trainee_id=e.trainee_id AND c.purpose='TRAINING_ENROLMENT');
        END IF;
    WHEN 'teacher-training-assessment-records','teacher-training-feedback-records' THEN
        FOR item IN SELECT jsonb_build_object('question_id',q.question_id,'answer',p_data->'answers'->>(q.ui_data->>'id'),
            'expected',q.expected_answer,'marks',q.marks) FROM public.form_question q
            WHERE q.resource_id=(SELECT resource_id FROM public.assessment_attempt WHERE attempt_id=p_record_id) AND q.is_active LOOP
            INSERT INTO public.form_submission(enrollment_id,question_id,answer,score)
            SELECT a.enrollment_id,(item->>'question_id')::bigint,COALESCE(item->>'answer',''),
                CASE WHEN a.kind='feedback' THEN NULL WHEN item->>'answer'=item->>'expected' THEN (item->>'marks')::numeric ELSE 0 END
            FROM public.assessment_attempt a WHERE a.attempt_id=p_record_id;
        END LOOP;
    WHEN 'teacher-training-certificates' THEN
        INSERT INTO public.completion_review(enrollment_id,is_eligible,remarks,reviewed_by)
        SELECT enrollment_id,true,'Completion rules verified by the application service.',p_user_id
        FROM public.certificate_record WHERE certificate_id=p_record_id
        ON CONFLICT(enrollment_id) DO UPDATE SET is_eligible=true,remarks=excluded.remarks,
            reviewed_by=excluded.reviewed_by,reviewed_at=now();
    ELSE NULL;
    END CASE;
END;
$$;


--
-- Name: usp_portal_verify_otp(uuid, character varying, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_verify_otp(IN p_id uuid, IN p_purpose character varying, IN p_otp_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE challenge public.portal_otp_challenge; user_record public.app_user; role_code text;
BEGIN
    p_result:='[{"payload":"{\"verified\":false}"}]';
    SELECT * INTO challenge FROM public.portal_otp_challenge WHERE challenge_id=p_id AND purpose=p_purpose FOR UPDATE;
    IF NOT FOUND OR challenge.consumed_at IS NOT NULL OR challenge.expires_at<=now() OR challenge.attempt_count>=3 THEN RETURN; END IF;
    UPDATE public.portal_otp_challenge SET attempt_count=attempt_count+1,
        locked_until=CASE WHEN attempt_count+1>=3 AND otp_hash<>p_otp_hash THEN now()+interval '15 minutes' ELSE locked_until END WHERE challenge_id=p_id;
    IF challenge.otp_hash<>p_otp_hash THEN RETURN; END IF;
    IF p_purpose='LOGIN' THEN
        SELECT * INTO user_record FROM public.app_user WHERE user_id=challenge.user_id AND is_active AND NOT portal_deleted;
        IF NOT FOUND OR user_record.locked_until>now() THEN RETURN; END IF;
        SELECT r.role_code INTO role_code FROM public.m_role r WHERE r.role_id=user_record.role_id AND r.is_active;
        IF role_code IS NULL THEN RETURN; END IF;
    END IF;
    UPDATE public.portal_otp_challenge SET consumed_at=now() WHERE challenge_id=p_id;
    INSERT INTO public.user_activity_log(user_id,activity_type,result)
        VALUES(challenge.user_id,'OTP_VERIFY','SUCCESS');
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('verified',true,
        'protectedPayload',challenge.protected_payload,'userId',challenge.user_id,
        'loginId',user_record.login_id,'role',role_code)::text));
END;
$$;


--
-- Name: usp_portal_verify_recovery(uuid, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_portal_verify_recovery(IN p_request_id uuid, IN p_otp_hash character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
DECLARE request_row public.portal_recovery_request; identifiers jsonb;
BEGIN
    SELECT * INTO request_row FROM public.portal_recovery_request WHERE request_id=p_request_id FOR UPDATE;
    IF NOT FOUND OR request_row.consumed_at IS NOT NULL OR request_row.expires_at<=now() OR request_row.attempt_count>=3 THEN
        p_result:='[{"payload":"{\"verified\":false}"}]';RETURN;
    END IF;
    UPDATE public.portal_recovery_request SET attempt_count=attempt_count+1 WHERE request_id=p_request_id;
    IF request_row.trainee_id IS NULL OR request_row.otp_hash<>p_otp_hash THEN
        p_result:='[{"payload":"{\"verified\":false}"}]';RETURN;
    END IF;
    UPDATE public.portal_recovery_request SET consumed_at=now() WHERE request_id=p_request_id;
    SELECT jsonb_agg(trainee_code) INTO identifiers FROM public.trainee WHERE trainee_id=request_row.trainee_id;
    p_result:=jsonb_build_array(jsonb_build_object('payload',jsonb_build_object('verified',true,'traineeIds',identifiers)::text));
END;
$$;


--
-- Name: usp_revoke_auth_token(integer, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_revoke_auth_token(IN p_teacher_id integer, IN p_token_id character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM public.teacher_auth_tokens
    WHERE teacher_id = p_teacher_id AND token_id = p_token_id;
    p_result := jsonb_build_array(jsonb_build_object('is_success', true));
END;
$$;


--
-- Name: usp_save_auth_token(integer, character varying, timestamp with time zone, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_save_auth_token(IN p_teacher_id integer, IN p_token_id character varying, IN p_expires_at timestamp with time zone, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO public.teacher_auth_tokens (teacher_id, token_id, expires_at)
    VALUES (p_teacher_id, p_token_id, p_expires_at)
    ON CONFLICT (teacher_id) DO UPDATE
    SET token_id = EXCLUDED.token_id, expires_at = EXCLUDED.expires_at;
    p_result := jsonb_build_array(jsonb_build_object('is_success', true));
END;
$$;


--
-- Name: usp_save_teacher(character varying, character varying, character varying, character varying, character varying, text, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_save_teacher(IN p_first_name character varying, IN p_last_name character varying, IN p_email character varying, IN p_subject character varying, IN p_phone_number character varying, IN p_password_hash text, IN p_role character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    WITH saved AS
    (
        INSERT INTO public.teachers
            (first_name, last_name, email, subject, phone_number, password_hash, role)
        VALUES (trim(p_first_name), trim(p_last_name), lower(trim(p_email)),
                trim(p_subject), trim(p_phone_number), p_password_hash, p_role)
        RETURNING id, first_name, last_name, email, subject, phone_number, role, is_active, created_at
    )
    SELECT jsonb_agg(to_jsonb(saved)) INTO p_result FROM saved;
END;
$$;


--
-- Name: usp_update_teacher(integer, character varying, character varying, character varying, character varying, character varying, jsonb); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.usp_update_teacher(IN p_teacher_id integer, IN p_first_name character varying, IN p_last_name character varying, IN p_email character varying, IN p_subject character varying, IN p_phone_number character varying, INOUT p_result jsonb DEFAULT NULL::jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    WITH updated AS
    (
        UPDATE public.teachers
        SET first_name = trim(p_first_name), last_name = trim(p_last_name),
            email = lower(trim(p_email)), subject = trim(p_subject),
            phone_number = trim(p_phone_number), updated_at = now()
        WHERE id = p_teacher_id
        RETURNING id, first_name, last_name, email, subject, phone_number, role, is_active, created_at
    )
    SELECT COALESCE(jsonb_agg(to_jsonb(updated)), '[]'::jsonb) INTO p_result FROM updated;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_auth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_auth_session (
    user_id bigint NOT NULL,
    token_id character varying(32) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    role_code character varying(30) NOT NULL
);


--
-- Name: app_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_user (
    user_id bigint NOT NULL,
    login_id character varying(30) NOT NULL,
    full_name character varying(150) NOT NULL,
    role_id smallint NOT NULL,
    email_enc bytea,
    email_hash character(64),
    email_mask character varying(150),
    pii_key_version smallint DEFAULT 1 NOT NULL,
    mobile_enc bytea,
    mobile_hash character(64),
    mobile_mask character varying(150),
    password_hash character varying(255) NOT NULL,
    must_change_password boolean DEFAULT true NOT NULL,
    failed_login_count smallint DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    stakeholder_id integer,
    parent_user_id bigint,
    trainer_id integer,
    trainee_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: app_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.app_user ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.app_user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: assessment_attempt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assessment_attempt (
    attempt_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    kind character varying(20) NOT NULL,
    answers jsonb DEFAULT '{}'::jsonb NOT NULL,
    score numeric(7,2),
    max_marks numeric(7,2),
    passed boolean,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: assessment_attempt_attempt_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.assessment_attempt ALTER COLUMN attempt_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.assessment_attempt_attempt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: assessment_start; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assessment_start (
    start_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance (
    attendance_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    attendance_date date NOT NULL,
    status character varying(10) NOT NULL,
    source character varying(10) DEFAULT 'MANUAL'::character varying NOT NULL,
    marked_by bigint NOT NULL,
    marked_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: attendance_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.attendance ALTER COLUMN attendance_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.attendance_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: attendance_exclusion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_exclusion (
    exclusion_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    training_date date NOT NULL,
    reason character varying(1000) NOT NULL,
    approved boolean DEFAULT true NOT NULL,
    changed_by bigint NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: attendance_exclusion_exclusion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.attendance_exclusion ALTER COLUMN exclusion_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.attendance_exclusion_exclusion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    audit_id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_user_id bigint,
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(50) NOT NULL,
    project_id integer,
    before_json jsonb,
    after_json jsonb,
    ip_address character varying(45),
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: audit_log_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ALTER COLUMN audit_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_log_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: batch_day; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_day (
    batch_day_id bigint NOT NULL,
    batch_id bigint NOT NULL,
    day_no smallint NOT NULL,
    day_date date NOT NULL,
    day_title character varying(200) NOT NULL,
    objective character varying(500),
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: batch_day_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_day_activity (
    batch_activity_id bigint NOT NULL,
    batch_day_id bigint NOT NULL,
    seq_no smallint NOT NULL,
    activity_type character varying(12) NOT NULL,
    title character varying(200) NOT NULL,
    description character varying(1000),
    start_time time without time zone,
    duration_minutes smallint,
    resource_id bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: batch_day_activity_batch_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.batch_day_activity ALTER COLUMN batch_activity_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.batch_day_activity_batch_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: batch_day_batch_day_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.batch_day ALTER COLUMN batch_day_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.batch_day_batch_day_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: batch_enrollment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_enrollment (
    enrollment_id bigint NOT NULL,
    batch_id bigint NOT NULL,
    trainee_id bigint NOT NULL,
    registration_mode character varying(10) NOT NULL,
    registered_at timestamp with time zone DEFAULT now() NOT NULL,
    registration_link_id bigint,
    registered_ip character varying(45),
    trainee_school_id integer,
    trainee_state_id integer,
    trainee_district_id integer,
    trainee_block_id integer,
    trainee_cluster_id integer,
    trainee_school_other character varying(200),
    approval_status character varying(10) DEFAULT 'PENDING'::character varying NOT NULL,
    approved_by bigint,
    approved_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: batch_enrollment_enrollment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.batch_enrollment ALTER COLUMN enrollment_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.batch_enrollment_enrollment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: batch_registration_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_registration_link (
    link_id bigint NOT NULL,
    batch_id bigint NOT NULL,
    token character varying(64) NOT NULL,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    max_registrations integer,
    registration_count integer DEFAULT 0 NOT NULL,
    scan_count integer DEFAULT 0 NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    revoked_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: batch_registration_link_link_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.batch_registration_link ALTER COLUMN link_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.batch_registration_link_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bulk_upload_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bulk_upload_log (
    upload_id bigint NOT NULL,
    upload_type character varying(20) NOT NULL,
    file_name character varying(255) NOT NULL,
    project_id integer,
    batch_id bigint,
    total_rows integer DEFAULT 0 NOT NULL,
    success_rows integer DEFAULT 0 NOT NULL,
    failed_rows integer DEFAULT 0 NOT NULL,
    status character varying(10) DEFAULT 'VALIDATED'::character varying NOT NULL,
    error_report_path character varying(500),
    uploaded_by bigint NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: bulk_upload_log_upload_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.bulk_upload_log ALTER COLUMN upload_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bulk_upload_log_upload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: certificate_record; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificate_record (
    certificate_id bigint NOT NULL,
    certificate_number character varying(40) NOT NULL,
    enrollment_id bigint NOT NULL,
    template_id integer NOT NULL,
    trainee_name character varying(150) NOT NULL,
    training_name character varying(200) NOT NULL,
    duration_days smallint NOT NULL,
    completion_date date NOT NULL,
    is_provisional boolean DEFAULT true NOT NULL,
    template_snapshot_json jsonb,
    issued_by bigint NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: certificate_record_certificate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.certificate_record ALTER COLUMN certificate_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.certificate_record_certificate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: certificate_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificate_template (
    template_id integer NOT NULL,
    template_code character varying(30) NOT NULL,
    project_id integer NOT NULL,
    program_name character varying(200) NOT NULL,
    signatory_name character varying(150) NOT NULL,
    colour_scheme character varying(7) DEFAULT '#17365D'::character varying NOT NULL,
    layout character varying(10) DEFAULT 'LANDSCAPE'::character varying NOT NULL,
    org_logo_path character varying(500),
    project_logo_path character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: certificate_template_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.certificate_template ALTER COLUMN template_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.certificate_template_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: completion_review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.completion_review (
    completion_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    attendance_pct numeric(5,2),
    assessment_score numeric(5,2),
    is_eligible boolean DEFAULT false NOT NULL,
    remarks character varying(300),
    reviewed_by bigint NOT NULL,
    reviewed_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: completion_review_completion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.completion_review ALTER COLUMN completion_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.completion_review_completion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: consent_record; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_record (
    consent_id bigint NOT NULL,
    trainee_id bigint NOT NULL,
    purpose character varying(30) NOT NULL,
    notice_version character varying(20) NOT NULL,
    channel character varying(10) NOT NULL,
    given_by character varying(10) DEFAULT 'SELF'::character varying NOT NULL,
    guardian_verified_at timestamp with time zone,
    consented_at timestamp with time zone DEFAULT now() NOT NULL,
    consent_ip character varying(45),
    withdrawn_at timestamp with time zone,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: consent_record_consent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.consent_record ALTER COLUMN consent_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.consent_record_consent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: data_subject_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_subject_request (
    request_id bigint NOT NULL,
    trainee_id bigint NOT NULL,
    request_type character varying(12) NOT NULL,
    details character varying(1000),
    status character varying(12) DEFAULT 'OPEN'::character varying NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    due_at date,
    handled_by bigint,
    closed_at timestamp with time zone,
    resolution character varying(1000),
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: data_subject_request_request_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.data_subject_request ALTER COLUMN request_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.data_subject_request_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: external_course_record; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_course_record (
    record_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    course_name character varying(200) NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: external_course_record_record_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.external_course_record ALTER COLUMN record_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.external_course_record_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: form_question; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.form_question (
    question_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    question_text character varying(1000) NOT NULL,
    expected_answer character varying(500),
    options_json jsonb,
    marks numeric(5,2) DEFAULT 100 NOT NULL,
    sort_order smallint DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: form_question_question_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.form_question ALTER COLUMN question_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.form_question_question_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: form_submission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.form_submission (
    submission_id bigint NOT NULL,
    enrollment_id bigint NOT NULL,
    question_id bigint NOT NULL,
    submitted_on date DEFAULT CURRENT_DATE NOT NULL,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    answer character varying(1000) NOT NULL,
    score numeric(5,2),
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: form_submission_submission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.form_submission ALTER COLUMN submission_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.form_submission_submission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: learning_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.learning_resource (
    resource_id bigint NOT NULL,
    resource_code character varying(30) NOT NULL,
    resource_name character varying(200) NOT NULL,
    resource_type character varying(10) NOT NULL,
    project_id integer,
    is_common boolean DEFAULT false NOT NULL,
    common_requested boolean DEFAULT false NOT NULL,
    file_name character varying(255),
    file_size_bytes bigint,
    mime_type character varying(100),
    storage_path character varying(500),
    form_type character varying(12),
    form_purpose character varying(30),
    duration_seconds integer,
    access_mode character varying(10) DEFAULT 'PLAN_ONLY'::character varying NOT NULL,
    uploaded_by bigint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: learning_resource_resource_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.learning_resource ALTER COLUMN resource_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.learning_resource_resource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_block; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_block (
    block_id integer NOT NULL,
    district_id integer NOT NULL,
    block_code character varying(10),
    block_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_block_block_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_block ALTER COLUMN block_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_block_block_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_cluster; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_cluster (
    cluster_id integer NOT NULL,
    district_id integer NOT NULL,
    block_id integer,
    cluster_code character varying(10),
    cluster_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_cluster_cluster_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_cluster ALTER COLUMN cluster_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_cluster_cluster_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_district; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_district (
    district_id integer NOT NULL,
    state_id integer NOT NULL,
    district_code character varying(10),
    district_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_district_district_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_district ALTER COLUMN district_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_district_district_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_holiday; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_holiday (
    holiday_id integer NOT NULL,
    holiday_name character varying(150) NOT NULL,
    holiday_date date NOT NULL,
    scope character varying(10) NOT NULL,
    state_id integer,
    district_id integer,
    project_id integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_holiday_holiday_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_holiday ALTER COLUMN holiday_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_holiday_holiday_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_module (
    module_id smallint NOT NULL,
    module_code character varying(40) NOT NULL,
    module_name character varying(80) NOT NULL,
    sort_order smallint DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_module_module_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_module ALTER COLUMN module_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_module_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_pii_field; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_pii_field (
    pii_field_id smallint NOT NULL,
    field_code character varying(50) NOT NULL,
    table_name character varying(50) NOT NULL,
    column_base character varying(50) NOT NULL,
    mask_rule character varying(15) NOT NULL,
    description character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_pii_field_pii_field_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_pii_field ALTER COLUMN pii_field_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_pii_field_pii_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_role (
    role_id smallint NOT NULL,
    role_code character varying(30) NOT NULL,
    role_name character varying(60) NOT NULL,
    role_rank smallint NOT NULL,
    role_category character varying(12) NOT NULL,
    data_scope character varying(10) NOT NULL,
    description character varying(300),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_role ALTER COLUMN role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_role_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_school; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_school (
    school_id integer NOT NULL,
    udise_code character varying(20) NOT NULL,
    school_name character varying(200) NOT NULL,
    state_id integer NOT NULL,
    district_id integer NOT NULL,
    block_id integer,
    cluster_id integer,
    actual_location character varying(300),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_school_school_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_school ALTER COLUMN school_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_school_school_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_stakeholder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_stakeholder (
    stakeholder_id integer NOT NULL,
    stakeholder_code character varying(30) NOT NULL,
    stakeholder_name character varying(200) NOT NULL,
    stakeholder_type character varying(15) DEFAULT 'OTHER'::character varying NOT NULL,
    description character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_stakeholder_stakeholder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_stakeholder ALTER COLUMN stakeholder_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_stakeholder_stakeholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.m_state (
    state_id integer NOT NULL,
    state_code character varying(10) NOT NULL,
    state_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: m_state_state_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.m_state ALTER COLUMN state_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m_state_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: odoo_project_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.odoo_project_catalog (
    catalog_id bigint NOT NULL,
    reference character varying(50) NOT NULL,
    project_name character varying(200) NOT NULL,
    sponsor_name character varying(200) NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: odoo_project_catalog_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.odoo_project_catalog ALTER COLUMN catalog_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.odoo_project_catalog_catalog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pii_access_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pii_access_log (
    pii_access_id bigint NOT NULL,
    user_id bigint NOT NULL,
    pii_field_id smallint NOT NULL,
    entity_id character varying(50) NOT NULL,
    action character varying(12) NOT NULL,
    purpose character varying(200),
    ip_address character varying(45),
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: pii_access_log_pii_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pii_access_log ALTER COLUMN pii_access_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pii_access_log_pii_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: plan_resource_day; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_resource_day (
    link_day_id bigint NOT NULL,
    link_id bigint NOT NULL,
    day_no smallint NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: plan_resource_day_link_day_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.plan_resource_day ALTER COLUMN link_day_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.plan_resource_day_link_day_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: plan_resource_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_resource_link (
    link_id bigint NOT NULL,
    plan_id integer NOT NULL,
    resource_id bigint NOT NULL,
    project_id integer,
    apply_existing boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: plan_resource_link_link_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.plan_resource_link ALTER COLUMN link_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.plan_resource_link_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: portal_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_collection (
    collection_key character varying(100) NOT NULL,
    table_name name NOT NULL,
    pk_column name NOT NULL,
    read_roles text[] NOT NULL,
    write_roles text[] NOT NULL
);


--
-- Name: portal_otp_challenge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_otp_challenge (
    challenge_id uuid NOT NULL,
    purpose character varying(20) NOT NULL,
    user_id bigint,
    recipient_hash character varying(64) NOT NULL,
    otp_hash character varying(64) NOT NULL,
    protected_payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    consumed_at timestamp with time zone,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL,
    locked_until timestamp with time zone,
    CONSTRAINT portal_otp_purpose_check CHECK (((purpose)::text = ANY ((ARRAY['LOGIN'::character varying, 'REGISTRATION'::character varying, 'RECOVERY'::character varying, 'PASSWORD_RESET'::character varying])::text[])))
);


--
-- Name: portal_recovery_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_recovery_request (
    request_id uuid NOT NULL,
    trainee_id bigint,
    otp_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    consumed_at timestamp with time zone,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: portal_setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_setting (
    portal_setting_id bigint NOT NULL,
    setting_key character varying(100) NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: portal_setting_portal_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.portal_setting ALTER COLUMN portal_setting_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.portal_setting_portal_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: profile_change_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profile_change_log (
    change_id bigint NOT NULL,
    user_id bigint NOT NULL,
    field_name character varying(30) NOT NULL,
    old_value_masked character varying(150),
    new_value_masked character varying(150),
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: profile_change_log_change_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.profile_change_log ALTER COLUMN change_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.profile_change_log_change_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project (
    project_id integer NOT NULL,
    project_code character varying(30) NOT NULL,
    project_name character varying(200) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    description character varying(1000),
    odoo_ref character varying(50),
    stakeholder_id integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: project_phase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_phase (
    phase_id bigint NOT NULL,
    project_id integer NOT NULL,
    phase_name character varying(200) NOT NULL,
    sequence_number integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(20) NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL,
    CONSTRAINT project_phase_check CHECK ((end_date >= start_date))
);


--
-- Name: project_phase_phase_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.project_phase ALTER COLUMN phase_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_phase_phase_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project_plan_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_plan_association (
    association_id bigint NOT NULL,
    project_id integer NOT NULL,
    plan_id integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: project_plan_association_association_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.project_plan_association ALTER COLUMN association_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_plan_association_association_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project_project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.project ALTER COLUMN project_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: registration_otp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_otp (
    otp_id bigint NOT NULL,
    batch_id bigint NOT NULL,
    mobile_enc bytea,
    mobile_hash character(64),
    mobile_mask character varying(150),
    email_enc bytea,
    email_hash character(64),
    email_mask character varying(150),
    pii_key_version smallint DEFAULT 1 NOT NULL,
    otp_hash character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attempt_count smallint DEFAULT 0 NOT NULL,
    verified_at timestamp with time zone,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: registration_otp_otp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.registration_otp ALTER COLUMN otp_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.registration_otp_otp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: resource_access_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_access_log (
    access_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    user_id bigint NOT NULL,
    accessed_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: resource_access_log_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.resource_access_log ALTER COLUMN access_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.resource_access_log_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: resource_audience; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_audience (
    audience_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    batch_id bigint,
    trainee_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: resource_audience_audience_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.resource_audience ALTER COLUMN audience_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.resource_audience_audience_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: resource_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_progress (
    progress_id bigint NOT NULL,
    trainee_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    first_viewed_at timestamp with time zone DEFAULT now() NOT NULL,
    last_viewed_at timestamp with time zone DEFAULT now() NOT NULL,
    last_position_seconds integer DEFAULT 0 NOT NULL,
    percent_viewed numeric(5,2) DEFAULT 0 NOT NULL,
    completed_at timestamp with time zone,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: resource_progress_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.resource_progress ALTER COLUMN progress_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.resource_progress_progress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: role_creation_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_creation_rule (
    rule_id integer NOT NULL,
    creator_role_id smallint NOT NULL,
    creatable_role_id smallint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: role_creation_rule_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.role_creation_rule ALTER COLUMN rule_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.role_creation_rule_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permission (
    role_permission_id integer NOT NULL,
    role_id smallint NOT NULL,
    module_id smallint NOT NULL,
    can_view boolean DEFAULT false NOT NULL,
    can_create boolean DEFAULT false NOT NULL,
    can_edit boolean DEFAULT false NOT NULL,
    can_delete boolean DEFAULT false NOT NULL,
    can_approve boolean DEFAULT false NOT NULL,
    can_export boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: role_permission_role_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.role_permission ALTER COLUMN role_permission_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.role_permission_role_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: role_pii_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_pii_permission (
    role_pii_id integer NOT NULL,
    role_id smallint NOT NULL,
    pii_field_id smallint NOT NULL,
    view_mode character varying(6) DEFAULT 'MASKED'::character varying NOT NULL,
    can_export_full boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: role_pii_permission_role_pii_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.role_pii_permission ALTER COLUMN role_pii_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.role_pii_permission_role_pii_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: school_eligibility; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_eligibility (
    eligibility_id bigint NOT NULL,
    school_id integer NOT NULL,
    project_id integer,
    beneficiary_type character varying(20) NOT NULL,
    eligible_count integer DEFAULT 0 NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL,
    CONSTRAINT school_eligibility_eligible_count_check CHECK ((eligible_count >= 0))
);


--
-- Name: school_eligibility_eligibility_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.school_eligibility ALTER COLUMN eligibility_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.school_eligibility_eligibility_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: system_setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_setting (
    setting_id integer NOT NULL,
    project_id integer,
    attendance_threshold_pct numeric(5,2),
    pass_score numeric(5,2),
    assessment_required boolean,
    feedback_required boolean,
    registration_window character varying(12) DEFAULT 'DAY1'::character varying NOT NULL,
    trainer_upload_allowed boolean DEFAULT false NOT NULL,
    propagate_resources boolean DEFAULT false NOT NULL,
    restrict_venue_to_scope boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: system_setting_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.system_setting ALTER COLUMN setting_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.system_setting_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: teacher_auth_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_auth_tokens (
    teacher_id integer NOT NULL,
    token_id character varying(32) NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teachers (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(254) NOT NULL,
    password_hash text NOT NULL,
    subject character varying(150) DEFAULT ''::character varying NOT NULL,
    phone_number character varying(30) DEFAULT ''::character varying NOT NULL,
    role character varying(20) DEFAULT 'Teacher'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT teachers_role_check CHECK (((role)::text = ANY ((ARRAY['Teacher'::character varying, 'Admin'::character varying])::text[])))
);


--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.teachers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.teachers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trainee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trainee (
    trainee_id bigint NOT NULL,
    trainee_code character varying(30) NOT NULL,
    full_name character varying(150) NOT NULL,
    mobile_enc bytea,
    mobile_hash character(64),
    mobile_mask character varying(150),
    email_enc bytea,
    email_hash character(64),
    email_mask character varying(150),
    pii_key_version smallint DEFAULT 1 NOT NULL,
    is_erased boolean DEFAULT false NOT NULL,
    erased_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: trainee_trainee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trainee ALTER COLUMN trainee_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trainee_trainee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trainer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trainer (
    trainer_id integer NOT NULL,
    trainer_code character varying(30) NOT NULL,
    trainer_name character varying(150) NOT NULL,
    category character varying(12) NOT NULL,
    mobile_enc bytea,
    mobile_hash character(64),
    mobile_mask character varying(150),
    email_enc bytea,
    email_hash character(64),
    email_mask character varying(150),
    pii_key_version smallint DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: trainer_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trainer_availability (
    availability_id integer NOT NULL,
    trainer_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: trainer_availability_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trainer_availability ALTER COLUMN availability_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trainer_availability_availability_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trainer_trainer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trainer ALTER COLUMN trainer_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trainer_trainer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: training_batch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.training_batch (
    batch_id bigint NOT NULL,
    batch_code character varying(30) NOT NULL,
    project_id integer NOT NULL,
    plan_id integer NOT NULL,
    school_id integer NOT NULL,
    reference_location character varying(300),
    actual_location character varying(300),
    start_date date NOT NULL,
    end_date date NOT NULL,
    capacity integer NOT NULL,
    trainer_id integer NOT NULL,
    open_registration boolean DEFAULT false NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    closed_at timestamp with time zone,
    plan_code_snapshot character varying(30),
    plan_snapshot_json jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: training_batch_batch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.training_batch ALTER COLUMN batch_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.training_batch_batch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: training_plan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.training_plan (
    plan_id integer NOT NULL,
    project_id integer,
    plan_code character varying(30) NOT NULL,
    plan_name character varying(200) NOT NULL,
    training_type character varying(15) NOT NULL,
    total_days smallint NOT NULL,
    description character varying(1000),
    status character varying(10) DEFAULT 'DRAFT'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: training_plan_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.training_plan_activity (
    activity_id bigint NOT NULL,
    plan_day_id bigint NOT NULL,
    seq_no smallint NOT NULL,
    activity_type character varying(12) NOT NULL,
    title character varying(200) NOT NULL,
    description character varying(1000),
    start_time time without time zone,
    duration_minutes smallint,
    resource_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: training_plan_activity_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.training_plan_activity ALTER COLUMN activity_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.training_plan_activity_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: training_plan_day; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.training_plan_day (
    plan_day_id bigint NOT NULL,
    plan_id integer NOT NULL,
    day_no smallint NOT NULL,
    day_title character varying(200) NOT NULL,
    objective character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: training_plan_day_plan_day_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.training_plan_day ALTER COLUMN plan_day_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.training_plan_day_plan_day_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: training_plan_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.training_plan ALTER COLUMN plan_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.training_plan_plan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_access_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_access_scope (
    scope_id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id integer,
    state_id integer,
    district_id integer,
    block_id integer,
    cluster_id integer,
    school_id integer,
    valid_from date,
    valid_to date,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: user_access_scope_scope_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.user_access_scope ALTER COLUMN scope_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_access_scope_scope_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_activity_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_activity_log (
    activity_id bigint NOT NULL,
    user_id bigint,
    login_id_tried character varying(30),
    activity_type character varying(20) NOT NULL,
    result character varying(10) NOT NULL,
    ip_address character varying(45),
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: user_activity_log_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.user_activity_log ALTER COLUMN activity_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_activity_log_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_pii_override; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_pii_override (
    override_id integer NOT NULL,
    user_id bigint NOT NULL,
    pii_field_id smallint NOT NULL,
    view_mode character varying(6) NOT NULL,
    reason character varying(300) NOT NULL,
    valid_from date,
    valid_to date,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp with time zone,
    updated_by bigint,
    external_id character varying(100),
    ui_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    portal_collection character varying(100),
    portal_project_id integer,
    portal_owner_user_id bigint,
    portal_batch_id bigint,
    row_version bigint DEFAULT 1 NOT NULL,
    portal_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: user_pii_override_override_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.user_pii_override ALTER COLUMN override_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_pii_override_override_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: v_school_geography; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_school_geography AS
 SELECT school.school_id,
    school.udise_code,
    school.school_name,
    school.actual_location,
    state.state_id,
    state.state_name,
    district.district_id,
    district.district_name,
    block.block_id,
    block.block_name,
    cluster.cluster_id,
    cluster.cluster_name
   FROM ((((public.m_school school
     JOIN public.m_state state ON ((state.state_id = school.state_id)))
     JOIN public.m_district district ON ((district.district_id = school.district_id)))
     LEFT JOIN public.m_block block ON ((block.block_id = school.block_id)))
     LEFT JOIN public.m_cluster cluster ON ((cluster.cluster_id = school.cluster_id)));


--
-- Name: v_batch_progress; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_batch_progress AS
 SELECT b.batch_id,
    b.external_id,
    b.batch_code,
    b.project_id,
    b.plan_id,
    b.school_id,
    b.trainer_id,
    b.start_date,
    b.end_date,
    b.ui_data,
    b.capacity,
    school.state_name,
    school.district_name,
    school.block_name,
    school.school_name,
    school.udise_code,
    trainer.trainer_name,
    plan.plan_name,
    ( SELECT count(*) AS count
           FROM public.batch_enrollment e
          WHERE ((e.batch_id = b.batch_id) AND (NOT e.portal_deleted) AND ((e.approval_status)::text <> 'REJECTED'::text))) AS registered_count,
    ( SELECT count(*) AS count
           FROM public.batch_enrollment e
          WHERE ((e.batch_id = b.batch_id) AND (NOT e.portal_deleted) AND ((e.approval_status)::text = 'APPROVED'::text))) AS approved_count,
    ( SELECT count(DISTINCT e.enrollment_id) AS count
           FROM (public.batch_enrollment e
             JOIN public.attendance a ON ((a.enrollment_id = e.enrollment_id)))
          WHERE ((e.batch_id = b.batch_id) AND (NOT e.portal_deleted) AND (NOT a.portal_deleted) AND ((a.status)::text = 'PRESENT'::text))) AS attended_count,
    ( SELECT count(DISTINCT e.enrollment_id) AS count
           FROM (public.batch_enrollment e
             JOIN public.completion_review c ON ((c.enrollment_id = e.enrollment_id)))
          WHERE ((e.batch_id = b.batch_id) AND (NOT e.portal_deleted) AND c.is_eligible)) AS completed_count,
    ( SELECT count(*) AS count
           FROM (public.batch_enrollment e
             JOIN public.certificate_record c ON ((c.enrollment_id = e.enrollment_id)))
          WHERE ((e.batch_id = b.batch_id) AND (NOT e.portal_deleted) AND (NOT c.portal_deleted) AND (COALESCE((c.ui_data ->> 'status'::text), 'Issued'::text) <> 'Revoked'::text))) AS certified_count,
    COALESCE(( SELECT ((100.0 * (count(*) FILTER (WHERE ((a.status)::text = 'PRESENT'::text)))::numeric) / (NULLIF(count(*), 0))::numeric)
           FROM (public.attendance a
             JOIN public.batch_enrollment e ON ((e.enrollment_id = a.enrollment_id)))
          WHERE ((e.batch_id = b.batch_id) AND (NOT a.portal_deleted) AND (NOT e.portal_deleted))), (0)::numeric) AS attendance_pct
   FROM (((public.training_batch b
     JOIN public.v_school_geography school ON ((school.school_id = b.school_id)))
     JOIN public.trainer trainer ON ((trainer.trainer_id = b.trainer_id)))
     JOIN public.training_plan plan ON ((plan.plan_id = b.plan_id)))
  WHERE ((NOT b.portal_deleted) AND (COALESCE((b.ui_data ->> 'status'::text), ''::text) <> ALL (ARRAY['Cancelled'::text, 'Archived'::text])));


--
-- Name: v_batch_schedule; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_batch_schedule AS
 SELECT b.batch_id,
    b.batch_code,
    day.batch_day_id,
    day.day_no,
    day.day_date,
    day.day_title,
    activity.seq_no,
    activity.activity_type,
    activity.title,
    activity.start_time,
    activity.duration_minutes,
    activity.resource_id
   FROM ((public.training_batch b
     JOIN public.batch_day day ON ((day.batch_id = b.batch_id)))
     LEFT JOIN public.batch_day_activity activity ON ((activity.batch_day_id = day.batch_day_id)))
  WHERE (NOT b.portal_deleted);


--
-- Name: v_project_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_project_status AS
SELECT
    NULL::integer AS project_id,
    NULL::character varying(30) AS project_code,
    NULL::character varying(200) AS project_name,
    NULL::date AS start_date,
    NULL::date AS end_date,
    NULL::text AS project_status,
    NULL::bigint AS batch_count;


--
-- Name: v_trainee_resource_access; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_trainee_resource_access AS
 SELECT DISTINCT e.trainee_id,
    e.batch_id,
    resource.resource_id
   FROM ((public.batch_enrollment e
     JOIN public.training_batch b ON ((b.batch_id = e.batch_id)))
     JOIN public.learning_resource resource ON ((NOT resource.portal_deleted)))
  WHERE ((NOT e.portal_deleted) AND ((e.approval_status)::text = 'APPROVED'::text) AND ((((resource.access_mode)::text = 'REPOSITORY'::text) AND (resource.is_common OR (resource.project_id = b.project_id))) OR (EXISTS ( SELECT 1
           FROM public.plan_resource_link link
          WHERE ((link.plan_id = b.plan_id) AND (link.resource_id = resource.resource_id) AND link.is_active))) OR (EXISTS ( SELECT 1
           FROM public.resource_audience audience
          WHERE ((audience.resource_id = resource.resource_id) AND audience.is_active AND ((audience.trainee_id = e.trainee_id) OR (audience.batch_id = b.batch_id)))))));


--
-- Name: v_trainer_assignment_history; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_trainer_assignment_history AS
 SELECT b.batch_id,
    b.batch_code,
    b.project_id,
    b.trainer_id,
    t.trainer_name,
    b.start_date,
    b.end_date,
    b.school_id,
    (b.ui_data ->> 'status'::text) AS batch_status
   FROM (public.training_batch b
     JOIN public.trainer t ON ((t.trainer_id = b.trainer_id)))
  WHERE (NOT b.portal_deleted);


--
-- Data for Name: app_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_user (user_id, login_id, full_name, role_id, email_enc, email_hash, email_mask, pii_key_version, mobile_enc, mobile_hash, mobile_mask, password_hash, must_change_password, failed_login_count, locked_until, last_login_at, stakeholder_id, parent_user_id, trainer_id, trainee_id, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
5	Demo5	Demo5	13	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEHUL4edLKTmdm49yYU2tGWx3XyYg825bVSYaHhq8seIIRyUINUTLwnO3pTyZPBmr1A==	f	0	\N	2026-10-27 17:16:55.189802+05:30	\N	\N	\N	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:16:55.189802+05:30	\N	Demo5	{"id": "Demo5", "role": "school-admin", "active": true, "userId": "Demo5"}	teacher-training-users	\N	5	\N	1	f
19	TR-5430D8AD810D	Sample registered teacher 1793100765860	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEKl+rd/Hv9jda+TTL8hPIePzM9KDOmLiSg4EIuAPWWwaU3KuSx/+iDMSnZyMEcQzMw==	t	0	\N	2026-10-27 17:02:46.858393+05:30	\N	\N	\N	5	t	2026-10-27 17:02:46.213911+05:30	\N	2026-10-27 17:02:46.858393+05:30	\N	ACCOUNT-e4da3b7fbbce2345d7772b0674a318d5	{"id": "TR-5430D8AD810D", "role": "trainee", "active": true, "userId": "TR-5430D8AD810D"}	teacher-training-users	\N	19	\N	1	f
7	Demo7	Demo7	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAECBmRotaiZ6rEZSrCA+vdq9M4U4MTLc0Ofh4KvsklE6pU21sInWjNQERs3smYB0Rhw==	f	0	\N	2026-10-27 17:18:52.724368+05:30	\N	\N	\N	1	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:18:52.724368+05:30	\N	Demo7	{"id": "Demo7", "role": "trainee", "active": true, "userId": "Demo7"}	teacher-training-users	\N	7	\N	1	f
17	TR-32707C0DF184	Sample OTP Trainee 37846807e0	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEHZJkARu3IByZO9g16I4VNFLP0aYY65uFenpEUsYOuqKmGEftHCp7W8LPOt/EOGqaQ==	t	0	\N	2026-10-27 17:00:44.233417+05:30	\N	\N	\N	3	t	2026-10-27 17:00:44.097113+05:30	\N	2026-10-27 17:00:44.233417+05:30	\N	TR-32707C0DF184	{"id": "TR-32707C0DF184", "role": "trainee", "active": true, "userId": "TR-32707C0DF184"}	teacher-training-users	\N	17	\N	1	f
22	TR-7E4A208E6C96	Sample registered teacher 1793101133035	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEGDw24AS6v775QrKg6Lj/NEbG8fXjB4eKYxB8a5cs5HkIP2jiqUuK3PlX3Qwe1GGIQ==	f	0	\N	2026-10-27 17:08:56.16481+05:30	\N	\N	\N	8	t	2026-10-27 17:08:53.407921+05:30	\N	2026-10-27 17:08:56.16481+05:30	\N	ACCOUNT-c9f0f895fb98ab9159f51fd0297e236d	{"id": "TR-7E4A208E6C96", "role": "trainee", "active": true, "userId": "TR-7E4A208E6C96"}	teacher-training-users	\N	22	\N	1	f
2	Demo2	Demo2	9	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEM73eK53xCcdfTZrA8CSh1goy3BePJuG1SOv0iTWizC10snXd+KiR6vDbQ8t4+UUAg==	f	0	\N	2026-10-27 17:16:36.71408+05:30	\N	\N	\N	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:16:36.71408+05:30	\N	Demo2	{"id": "Demo2", "role": "schoolnet-super-admin", "active": true, "userId": "Demo2"}	teacher-training-users	\N	2	\N	1	f
23	TR-D8BD7BE2B7A6	Sample OTP Trainee 27c6193462	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEINN2MVB9tI00C26Feb5e7B380TlaDPzgMJKihW6CP+bXs8aP4EkaDR/1DIAcj4ehQ==	f	0	\N	2026-10-27 17:14:24.030881+05:30	\N	\N	\N	9	t	2026-10-27 17:14:23.34919+05:30	\N	2026-10-27 17:14:24.030881+05:30	\N	ACCOUNT-45c48cce2e2d7fbdea1afc51c7c6ad26	{"id": "TR-D8BD7BE2B7A6", "role": "trainee", "active": true, "userId": "TR-D8BD7BE2B7A6"}	teacher-training-users	\N	23	\N	1	f
6	Demo6	Demo6	14	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEBpU3suqetzUZumgpNV0NXIZEg6klSPksRr6uZChS6CwColfHjyYv9ElMVz2zaYiTw==	f	0	\N	2026-10-27 17:16:59.320368+05:30	\N	\N	1	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:16:59.320368+05:30	\N	Demo6	{"id": "Demo6", "role": "trainer", "active": true, "userId": "Demo6"}	teacher-training-users	\N	6	\N	1	f
21	TR-082AB5DF4B64	Sample registered teacher 1793100963044	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEDER75hjTJncjd/nTJZ41vZx0FaNkiwX6Mo1Ah0UXFpgrc8xFyw5pYXhSYqu8ZyA2A==	f	0	\N	2026-10-27 17:06:04.038106+05:30	\N	\N	\N	7	t	2026-10-27 17:06:03.392696+05:30	\N	2026-10-27 17:06:05.411792+05:30	\N	ACCOUNT-8f14e45fceea167a5a36dedd4bea2543	{"id": "TR-082AB5DF4B64", "role": "trainee", "active": true, "userId": "TR-082AB5DF4B64"}	teacher-training-users	\N	21	\N	1	f
20	TR-17AFCB419633	Sample OTP Trainee aee362e923	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAECada2mvwSG0uOHWSs31ZZoo9JmOGNLdhtLsaxdyb6AA0FgFIcXSJn7mTQuXjZcwyQ==	f	0	\N	2026-10-27 17:05:47.708989+05:30	\N	\N	\N	6	t	2026-10-27 17:05:46.964267+05:30	\N	2026-10-27 17:05:47.708989+05:30	\N	ACCOUNT-1679091c5a880faf6fb5e6087eb1b2dc	{"id": "TR-17AFCB419633", "role": "trainee", "active": true, "userId": "TR-17AFCB419633"}	teacher-training-users	\N	20	\N	1	f
18	TR-DAA3F8A0E3D1	Sample OTP Trainee 9dcc2f5d02	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAECdOuxpqnXPKLSNk8CWu/QohOEPTP/LLW9odK3EMNEiUAdrZanVOYDFcXMknZ7P+Vg==	t	0	\N	2026-10-27 17:01:57.218705+05:30	\N	\N	\N	4	t	2026-10-27 17:01:57.033231+05:30	\N	2026-10-27 17:01:57.218705+05:30	\N	ACCOUNT-a87ff679a2f3e71d9181a67b7542122c	{"id": "TR-DAA3F8A0E3D1", "role": "trainee", "active": true, "userId": "TR-DAA3F8A0E3D1"}	teacher-training-users	\N	18	\N	1	f
24	TR-A7F6B65E6871	Sample registered teacher 1793101526960	15	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEHD6086sDvQMGBqGfoJGksvwLzmQI1lEptpjlqgEIZj57rt7qNbt/gKhd03wEkLHdA==	f	0	\N	2026-10-27 17:15:29.675535+05:30	\N	\N	\N	10	t	2026-10-27 17:15:27.351642+05:30	\N	2026-10-27 17:15:29.675535+05:30	\N	ACCOUNT-d3d9446802a44259755d38e6d163e820	{"id": "TR-A7F6B65E6871", "role": "trainee", "active": true, "userId": "TR-A7F6B65E6871"}	teacher-training-users	\N	24	\N	1	f
8	Demo8	Demo8	16	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEPVtrZiPRgqfuijCxJfxPe50McyXuTI77WcBnQtBTqpMMEGWCPPdxh9WDgo4JPFpvA==	f	0	\N	2026-10-27 17:17:08.982498+05:30	\N	\N	\N	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:17:08.982498+05:30	\N	Demo8	{"id": "Demo8", "role": "reporting-audit-user", "active": true, "userId": "Demo8"}	teacher-training-users	\N	8	\N	1	f
1	Demo1	Demo1	10	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEKa9/j02McYfh516lFOUJPTOncTwAm09Q6i1p+zytJ2V3u8hfkV1z/3f4WvmoWEGOQ==	f	0	\N	2026-10-27 17:21:08.412057+05:30	\N	\N	\N	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:21:08.412057+05:30	\N	Demo1	{"id": "Demo1", "role": "sponsor-admin", "active": true, "userId": "Demo1"}	teacher-training-users	\N	1	\N	1	f
3	Demo3	Demo3	11	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEPUbpTnc6Iz9WwWtivnc96vXWFZAN97n6d0rjX44Jpgu75HQnNLtcLyLb7geGOBorA==	f	0	\N	2026-10-27 17:16:46.226792+05:30	\N	\N	\N	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:16:46.226792+05:30	\N	Demo3	{"id": "Demo3", "role": "schoolnet-project-admin", "active": true, "userId": "Demo3"}	teacher-training-users	\N	3	\N	1	f
4	Demo4	Demo4	12	\N	\N	\N	1	\N	\N	\N	AQAAAAIAAYagAAAAEDyi4S0vRAzD9XBJWDijPFJBtXSDdnrExjWTaOVIeSmcBuaNYPdDjJ7rPH0N01xebg==	f	0	\N	2026-10-27 17:16:51.092429+05:30	\N	\N	\N	\N	t	2026-10-27 15:54:39.128723+05:30	\N	2026-10-27 17:16:51.092429+05:30	\N	Demo4	{"id": "Demo4", "role": "state-admin", "active": true, "userId": "Demo4"}	teacher-training-users	\N	4	\N	1	f
\.


--
-- Data for Name: assessment_attempt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assessment_attempt (attempt_id, enrollment_id, resource_id, kind, answers, score, max_marks, passed, submitted_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	4	8	assessment	{"q1": "0"}	1.00	1.00	t	2026-10-27 16:25:27.246254+05:30	TEST-ATTEMPT-d4496ff644	{"id": "TEST-ATTEMPT-d4496ff644", "day": 1, "kind": "assessment", "score": 1.00, "stage": "post", "formId": "TEST-FORM-d4496ff644", "passed": true, "status": "Passed", "userId": "Demo7", "answers": {"q1": "0"}, "batchId": "TEST-BATCH-d4496ff644", "grading": "graded", "maxMarks": 1.00, "planCode": "TST-d4496ff644", "batchCode": "TST-B-d4496ff644", "completed": true, "formTitle": "Integration assessment", "traineeId": "Demo7", "submittedAt": "2026-10-27T10:55:27.2454773Z", "registrationId": "TEST-REG-d4496ff644"}	teacher-training-assessment-records	1	7	3	2	t
2	4	9	feedback	{"q1": "0"}	\N	\N	\N	2026-10-27 16:25:28.193518+05:30	TEST-FEEDBACK-ATT-d4496ff644	{"id": "TEST-FEEDBACK-ATT-d4496ff644", "day": 1, "kind": "feedback", "score": null, "stage": "post", "formId": "TEST-FEEDBACK-d4496ff644", "passed": null, "status": "Submitted", "userId": "Demo7", "answers": {"q1": "0"}, "batchId": "TEST-BATCH-d4496ff644", "grading": "non-graded", "maxMarks": null, "planCode": "TST-d4496ff644", "batchCode": "TST-B-d4496ff644", "completed": true, "formTitle": "Integration assessment", "traineeId": "Demo7", "submittedAt": "2026-10-27T10:55:28.1930376Z", "registrationId": "TEST-REG-d4496ff644"}	teacher-training-feedback-records	1	7	3	2	t
3	5	10	assessment	{"q1": "0"}	1.00	1.00	t	2026-10-27 16:56:58.943364+05:30	TEST-ATTEMPT-e9519e0e3d	{"id": "TEST-ATTEMPT-e9519e0e3d", "day": 1, "kind": "assessment", "score": 1.00, "stage": "post", "formId": "TEST-FORM-e9519e0e3d", "passed": true, "status": "Passed", "userId": "Demo7", "answers": {"q1": "0"}, "batchId": "TEST-BATCH-e9519e0e3d", "grading": "graded", "maxMarks": 1.00, "planCode": "TST-e9519e0e3d", "batchCode": "TST-B-e9519e0e3d", "completed": true, "formTitle": "Integration assessment", "traineeId": "Demo7", "submittedAt": "2026-10-27T11:26:58.9429498Z", "registrationId": "TEST-REG-e9519e0e3d"}	teacher-training-assessment-records	1	7	4	2	t
4	5	11	feedback	{"q1": "0"}	\N	\N	\N	2026-10-27 16:56:59.710531+05:30	TEST-FEEDBACK-ATT-e9519e0e3d	{"id": "TEST-FEEDBACK-ATT-e9519e0e3d", "day": 1, "kind": "feedback", "score": null, "stage": "post", "formId": "TEST-FEEDBACK-e9519e0e3d", "passed": null, "status": "Submitted", "userId": "Demo7", "answers": {"q1": "0"}, "batchId": "TEST-BATCH-e9519e0e3d", "grading": "non-graded", "maxMarks": null, "planCode": "TST-e9519e0e3d", "batchCode": "TST-B-e9519e0e3d", "completed": true, "formTitle": "Integration assessment", "traineeId": "Demo7", "submittedAt": "2026-10-27T11:26:59.7100736Z", "registrationId": "TEST-REG-e9519e0e3d"}	teacher-training-feedback-records	1	7	4	2	t
5	12	12	assessment	{"q1": "0"}	1.00	1.00	t	2026-10-27 17:13:20.422545+05:30	TEST-ATTEMPT-92358f6105	{"id": "TEST-ATTEMPT-92358f6105", "day": 1, "kind": "assessment", "score": 1.00, "stage": "post", "formId": "TEST-FORM-92358f6105", "passed": true, "status": "Passed", "userId": "Demo7", "answers": {"q1": "0"}, "batchId": "TEST-BATCH-92358f6105", "grading": "graded", "maxMarks": 1.00, "planCode": "TST-92358f6105", "batchCode": "TST-B-92358f6105", "completed": true, "formTitle": "Integration assessment", "traineeId": "Demo7", "submittedAt": "2026-10-27T11:43:20.4221068Z", "attemptToken": "6e7bedaf-a99b-4de4-9520-50e8af76837b", "registrationId": "TEST-REG-92358f6105"}	teacher-training-assessment-records	1	7	5	2	t
6	12	13	feedback	{"q1": "0"}	\N	\N	\N	2026-10-27 17:13:21.177999+05:30	TEST-FEEDBACK-ATT-92358f6105	{"id": "TEST-FEEDBACK-ATT-92358f6105", "day": 1, "kind": "feedback", "score": null, "stage": "post", "formId": "TEST-FEEDBACK-92358f6105", "passed": null, "status": "Submitted", "userId": "Demo7", "answers": {"q1": "0"}, "batchId": "TEST-BATCH-92358f6105", "grading": "non-graded", "maxMarks": null, "planCode": "TST-92358f6105", "batchCode": "TST-B-92358f6105", "completed": true, "formTitle": "Integration assessment", "traineeId": "Demo7", "submittedAt": "2026-10-27T11:43:21.1775998Z", "attemptToken": "6e7bedaf-a99b-4de4-9520-50e8af76837b", "registrationId": "TEST-REG-92358f6105"}	teacher-training-feedback-records	1	7	5	2	t
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance (attendance_id, enrollment_id, attendance_date, status, source, marked_by, marked_at, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	2026-09-14	PRESENT	MANUAL	2	2026-10-27 15:54:39.845572+05:30	\N	\N	DEMO-SAMPLE-ATTENDANCE-1	{"id": "DEMO-SAMPLE-ATTENDANCE-1", "status": "Present", "userId": "Demo7", "batchId": "DEMO-SAMPLE-BATCH-PAST", "markedAt": "2026-09-14T10:00:00Z", "markedBy": "Demo6", "batchCode": "BATCH-DEMO-PAST", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-09-14"}	teacher-training-attendance-records	1	7	1	1	f
2	1	2026-09-15	PRESENT	MANUAL	2	2026-10-27 15:54:39.879692+05:30	\N	\N	DEMO-SAMPLE-ATTENDANCE-2	{"id": "DEMO-SAMPLE-ATTENDANCE-2", "status": "Present", "userId": "Demo7", "batchId": "DEMO-SAMPLE-BATCH-PAST", "markedAt": "2026-09-15T10:00:00Z", "markedBy": "Demo6", "batchCode": "BATCH-DEMO-PAST", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-09-15"}	teacher-training-attendance-records	1	7	1	1	f
3	1	2026-09-16	ABSENT	MANUAL	2	2026-10-27 15:54:39.913257+05:30	\N	\N	DEMO-SAMPLE-ATTENDANCE-3	{"id": "DEMO-SAMPLE-ATTENDANCE-3", "status": "Absent", "userId": "Demo7", "batchId": "DEMO-SAMPLE-BATCH-PAST", "markedAt": "2026-09-16T10:00:00Z", "markedBy": "Demo6", "batchCode": "BATCH-DEMO-PAST", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-09-16"}	teacher-training-attendance-records	1	7	1	1	f
4	4	2026-10-27	PRESENT	MANUAL	6	2026-10-27 16:25:26.44245+05:30	2026-10-27 17:17:11.869743+05:30	\N	TEST-ATT-d4496ff644	{"id": "TEST-ATT-d4496ff644", "status": "Present", "userId": "Demo7", "batchId": "TEST-BATCH-d4496ff644", "batchCode": "TST-B-d4496ff644", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-10-27"}	teacher-training-attendance-records	1	7	3	2	t
5	5	2026-10-27	PRESENT	MANUAL	6	2026-10-27 16:56:58.306587+05:30	2026-10-27 17:17:11.869743+05:30	\N	TEST-ATT-e9519e0e3d	{"id": "TEST-ATT-e9519e0e3d", "status": "Present", "userId": "Demo7", "batchId": "TEST-BATCH-e9519e0e3d", "batchCode": "TST-B-e9519e0e3d", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-10-27"}	teacher-training-attendance-records	1	7	4	2	t
6	12	2026-10-27	PRESENT	MANUAL	6	2026-10-27 17:13:19.672651+05:30	2026-10-27 17:17:11.869743+05:30	\N	TEST-ATT-92358f6105	{"id": "TEST-ATT-92358f6105", "status": "Present", "userId": "Demo7", "batchId": "TEST-BATCH-92358f6105", "batchCode": "TST-B-92358f6105", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-10-27"}	teacher-training-attendance-records	1	7	5	2	t
7	12	2026-10-26	PRESENT	MANUAL	6	2026-10-27 17:13:21.679301+05:30	2026-10-27 17:17:11.869743+05:30	\N	TEST-ATT-DAY1-92358f6105	{"id": "TEST-ATT-DAY1-92358f6105", "status": "Present", "userId": "Demo7", "batchId": "TEST-BATCH-92358f6105", "batchCode": "TST-B-92358f6105", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "trainingDate": "2026-10-26"}	teacher-training-attendance-records	1	7	5	2	t
\.


--
-- Data for Name: attendance_exclusion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_exclusion (exclusion_id, enrollment_id, training_date, reason, approved, changed_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (audit_id, occurred_at, actor_user_id, action, entity_type, entity_id, project_id, before_json, after_json, ip_address, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	2026-10-27 15:54:39.335634+05:30	2	CREATE	project	1	\N	\N	{"id": "DEMO-SAMPLE-PROJECT-001", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
2	2026-10-27 15:54:39.386965+05:30	2	CREATE	training_plan	1	\N	\N	{"id": "DEMO-SAMPLE-PLAN-001", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
3	2026-10-27 15:54:39.426721+05:30	2	CREATE	project_plan_association	1	1	\N	{"id": "DEMO-SAMPLE-ASSOCIATION-001", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
4	2026-10-27 15:54:39.461629+05:30	2	CREATE	trainer	1	\N	\N	{"id": "c8704cbb-2f66-4838-a18f-9b037a6e20b5", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
5	2026-10-27 15:54:39.495222+05:30	2	CREATE	trainer_availability	1	\N	\N	{"id": "DEMO-SAMPLE-AVAILABILITY-1", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
6	2026-10-27 15:54:39.531142+05:30	2	CREATE	trainer_availability	2	\N	\N	{"id": "DEMO-SAMPLE-AVAILABILITY-2", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
7	2026-10-27 15:54:39.567635+05:30	2	CREATE	trainer_availability	3	\N	\N	{"id": "DEMO-SAMPLE-AVAILABILITY-3", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
8	2026-10-27 15:54:39.604019+05:30	2	CREATE	training_batch	1	1	\N	{"id": "DEMO-SAMPLE-BATCH-PAST", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
9	2026-10-27 15:54:39.640732+05:30	2	CREATE	training_batch	2	1	\N	{"id": "DEMO-SAMPLE-BATCH-UPCOMING", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
10	2026-10-27 15:54:39.672381+05:30	2	CREATE	trainee	1	1	\N	{"id": "DEMO-SAMPLE-TRAINEE-007", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
11	2026-10-27 15:54:39.708823+05:30	2	CREATE	trainee	2	1	\N	{"id": "DEMO-SAMPLE-TRAINEE-008", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
12	2026-10-27 15:54:39.741307+05:30	2	CREATE	batch_enrollment	1	1	\N	{"id": "DEMO-SAMPLE-REG-COMPLETE", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
13	2026-10-27 15:54:39.779271+05:30	2	CREATE	batch_enrollment	2	1	\N	{"id": "DEMO-SAMPLE-REG-APPROVED", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
14	2026-10-27 15:54:39.812154+05:30	2	CREATE	batch_enrollment	3	1	\N	{"id": "DEMO-SAMPLE-REG-PENDING", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
15	2026-10-27 15:54:39.845572+05:30	2	CREATE	attendance	1	1	\N	{"id": "DEMO-SAMPLE-ATTENDANCE-1", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
16	2026-10-27 15:54:39.879692+05:30	2	CREATE	attendance	2	1	\N	{"id": "DEMO-SAMPLE-ATTENDANCE-2", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
17	2026-10-27 15:54:39.913257+05:30	2	CREATE	attendance	3	1	\N	{"id": "DEMO-SAMPLE-ATTENDANCE-3", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
18	2026-10-27 15:54:39.946272+05:30	2	CREATE	school_eligibility	1	1	\N	{"id": "DEMO-SAMPLE-ELIGIBLE-TEACHERS", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
19	2026-10-27 15:54:39.978722+05:30	2	CREATE	school_eligibility	2	1	\N	{"id": "DEMO-SAMPLE-ELIGIBLE-STUDENTS", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
20	2026-10-27 15:54:40.011432+05:30	2	CREATE	m_holiday	1	\N	\N	{"id": "DEMO-SAMPLE-HOLIDAY-NATIONAL", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
21	2026-10-27 15:54:40.047314+05:30	2	CREATE	m_holiday	2	\N	\N	{"id": "DEMO-SAMPLE-HOLIDAY-STATE", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
22	2026-10-27 15:54:40.07963+05:30	2	CREATE	portal_setting	1	1	\N	{"id": "DEMO-SAMPLE-SCHOOL-ASSIGNMENT", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
23	2026-10-27 16:09:54.773477+05:30	2	CREATE	learning_resource	1	\N	\N	{"id": "video", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
24	2026-10-27 16:09:54.819849+05:30	2	CREATE	learning_resource	2	\N	\N	{"id": "manual", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
25	2026-10-27 16:09:54.857896+05:30	2	CREATE	learning_resource	3	\N	\N	{"id": "presentation", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
26	2026-10-27 16:09:54.894751+05:30	2	CREATE	learning_resource	4	\N	\N	{"id": "guide", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
27	2026-10-27 16:09:54.933951+05:30	2	CREATE	learning_resource	5	\N	\N	{"id": "workflow", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
28	2026-10-27 16:09:54.969935+05:30	2	CREATE	odoo_project_catalog	1	\N	\N	{"id": "ODOO-PRJ-001", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
29	2026-10-27 16:09:55.010211+05:30	2	CREATE	odoo_project_catalog	2	\N	\N	{"id": "ODOO-PRJ-002", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
30	2026-10-27 16:09:55.054596+05:30	2	CREATE	certificate_template	1	\N	\N	{"id": "offline", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
31	2026-10-27 16:09:55.091798+05:30	2	CREATE	certificate_template	2	\N	\N	{"id": "online", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
32	2026-10-27 16:09:55.129129+05:30	2	CREATE	certificate_template	3	\N	\N	{"id": "hybrid", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
33	2026-10-27 16:09:55.165585+05:30	2	CREATE	learning_resource	6	\N	\N	{"id": "DEMO-FORM-assessment", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
34	2026-10-27 16:09:55.205588+05:30	2	CREATE	learning_resource	7	\N	\N	{"id": "DEMO-FORM-feedback", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
35	2026-10-27 16:22:12.662971+05:30	2	CREATE	project	2	\N	\N	{"id": "TEST-PROJECT-7813160dd8", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
36	2026-10-27 16:25:25.204374+05:30	2	CREATE	project	3	\N	\N	{"id": "TEST-PROJECT-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
37	2026-10-27 16:25:25.475174+05:30	2	DELETE	project	3	3	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
38	2026-10-27 16:25:25.627936+05:30	2	CREATE	training_plan	2	\N	\N	{"id": "TEST-PLAN-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
39	2026-10-27 16:25:25.78426+05:30	2	CREATE	project_plan_association	2	1	\N	{"id": "TEST-ASSOC-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
40	2026-10-27 16:25:25.934544+05:30	2	CREATE	training_batch	3	1	\N	{"id": "TEST-BATCH-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
41	2026-10-27 16:25:26.216112+05:30	2	CREATE	batch_enrollment	4	1	\N	{"id": "TEST-REG-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
42	2026-10-27 16:25:26.44245+05:30	6	CREATE	attendance	4	1	\N	{"id": "TEST-ATT-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
43	2026-10-27 16:25:26.923846+05:30	2	CREATE	learning_resource	8	\N	\N	{"id": "TEST-FORM-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
44	2026-10-27 16:25:27.246254+05:30	7	CREATE	assessment_attempt	1	1	\N	{"id": "TEST-ATTEMPT-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
45	2026-10-27 16:25:27.887273+05:30	2	CREATE	learning_resource	9	\N	\N	{"id": "TEST-FEEDBACK-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
46	2026-10-27 16:25:28.193518+05:30	7	CREATE	assessment_attempt	2	1	\N	{"id": "TEST-FEEDBACK-ATT-d4496ff644", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
47	2026-10-27 16:25:28.514249+05:30	2	UPDATE	training_batch	3	1	{"id": "TEST-BATCH-d4496ff644", "version": 1}	{"id": "TEST-BATCH-d4496ff644", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
48	2026-10-27 16:56:56.636593+05:30	2	CREATE	project	4	\N	\N	{"id": "TEST-PROJECT-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
49	2026-10-27 16:56:57.058209+05:30	2	DELETE	project	4	4	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
50	2026-10-27 16:56:57.283691+05:30	2	CREATE	training_plan	3	\N	\N	{"id": "TEST-PLAN-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
51	2026-10-27 16:56:57.534457+05:30	2	CREATE	project_plan_association	3	1	\N	{"id": "TEST-ASSOC-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
52	2026-10-27 16:56:57.799884+05:30	2	CREATE	training_batch	4	1	\N	{"id": "TEST-BATCH-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
53	2026-10-27 16:56:58.056397+05:30	2	CREATE	batch_enrollment	5	1	\N	{"id": "TEST-REG-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
54	2026-10-27 16:56:58.306587+05:30	6	CREATE	attendance	5	1	\N	{"id": "TEST-ATT-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
55	2026-10-27 16:56:58.680952+05:30	2	CREATE	learning_resource	10	\N	\N	{"id": "TEST-FORM-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
56	2026-10-27 16:56:58.943364+05:30	7	CREATE	assessment_attempt	3	1	\N	{"id": "TEST-ATTEMPT-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
57	2026-10-27 16:56:59.477078+05:30	2	CREATE	learning_resource	11	\N	\N	{"id": "TEST-FEEDBACK-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
58	2026-10-27 16:56:59.710531+05:30	7	CREATE	assessment_attempt	4	1	\N	{"id": "TEST-FEEDBACK-ATT-e9519e0e3d", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
59	2026-10-27 16:57:00.038706+05:30	2	UPDATE	training_batch	4	1	{"id": "TEST-BATCH-e9519e0e3d", "version": 1}	{"id": "TEST-BATCH-e9519e0e3d", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
60	2026-10-27 17:00:44.097113+05:30	\N	SELF_REGISTER	batch_enrollment	6	1	\N	{"registrationId": "REG-704f18bf6e3c76175e0ab06837d15c7a"}	\N	\N	{}	\N	\N	\N	\N	1	f
61	2026-10-27 17:00:44.375355+05:30	2	UPDATE	batch_enrollment	6	1	{"id": "REG-704f18bf6e3c76175e0ab06837d15c7a", "version": 1}	{"id": "REG-704f18bf6e3c76175e0ab06837d15c7a", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
62	2026-10-27 17:01:57.033231+05:30	\N	SELF_REGISTER	batch_enrollment	7	1	\N	{"registrationId": "REG-8ff0e4d1b3a77e93f538ad9e7346b967"}	\N	\N	{}	\N	\N	\N	\N	1	f
63	2026-10-27 17:01:57.390007+05:30	2	UPDATE	batch_enrollment	7	1	{"id": "REG-8ff0e4d1b3a77e93f538ad9e7346b967", "version": 1}	{"id": "REG-8ff0e4d1b3a77e93f538ad9e7346b967", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
64	2026-10-27 17:02:44.954445+05:30	2	CREATE	training_plan	4	\N	\N	{"id": "e10eb5c6-ed0f-499d-8e97-9e1b1d583a4a", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
65	2026-10-27 17:02:46.213911+05:30	\N	SELF_REGISTER	batch_enrollment	8	1	\N	{"registrationId": "REG-b28a5c634cb7038784df85e8f6ccd034"}	\N	\N	{}	\N	\N	\N	\N	1	f
66	2026-10-27 17:05:46.964267+05:30	\N	SELF_REGISTER	batch_enrollment	9	1	\N	{"registrationId": "REG-7f1c5f9326718c7aacf8516256f9a374"}	\N	\N	{}	\N	\N	\N	\N	1	f
67	2026-10-27 17:05:47.27393+05:30	2	UPDATE	batch_enrollment	9	1	{"id": "REG-7f1c5f9326718c7aacf8516256f9a374", "version": 1}	{"id": "REG-7f1c5f9326718c7aacf8516256f9a374", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
68	2026-10-27 17:06:02.157465+05:30	2	CREATE	training_plan	5	\N	\N	{"id": "2a2b50db-5146-430d-a230-1acd50587491", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
69	2026-10-27 17:06:03.392696+05:30	\N	SELF_REGISTER	batch_enrollment	10	1	\N	{"registrationId": "REG-722eb42d7bc1627e0c2fcae661f4a41b"}	\N	\N	{}	\N	\N	\N	\N	1	f
70	2026-10-27 17:08:52.114338+05:30	2	CREATE	training_plan	6	\N	\N	{"id": "63287176-647a-45d6-903f-ce85d82a194f", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
71	2026-10-27 17:08:53.407921+05:30	\N	SELF_REGISTER	batch_enrollment	11	1	\N	{"registrationId": "REG-a1c02f9e037b0b5a8ad5ea8dacc49d6f"}	\N	\N	{}	\N	\N	\N	\N	1	f
72	2026-10-27 17:13:18.009519+05:30	2	CREATE	project	5	\N	\N	{"id": "TEST-PROJECT-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
73	2026-10-27 17:13:18.473441+05:30	2	DELETE	project	5	5	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
74	2026-10-27 17:13:18.687602+05:30	2	CREATE	training_plan	7	\N	\N	{"id": "TEST-PLAN-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
75	2026-10-27 17:13:18.916232+05:30	2	CREATE	project_plan_association	4	1	\N	{"id": "TEST-ASSOC-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
76	2026-10-27 17:13:19.146519+05:30	2	CREATE	training_batch	5	1	\N	{"id": "TEST-BATCH-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
77	2026-10-27 17:13:19.389255+05:30	2	CREATE	batch_enrollment	12	1	\N	{"id": "TEST-REG-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
78	2026-10-27 17:13:19.672651+05:30	6	CREATE	attendance	6	1	\N	{"id": "TEST-ATT-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
79	2026-10-27 17:13:20.094705+05:30	2	CREATE	learning_resource	12	\N	\N	{"id": "TEST-FORM-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
80	2026-10-27 17:13:20.422545+05:30	7	CREATE	assessment_attempt	5	1	\N	{"id": "TEST-ATTEMPT-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
81	2026-10-27 17:13:20.924863+05:30	2	CREATE	learning_resource	13	\N	\N	{"id": "TEST-FEEDBACK-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
82	2026-10-27 17:13:21.177999+05:30	7	CREATE	assessment_attempt	6	1	\N	{"id": "TEST-FEEDBACK-ATT-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
83	2026-10-27 17:13:21.679301+05:30	6	CREATE	attendance	7	1	\N	{"id": "TEST-ATT-DAY1-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
84	2026-10-27 17:13:21.949386+05:30	2	CREATE	certificate_record	1	1	\N	{"id": "TEST-CERT-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
85	2026-10-27 17:13:22.191435+05:30	2	UPDATE	certificate_record	1	1	{"id": "TEST-CERT-92358f6105", "version": 1}	{"id": "TEST-CERT-92358f6105", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
86	2026-10-27 17:13:22.191435+05:30	2	CREATE	certificate_record	2	1	\N	{"id": "TEST-CERT-REISSUE-92358f6105", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
87	2026-10-27 17:13:22.449084+05:30	2	UPDATE	certificate_record	2	1	{"id": "TEST-CERT-REISSUE-92358f6105", "version": 1}	{"id": "TEST-CERT-REISSUE-92358f6105", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
88	2026-10-27 17:13:22.674731+05:30	2	UPDATE	training_batch	5	1	{"id": "TEST-BATCH-92358f6105", "version": 1}	{"id": "TEST-BATCH-92358f6105", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
89	2026-10-27 17:14:23.34919+05:30	\N	SELF_REGISTER	batch_enrollment	13	1	\N	{"registrationId": "REG-e1056615ef28e9067e2ff508e05acc4e"}	\N	\N	{}	\N	\N	\N	\N	1	f
90	2026-10-27 17:14:23.614872+05:30	2	UPDATE	batch_enrollment	13	1	{"id": "REG-e1056615ef28e9067e2ff508e05acc4e", "version": 1}	{"id": "REG-e1056615ef28e9067e2ff508e05acc4e", "version": 2}	\N	\N	{}	\N	\N	\N	\N	1	f
91	2026-10-27 17:15:26.084598+05:30	2	CREATE	training_plan	8	\N	\N	{"id": "5c4b02e0-6b82-4c3b-befa-9723f8d73012", "version": 1}	\N	\N	{}	\N	\N	\N	\N	1	f
92	2026-10-27 17:15:27.351642+05:30	\N	SELF_REGISTER	batch_enrollment	14	1	\N	{"registrationId": "REG-3067461e35a2a02dfa2db2a68e3a54df"}	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: batch_day; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_day (batch_day_id, batch_id, day_no, day_date, day_title, objective, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	1	2026-09-14	Day 1	\N	\N	{}	\N	\N	\N	\N	1	f
2	1	2	2026-09-15	Day 2	\N	\N	{}	\N	\N	\N	\N	1	f
3	1	3	2026-09-16	Day 3	\N	\N	{}	\N	\N	\N	\N	1	f
4	2	1	2026-11-10	Day 1	\N	\N	{}	\N	\N	\N	\N	1	f
5	2	2	2026-11-11	Day 2	\N	\N	{}	\N	\N	\N	\N	1	f
6	2	3	2026-11-12	Day 3	\N	\N	{}	\N	\N	\N	\N	1	f
7	3	1	2026-10-26	Day 1	\N	\N	{}	\N	\N	\N	\N	1	f
8	3	2	2026-10-27	Day 2	\N	\N	{}	\N	\N	\N	\N	1	f
11	4	1	2026-10-26	Day 1	\N	\N	{}	\N	\N	\N	\N	1	f
12	4	2	2026-10-27	Day 2	\N	\N	{}	\N	\N	\N	\N	1	f
15	5	1	2026-10-26	Day 1	\N	\N	{}	\N	\N	\N	\N	1	f
16	5	2	2026-10-27	Day 2	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: batch_day_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_day_activity (batch_activity_id, batch_day_id, seq_no, activity_type, title, description, start_time, duration_minutes, resource_id, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: batch_enrollment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_enrollment (enrollment_id, batch_id, trainee_id, registration_mode, registered_at, registration_link_id, registered_ip, trainee_school_id, trainee_state_id, trainee_district_id, trainee_block_id, trainee_cluster_id, trainee_school_other, approval_status, approved_by, approved_at, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	1	SELF	2026-10-27 15:54:39.741307+05:30	\N	\N	1	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 15:54:39.740597+05:30	t	2026-10-27 15:54:39.741307+05:30	\N	\N	\N	DEMO-SAMPLE-REG-COMPLETE	{"id": "DEMO-SAMPLE-REG-COMPLETE", "name": "Sample Trainee", "source": "Sample data", "status": "Approved", "userId": "Demo7", "batchId": "DEMO-SAMPLE-BATCH-PAST", "approved": true, "category": "Teacher", "_contacts": {"email": {"tag": "uI0PEaQ0MwxSFvn0QXXC4w==", "data": "cc7wrHJ+CbIu/KTvhA8n/0++uNXcxFOWxg==", "hash": "42f43cae0104cab1939b117cb06dafd9b616803f722f3898d097fb2c47212e10", "mask": "d*****@example.org", "salt": "T8nXeXHGPDp/ZEU1IRBDgw==", "nonce": "/33dFrY1YWkVX48u"}, "phone": {"tag": "JrRscVYzzQbuw9y+eCvzRQ==", "data": "A90X7CIgjE35Jgxb7rUJ", "hash": "0923a2c2a3a01123e26a5697d9e6369f34f7fa944f61742d9634695e1e14917b", "mask": "+9***********07", "salt": "e0UM8EkYBfDMvn/QRIQoHQ==", "nonce": "MAphJd0PLeCRjEig"}}, "batchCode": "BATCH-DEMO-PAST", "completed": true, "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "reviewedAt": "2026-08-02T09:00:00Z", "reviewedBy": "Demo6", "submittedAt": "2026-08-01T09:00:00Z", "submittedBy": "Demo7", "traineeName": "Sample Trainee", "approvalStatus": "Approved", "consentProvided": true, "registrationStatus": "Approved"}	teacher-training-registrations	1	7	1	1	f
2	2	1	SELF	2026-10-27 15:54:39.779271+05:30	\N	\N	1	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 15:54:39.778624+05:30	t	2026-10-27 15:54:39.779271+05:30	\N	\N	\N	DEMO-SAMPLE-REG-APPROVED	{"id": "DEMO-SAMPLE-REG-APPROVED", "name": "Sample Trainee", "source": "Sample data", "status": "Approved", "userId": "Demo7", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "approved": true, "category": "Teacher", "_contacts": {"email": {"tag": "lzN5bCrrW7jrkYZn7zqMkw==", "data": "o6dMfwMuqyOgs3aDGhPf0cUzoRlTxqmDmQ==", "hash": "42f43cae0104cab1939b117cb06dafd9b616803f722f3898d097fb2c47212e10", "mask": "d*****@example.org", "salt": "Jtj7v2uz+ZlaBkpomDWPuw==", "nonce": "TfoAleEqvHlbMWPN"}, "phone": {"tag": "3Gr3DFWTzicMRnZQym5DAA==", "data": "9e1qQ4L2+gEGGEQ17ZTO", "hash": "0923a2c2a3a01123e26a5697d9e6369f34f7fa944f61742d9634695e1e14917b", "mask": "+9***********07", "salt": "yWAlGuHSa4jQqw5/g90J0g==", "nonce": "NtsyLIX/jhQOoNBg"}}, "batchCode": "BATCH-DEMO-NOV", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "reviewedAt": "2026-10-13T09:00:00Z", "reviewedBy": "Demo6", "submittedAt": "2026-10-12T09:00:00Z", "submittedBy": "Demo7", "traineeName": "Sample Trainee", "approvalStatus": "Approved", "consentProvided": true, "registrationStatus": "Approved"}	teacher-training-registrations	1	7	2	1	f
3	2	2	SELF	2026-10-27 15:54:39.812154+05:30	\N	\N	1	\N	\N	\N	\N	\N	PENDING	\N	\N	t	2026-10-27 15:54:39.812154+05:30	\N	\N	\N	DEMO-SAMPLE-REG-PENDING	{"id": "DEMO-SAMPLE-REG-PENDING", "name": "Sample Teacher Two", "source": "Sample data", "status": "Pending", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "approved": false, "category": "Teacher", "_contacts": {"email": {"tag": "s9y21fg889nn1JgkroMJdQ==", "data": "fsf1YWTPt1OLxpKGhejBvWaNHnK3YUQ=", "hash": "acb6e1e4e44ad7416294807d76c7c268e396f852accd467f167202ed62212c9a", "mask": "t*****@example.org", "salt": "xHNWUa8s9SO58jqB0MGvaA==", "nonce": "Rc/BoU5W4u+tABzW"}, "phone": {"tag": "gkjMPBb1R9C0v5/S53Ci7Q==", "data": "AXis3I3uFi5i53b8yEMg", "hash": "9f749c1dde4a599de5b0bacfb85bb36e162572c1ea084c758f6ae84cc760f89a", "mask": "+9***********08", "salt": "25yr8xfrQN/y9RvicR5lfg==", "nonce": "DtdpG/ZSWauOscvY"}}, "batchCode": "BATCH-DEMO-NOV", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-008", "submittedAt": "2026-10-20T09:00:00Z", "submittedBy": "Demo7", "traineeName": "Sample Teacher Two", "approvalStatus": "Pending", "consentProvided": true, "registrationStatus": "Pending"}	teacher-training-registrations	1	\N	2	1	f
6	2	3	SELF	2026-10-27 17:00:44.097113+05:30	\N	\N	\N	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 17:00:44.374793+05:30	t	2026-10-27 17:00:44.097113+05:30	\N	2026-10-27 17:01:34.235374+05:30	\N	REG-704f18bf6e3c76175e0ab06837d15c7a	{"id": "REG-704f18bf6e3c76175e0ab06837d15c7a", "name": "Sample OTP Trainee 37846807e0", "status": "Approved", "userId": "TR-32707C0DF184", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "approved": true, "category": "Teacher", "_contacts": {"email": {"tag": "6ZwZFvvAATDdURvZlOUZzg==", "data": "c67ZdH3WH4hb0RRIBt9JJhtAF/W71bwQZbbo", "hash": "d078670711f74e837594741f1860abe02df3ce9753bf4dd2c4e10e2ddc460b5e", "mask": "o*****@example.test", "salt": "smkum9ZutsDGDCdegF+PrQ==", "nonce": "uISX2TWk2Pu3d7g8"}, "phone": {"tag": "KoU7bxk/rYbYaRyx3uCu5w==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "+0FOVbXPVSYtXn2FBFxysQ==", "nonce": "Y7F0pdqgpQK6zvLs"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:30:44.059457Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-32707C0DF184", "submittedAt": "2026-10-27T17:00:44.097113+05:30", "traineeName": "Sample OTP Trainee 37846807e0", "approvalStatus": "Approved", "registrationStatus": "Pending"}	teacher-training-registrations	1	17	2	3	f
4	3	1	SELF	2026-10-27 16:25:26.216112+05:30	\N	\N	1	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 16:25:26.215458+05:30	t	2026-10-27 16:25:26.216112+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-REG-d4496ff644	{"id": "TEST-REG-d4496ff644", "name": "Sample Trainee", "source": "Integration verification", "status": "Approved", "userId": "Demo7", "batchId": "TEST-BATCH-d4496ff644", "approved": true, "batchCode": "TST-B-d4496ff644", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "approvalStatus": "Approved", "consentProvided": true}	teacher-training-registrations	1	7	3	2	t
5	4	1	SELF	2026-10-27 16:56:58.056397+05:30	\N	\N	1	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 16:56:58.05597+05:30	t	2026-10-27 16:56:58.056397+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-REG-e9519e0e3d	{"id": "TEST-REG-e9519e0e3d", "name": "Sample Trainee", "source": "Integration verification", "status": "Approved", "userId": "Demo7", "batchId": "TEST-BATCH-e9519e0e3d", "approved": true, "batchCode": "TST-B-e9519e0e3d", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "approvalStatus": "Approved", "consentProvided": true}	teacher-training-registrations	1	7	4	2	t
7	2	4	SELF	2026-10-27 17:01:57.033231+05:30	\N	\N	\N	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 17:01:57.387757+05:30	t	2026-10-27 17:01:57.033231+05:30	\N	2026-10-27 17:01:57.390007+05:30	\N	REG-8ff0e4d1b3a77e93f538ad9e7346b967	{"id": "REG-8ff0e4d1b3a77e93f538ad9e7346b967", "name": "Sample OTP Trainee 9dcc2f5d02", "status": "Approved", "userId": "TR-DAA3F8A0E3D1", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "approved": true, "category": "Teacher", "_contacts": {"email": {"tag": "butkF7b36s0EwnhdlLakIA==", "data": "D3AYmBXv15vcdiak8uYDPSQD23rJJ5QKG7bh", "hash": "96daa7fdcd78c5dfe60266bd35509dc82c968448fa090272bb948d99641d67e0", "mask": "o*****@example.test", "salt": "7M0XeZzGbm/1KbpzRGmmGQ==", "nonce": "uIDi2N5Gbi9mbdb+"}, "phone": {"tag": "zHizPihbFg8+1zpXY0vipg==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "80yjBI3uTnQin9NNLQr4NA==", "nonce": "wdEjNWA04lui01qJ"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:31:56.989418Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-DAA3F8A0E3D1", "submittedAt": "2026-10-27T17:01:57.033231+05:30", "traineeName": "Sample OTP Trainee 9dcc2f5d02", "approvalStatus": "Approved", "registrationStatus": "Pending"}	teacher-training-registrations	1	18	2	2	f
8	2	5	SELF	2026-10-27 17:02:46.213911+05:30	\N	\N	\N	\N	\N	\N	\N	\N	PENDING	\N	\N	t	2026-10-27 17:02:46.213911+05:30	\N	\N	\N	REG-b28a5c634cb7038784df85e8f6ccd034	{"id": "REG-b28a5c634cb7038784df85e8f6ccd034", "name": "Sample registered teacher 1793100765860", "status": "Pending", "userId": "TR-5430D8AD810D", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "category": "Teacher", "_contacts": {"email": {"tag": "uvOutv4Tp4P9CKjO5Ik0NQ==", "data": "h2rn2/QIgD2i8LtSqpIjfM2XjTKR8MqnF9qiTBANEqgvAQ==", "hash": "603945f23dfea3633a7fbb53b741c10d9504736aae1c6670fe8d1a675b021345", "mask": "b*****@example.test", "salt": "glQSWLEG1euf5LMGIQ4y1A==", "nonce": "POLDiEBNYc11PXmj"}, "phone": {"tag": "TIFZt2WmyfhcZFiv8hkMuA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "OyUUu1g/11R3KihNna9Unw==", "nonce": "aBIuBvxegF7E6NEo"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:32:46.1723926Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-5430D8AD810D", "submittedAt": "2026-10-27T17:02:46.213911+05:30", "traineeName": "Sample registered teacher 1793100765860", "registrationStatus": "Pending"}	teacher-training-registrations	1	19	2	1	f
9	2	6	SELF	2026-10-27 17:05:46.964267+05:30	\N	\N	\N	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 17:05:47.27252+05:30	t	2026-10-27 17:05:46.964267+05:30	\N	2026-10-27 17:05:47.27393+05:30	\N	REG-7f1c5f9326718c7aacf8516256f9a374	{"id": "REG-7f1c5f9326718c7aacf8516256f9a374", "name": "Sample OTP Trainee aee362e923", "status": "Approved", "userId": "TR-17AFCB419633", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "approved": true, "category": "Teacher", "_contacts": {"email": {"tag": "zSVY7aKCwOydGrnRUUeYCQ==", "data": "Q1eFK6eJDRchNc+EIwWF/p48jPVz2BA7C6KS", "hash": "5e7178f4f22b99cf4e4caf49c06b050b203070e03f33365b39c2517d9ae5dfd2", "mask": "o*****@example.test", "salt": "dh0mIHh37Q/vEVKmpzzhCQ==", "nonce": "ECmImd0qlVzUB/ie"}, "phone": {"tag": "0hrvKbEg4Z44TWkWNQg/Jw==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "S2zYwBjj0xQ464/+fP3Ctg==", "nonce": "SUyCVKOR4vgPuQ95"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:35:46.9253377Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-17AFCB419633", "submittedAt": "2026-10-27T17:05:46.964267+05:30", "traineeName": "Sample OTP Trainee aee362e923", "approvalStatus": "Approved", "registrationStatus": "Pending"}	teacher-training-registrations	1	20	2	2	f
10	2	7	SELF	2026-10-27 17:06:03.392696+05:30	\N	\N	\N	\N	\N	\N	\N	\N	PENDING	\N	\N	t	2026-10-27 17:06:03.392696+05:30	\N	\N	\N	REG-722eb42d7bc1627e0c2fcae661f4a41b	{"id": "REG-722eb42d7bc1627e0c2fcae661f4a41b", "name": "Sample registered teacher 1793100963044", "status": "Pending", "userId": "TR-082AB5DF4B64", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "category": "Teacher", "_contacts": {"email": {"tag": "y6CDzjdRvhXD0sMh1wLSvw==", "data": "MKN+bnLq4xjoHjNXGHtS67QWnt5TdN4HOnHqMi0giKHhOw==", "hash": "9554140a056141b6ff398fbae54eabfe199e264c3ec79bcfa213eb54672822c8", "mask": "b*****@example.test", "salt": "G6mT9whlSRwMEhtUSx9wqA==", "nonce": "EY5C9P+eClgodhYA"}, "phone": {"tag": "r7HIdQ6aioBlpEWuwfC+rA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "At5WJxh114AftTPWVTGt4g==", "nonce": "xI8OUh1Otb91wTfo"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:36:03.3539977Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-082AB5DF4B64", "submittedAt": "2026-10-27T17:06:03.392696+05:30", "traineeName": "Sample registered teacher 1793100963044", "registrationStatus": "Pending"}	teacher-training-registrations	1	21	2	1	f
11	2	8	SELF	2026-10-27 17:08:53.407921+05:30	\N	\N	\N	\N	\N	\N	\N	\N	PENDING	\N	\N	t	2026-10-27 17:08:53.407921+05:30	\N	\N	\N	REG-a1c02f9e037b0b5a8ad5ea8dacc49d6f	{"id": "REG-a1c02f9e037b0b5a8ad5ea8dacc49d6f", "name": "Sample registered teacher 1793101133035", "status": "Pending", "userId": "TR-7E4A208E6C96", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "category": "Teacher", "_contacts": {"email": {"tag": "yGXO76NcHb7Epc4UBMUJrw==", "data": "Xsjv7NBAgOYadnxREA44VUvxxYvOSZxgRV3BkKsimKGncg==", "hash": "257cb7a422ff14da0ce1b4dbf86db43a488a778d803fd6d2f7bff88d6cf52da7", "mask": "b*****@example.test", "salt": "YNM0Gl43iQDNm46G5Xnd9A==", "nonce": "q77L+HVsR5ZnE5Ah"}, "phone": {"tag": "poSw4SeroEtoHJrQNcDJBA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "W+B1Nsf2pB/Z0w1cFN5+Aw==", "nonce": "/BGFK9gzctZPhhCv"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:38:53.3657713Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-7E4A208E6C96", "submittedAt": "2026-10-27T17:08:53.407921+05:30", "traineeName": "Sample registered teacher 1793101133035", "registrationStatus": "Pending"}	teacher-training-registrations	1	22	2	1	f
12	5	1	SELF	2026-10-27 17:13:19.389255+05:30	\N	\N	1	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 17:13:19.388716+05:30	t	2026-10-27 17:13:19.389255+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-REG-92358f6105	{"id": "TEST-REG-92358f6105", "name": "Sample Trainee", "source": "Integration verification", "status": "Approved", "userId": "Demo7", "batchId": "TEST-BATCH-92358f6105", "approved": true, "batchCode": "TST-B-92358f6105", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "traineeName": "Sample Trainee", "approvalStatus": "Approved", "consentProvided": true}	teacher-training-registrations	1	7	5	2	t
13	2	9	SELF	2026-10-27 17:14:23.34919+05:30	\N	\N	\N	\N	\N	\N	\N	\N	APPROVED	2	2026-10-27 17:14:23.614311+05:30	t	2026-10-27 17:14:23.34919+05:30	\N	2026-10-27 17:14:23.614872+05:30	\N	REG-e1056615ef28e9067e2ff508e05acc4e	{"id": "REG-e1056615ef28e9067e2ff508e05acc4e", "name": "Sample OTP Trainee 27c6193462", "status": "Approved", "userId": "TR-D8BD7BE2B7A6", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "approved": true, "category": "Teacher", "_contacts": {"email": {"tag": "6J3N8BI46AxCCyGBYF7h3w==", "data": "860UnDvQPaCL229Db6iQNlTSKrthBborz+W+", "hash": "14c7634f7638055bfda1d4389af46e67fafaf19ec0d899be201f4478613b9fb3", "mask": "o*****@example.test", "salt": "vf91GUymaLcxHiJgLNPb7A==", "nonce": "344aCjwtyMbA4u+Q"}, "phone": {"tag": "H8cMu3LHidVhuZ9Cn+OLUw==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "iQNgWh5j4uL3zEudq448yg==", "nonce": "C4t34pUz4TNXDvkq"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:44:23.3109757Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-D8BD7BE2B7A6", "submittedAt": "2026-10-27T17:14:23.34919+05:30", "traineeName": "Sample OTP Trainee 27c6193462", "approvalStatus": "Approved", "consentProvided": true, "registrationStatus": "Pending"}	teacher-training-registrations	1	23	2	2	f
14	2	10	SELF	2026-10-27 17:15:27.351642+05:30	\N	\N	\N	\N	\N	\N	\N	\N	PENDING	\N	\N	t	2026-10-27 17:15:27.351642+05:30	\N	\N	\N	REG-3067461e35a2a02dfa2db2a68e3a54df	{"id": "REG-3067461e35a2a02dfa2db2a68e3a54df", "name": "Sample registered teacher 1793101526960", "status": "Pending", "userId": "TR-A7F6B65E6871", "batchId": "DEMO-SAMPLE-BATCH-UPCOMING", "category": "Teacher", "_contacts": {"email": {"tag": "+dK7L9m+WmtWJAb2e06eTQ==", "data": "QF6kmxzkLDky7Evbtx0ss0eE2aGvPFAAGQb1EL+vohS08g==", "hash": "9ab1959d6548b7d62aa5bfde11be5d0e5bc5fc9c20cfa273111e67b067aaaead", "mask": "b*****@example.test", "salt": "zz5bD1hv6hVPcjPjHl7uPA==", "nonce": "EFHbLHoyjuvO+PiO"}, "phone": {"tag": "B6UnrAchnZlP110C1WBqIA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "RDTij4mydyXIq6rnu1ZMhA==", "nonce": "tGKuCfssyz586f/K"}}, "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-10-27T11:45:27.3094253Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "TR-A7F6B65E6871", "submittedAt": "2026-10-27T17:15:27.351642+05:30", "traineeName": "Sample registered teacher 1793101526960", "consentProvided": true, "registrationStatus": "Pending"}	teacher-training-registrations	1	24	2	1	f
\.


--
-- Data for Name: batch_registration_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_registration_link (link_id, batch_id, token, valid_from, valid_until, max_registrations, registration_count, scan_count, is_revoked, revoked_at, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: bulk_upload_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bulk_upload_log (upload_id, upload_type, file_name, project_id, batch_id, total_rows, success_rows, failed_rows, status, error_report_path, uploaded_by, uploaded_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: certificate_record; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificate_record (certificate_id, certificate_number, enrollment_id, template_id, trainee_name, training_name, duration_days, completion_date, is_provisional, template_snapshot_json, issued_by, issued_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	CERT-HYB-2026-0001	12	3	Sample Trainee	Integration plan	2	2026-10-27	f	{"id": "hybrid", "mode": "Hybrid", "_dbId": 3, "title": "Hybrid Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "_ownerId": null, "_version": 1, "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-HYB-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}	2	2026-10-27 17:13:21.949386+05:30	TEST-CERT-92358f6105	{"id": "TEST-CERT-92358f6105", "reason": "", "status": "Reissued", "userId": "Demo7", "batchId": "TEST-BATCH-92358f6105", "issuedAt": "2026-10-27T11:43:21.9484728Z", "issuedBy": "Demo2", "batchCode": "TST-B-92358f6105", "projectId": "DEMO-SAMPLE-PROJECT-001", "revokedAt": "2026-10-27T11:43:22.1905528Z", "revokedBy": "Demo2", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "projectName": "Digital Teaching Improvement Project", "traineeName": "Sample Trainee", "templateMode": "Hybrid", "registrationId": "TEST-REG-92358f6105", "trainingEndDate": "2026-10-27", "templateSnapshot": {"id": "hybrid", "mode": "Hybrid", "_dbId": 3, "title": "Hybrid Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "_ownerId": null, "_version": 1, "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-HYB-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}, "trainingPlanName": "Integration plan", "certificateNumber": "CERT-HYB-2026-0001", "trainingStartDate": "2026-10-26"}	teacher-training-certificates	1	7	5	3	t
2	CERT-HYB-2026-0002	12	3	Sample Trainee	Integration plan	2	2026-10-27	f	{"id": "hybrid", "mode": "Hybrid", "_dbId": 3, "title": "Hybrid Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "_ownerId": null, "_version": 1, "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-HYB-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}	2	2026-10-27 17:13:22.191435+05:30	TEST-CERT-REISSUE-92358f6105	{"id": "TEST-CERT-REISSUE-92358f6105", "reason": "Integration verification cleanup", "status": "Revoked", "userId": "Demo7", "batchId": "TEST-BATCH-92358f6105", "issuedAt": "2026-10-27T11:43:22.1908697Z", "issuedBy": "Demo2", "batchCode": "TST-B-92358f6105", "projectId": "DEMO-SAMPLE-PROJECT-001", "reissueOf": "TEST-CERT-92358f6105", "revokedAt": "2026-10-27T11:43:22.4487166Z", "revokedBy": "Demo2", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "projectName": "Digital Teaching Improvement Project", "traineeName": "Sample Trainee", "templateMode": "Hybrid", "registrationId": "TEST-REG-92358f6105", "trainingEndDate": "2026-10-27", "templateSnapshot": {"id": "hybrid", "mode": "Hybrid", "_dbId": 3, "title": "Hybrid Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "_ownerId": null, "_version": 1, "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-HYB-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}, "trainingPlanName": "Integration plan", "certificateNumber": "CERT-HYB-2026-0002", "trainingStartDate": "2026-10-26"}	teacher-training-certificates	1	7	5	3	t
\.


--
-- Data for Name: certificate_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificate_template (template_id, template_code, project_id, program_name, signatory_name, colour_scheme, layout, org_logo_path, project_logo_path, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	offline	1	Offline Training Completion Certificate	Authorized Signatory	#173f68	LANDSCAPE	\N	\N	t	2026-10-27 16:09:55.054596+05:30	\N	\N	\N	offline	{"id": "offline", "mode": "Offline", "title": "Offline Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-OFF-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}	teacher-training-certificate-templates	\N	\N	\N	1	f
2	online	1	Online Training Completion Certificate	Authorized Signatory	#173f68	LANDSCAPE	\N	\N	t	2026-10-27 16:09:55.091798+05:30	\N	\N	\N	online	{"id": "online", "mode": "Online", "title": "Online Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-ONL-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}	teacher-training-certificate-templates	\N	\N	\N	1	f
3	hybrid	1	Hybrid Training Completion Certificate	Authorized Signatory	#173f68	LANDSCAPE	\N	\N	t	2026-10-27 16:09:55.129129+05:30	\N	\N	\N	hybrid	{"id": "hybrid", "mode": "Hybrid", "title": "Hybrid Training Completion Certificate", "accent": "#c79535", "primary": "#173f68", "sponsor": "ERNET", "wording": "This is to certify that {{traineeName}} has successfully completed {{trainingPlan}} through {{trainingMode}} training held from {{startDate}} to {{endDate}}.", "signatory": "Authorized Signatory", "sponsorName": "ERNET India", "numberFormat": "CERT-HYB-{YYYY}-{####}", "requiredDetails": ["Trainee name", "Training plan", "Training mode", "Training dates", "Organization / school", "Certificate number", "Issue date"]}	teacher-training-certificate-templates	\N	\N	\N	1	f
\.


--
-- Data for Name: completion_review; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.completion_review (completion_id, enrollment_id, attendance_pct, assessment_score, is_eligible, remarks, reviewed_by, reviewed_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	12	\N	\N	t	Completion rules verified by the application service.	2	2026-10-27 17:13:22.449084+05:30	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: consent_record; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consent_record (consent_id, trainee_id, purpose, notice_version, channel, given_by, guardian_verified_at, consented_at, consent_ip, withdrawn_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	TRAINING_ENROLMENT	1.0	ADMIN	SELF	\N	2026-10-27 15:54:39.741307+05:30	\N	\N	\N	{}	\N	\N	\N	\N	1	f
2	2	TRAINING_ENROLMENT	1.0	ADMIN	SELF	\N	2026-10-27 15:54:39.812154+05:30	\N	\N	\N	{}	\N	\N	\N	\N	1	f
3	9	TRAINING_REGISTRATION	1.0	WEB	SELF	\N	2026-10-27 17:14:23.34919+05:30	\N	\N	\N	{}	\N	\N	\N	\N	1	f
4	9	TRAINING_ENROLMENT	1.0	ADMIN	SELF	\N	2026-10-27 17:14:23.614872+05:30	\N	\N	\N	{}	\N	\N	\N	\N	1	f
5	10	TRAINING_REGISTRATION	1.0	WEB	SELF	\N	2026-10-27 17:15:27.351642+05:30	\N	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: data_subject_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_subject_request (request_id, trainee_id, request_type, details, status, received_at, due_at, handled_by, closed_at, resolution, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: external_course_record; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_course_record (record_id, enrollment_id, course_name, completed, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: form_question; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.form_question (question_id, resource_id, question_text, expected_answer, options_json, marks, sort_order, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	6	Which action supports active learning?	0	["Discussion and practice", "Passive listening only"]	1.00	1	t	2026-10-27 16:09:55.165585+05:30	2	\N	\N	DEMO-FORM-assessment:q1	{"id": "q1", "points": 1, "prompt": "Which action supports active learning?", "options": ["Discussion and practice", "Passive listening only"], "required": true, "correctIndex": 0}	\N	\N	\N	\N	1	f
2	7	How useful was this training?	\N	["Very useful", "Useful", "Needs improvement"]	0.00	1	t	2026-10-27 16:09:55.205588+05:30	2	\N	\N	DEMO-FORM-feedback:q1	{"id": "q1", "points": 0, "prompt": "How useful was this training?", "options": ["Very useful", "Useful", "Needs improvement"], "required": true, "correctIndex": null}	\N	\N	\N	\N	1	f
3	8	Choose the correct option	0	["Correct", "Wrong"]	1.00	1	t	2026-10-27 16:25:26.923846+05:30	2	\N	\N	TEST-FORM-d4496ff644:q1	{"id": "q1", "points": 1, "prompt": "Choose the correct option", "options": ["Correct", "Wrong"], "required": true, "correctIndex": 0}	\N	\N	\N	\N	1	f
4	9	Was it useful?	\N	["Yes", "No"]	0.00	1	t	2026-10-27 16:25:27.887273+05:30	2	\N	\N	TEST-FEEDBACK-d4496ff644:q1	{"id": "q1", "points": 0, "prompt": "Was it useful?", "options": ["Yes", "No"], "required": true}	\N	\N	\N	\N	1	f
5	10	Choose the correct option	0	["Correct", "Wrong"]	1.00	1	t	2026-10-27 16:56:58.680952+05:30	2	\N	\N	TEST-FORM-e9519e0e3d:q1	{"id": "q1", "points": 1, "prompt": "Choose the correct option", "options": ["Correct", "Wrong"], "required": true, "correctIndex": 0}	\N	\N	\N	\N	1	f
6	11	Was it useful?	\N	["Yes", "No"]	0.00	1	t	2026-10-27 16:56:59.477078+05:30	2	\N	\N	TEST-FEEDBACK-e9519e0e3d:q1	{"id": "q1", "points": 0, "prompt": "Was it useful?", "options": ["Yes", "No"], "required": true}	\N	\N	\N	\N	1	f
7	12	Choose the correct option	0	["Correct", "Wrong"]	1.00	1	t	2026-10-27 17:13:20.094705+05:30	2	\N	\N	TEST-FORM-92358f6105:q1	{"id": "q1", "points": 1, "prompt": "Choose the correct option", "options": ["Correct", "Wrong"], "required": true, "correctIndex": 0}	\N	\N	\N	\N	1	f
8	13	Was it useful?	\N	["Yes", "No"]	0.00	1	t	2026-10-27 17:13:20.924863+05:30	2	\N	\N	TEST-FEEDBACK-92358f6105:q1	{"id": "q1", "points": 0, "prompt": "Was it useful?", "options": ["Yes", "No"], "required": true}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: form_submission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.form_submission (submission_id, enrollment_id, question_id, submitted_on, submitted_at, answer, score, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	4	3	2026-10-27	2026-10-27 16:25:27.246254+05:30	0	1.00	\N	{}	\N	\N	\N	\N	1	f
2	4	4	2026-10-27	2026-10-27 16:25:28.193518+05:30	0	\N	\N	{}	\N	\N	\N	\N	1	f
3	5	5	2026-10-27	2026-10-27 16:56:58.943364+05:30	0	1.00	\N	{}	\N	\N	\N	\N	1	f
4	5	6	2026-10-27	2026-10-27 16:56:59.710531+05:30	0	\N	\N	{}	\N	\N	\N	\N	1	f
5	12	7	2026-10-27	2026-10-27 17:13:20.422545+05:30	0	1.00	\N	{}	\N	\N	\N	\N	1	f
6	12	8	2026-10-27	2026-10-27 17:13:21.177999+05:30	0	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: learning_resource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.learning_resource (resource_id, resource_code, resource_name, resource_type, project_id, is_common, common_requested, file_name, file_size_bytes, mime_type, storage_path, form_type, form_purpose, duration_seconds, access_mode, uploaded_by, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	video	Digital classroom training	MP4	\N	t	f	sample-training-video.mp4	\N	\N	sample-training-video.mp4	\N	\N	\N	REPOSITORY	2	t	2026-10-27 16:09:54.773477+05:30	\N	\N	\N	video	{"id": "video", "file": "sample-training-video.mp4", "size": "19 KB", "tags": ["Training"], "title": "Digital classroom training", "format": "MP4", "category": "Video", "language": "English", "storagePath": "sample-training-video.mp4"}	teacher-training-learning-resources	\N	\N	\N	1	f
2	manual	Teacher training manual	PDF	\N	t	f	sample-training-manual.pdf	\N	\N	sample-training-manual.pdf	\N	\N	\N	REPOSITORY	2	t	2026-10-27 16:09:54.819849+05:30	\N	\N	\N	manual	{"id": "manual", "file": "sample-training-manual.pdf", "size": "1 KB", "tags": ["Training"], "title": "Teacher training manual", "format": "PDF", "category": "Documents", "language": "English", "storagePath": "sample-training-manual.pdf"}	teacher-training-learning-resources	\N	\N	\N	1	f
3	presentation	Teacher training presentation	PPTX	\N	t	f	sample-training.pptx	\N	\N	sample-training.pptx	\N	\N	\N	REPOSITORY	2	t	2026-10-27 16:09:54.857896+05:30	\N	\N	\N	presentation	{"id": "presentation", "file": "sample-training.pptx", "size": "27 KB", "tags": ["Training"], "title": "Teacher training presentation", "format": "PPTX", "category": "Presentation", "language": "English", "storagePath": "sample-training.pptx"}	teacher-training-learning-resources	\N	\N	\N	1	f
4	guide	Teacher training guide	DOCX	\N	t	f	sample-training-guide.docx	\N	\N	sample-training-guide.docx	\N	\N	\N	REPOSITORY	2	t	2026-10-27 16:09:54.894751+05:30	\N	\N	\N	guide	{"id": "guide", "file": "sample-training-guide.docx", "size": "35 KB", "tags": ["Training"], "title": "Teacher training guide", "format": "DOCX", "category": "Documents", "language": "English", "storagePath": "sample-training-guide.docx"}	teacher-training-learning-resources	\N	\N	\N	1	f
5	workflow	Educator onboarding workflow	WORKFLOW	\N	t	f	educator-onboarding-workflow.json	\N	\N	educator-onboarding-workflow.json	\N	\N	\N	REPOSITORY	2	t	2026-10-27 16:09:54.933951+05:30	\N	\N	\N	workflow	{"id": "workflow", "file": "educator-onboarding-workflow.json", "size": "0 KB", "tags": ["Training"], "title": "Educator onboarding workflow", "format": "WORKFLOW", "category": "Documents", "language": "English", "storagePath": "educator-onboarding-workflow.json"}	teacher-training-learning-resources	\N	\N	\N	1	f
6	DEMO-FORM-assessment	Digital teaching assessment	FORM	\N	t	f	\N	\N	\N	\N	ASSESSMENT	POST_ASSESSMENT	\N	REPOSITORY	2	t	2026-10-27 16:09:55.165585+05:30	\N	\N	\N	DEMO-FORM-assessment	{"id": "DEMO-FORM-assessment", "day": 1, "kind": "assessment", "stage": "post", "title": "Digital teaching assessment", "source": "native", "grading": "graded", "maxMarks": 1, "planCode": "TP-DEMO-001", "createdAt": "2026-10-27T10:39:55.164496Z", "mandatory": false, "passMarks": 1, "questions": [{"id": "q1", "points": 1, "prompt": "Which action supports active learning?", "options": ["Discussion and practice", "Passive listening only"], "required": true, "correctIndex": 0}], "comparable": true, "attemptLimit": 3, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	1	f
7	DEMO-FORM-feedback	Training feedback	FORM	\N	t	f	\N	\N	\N	\N	FEEDBACK	DAILY_FEEDBACK	\N	REPOSITORY	2	t	2026-10-27 16:09:55.205588+05:30	\N	\N	\N	DEMO-FORM-feedback	{"id": "DEMO-FORM-feedback", "day": 1, "kind": "feedback", "stage": "feedback", "title": "Training feedback", "source": "native", "grading": "non-graded", "maxMarks": 0, "planCode": "TP-DEMO-001", "createdAt": "2026-10-27T10:39:55.2050629Z", "mandatory": false, "passMarks": 0, "questions": [{"id": "q1", "points": 0, "prompt": "How useful was this training?", "options": ["Very useful", "Useful", "Needs improvement"], "required": true, "correctIndex": null}], "comparable": false, "attemptLimit": 3, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	1	f
9	TEST-FEEDBACK-d4496ff644	Integration feedback	FORM	\N	t	f	\N	\N	\N	\N	FEEDBACK	DAILY_FEEDBACK	\N	REPOSITORY	2	t	2026-10-27 16:25:27.887273+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-FEEDBACK-d4496ff644	{"id": "TEST-FEEDBACK-d4496ff644", "day": 1, "kind": "feedback", "stage": "feedback", "title": "Integration feedback", "source": "native", "grading": "non-graded", "maxMarks": 1, "planCode": "TST-d4496ff644", "createdAt": "2026-10-27T10:55:26.826Z", "mandatory": true, "passMarks": 0, "questions": [{"id": "q1", "points": 0, "prompt": "Was it useful?", "options": ["Yes", "No"], "required": true}], "comparable": true, "attemptLimit": 1, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	2	t
8	TEST-FORM-d4496ff644	Integration assessment	FORM	\N	t	f	\N	\N	\N	\N	ASSESSMENT	POST_ASSESSMENT	\N	REPOSITORY	2	t	2026-10-27 16:25:26.923846+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-FORM-d4496ff644	{"id": "TEST-FORM-d4496ff644", "day": 1, "kind": "assessment", "stage": "post", "title": "Integration assessment", "source": "native", "grading": "graded", "maxMarks": 1, "planCode": "TST-d4496ff644", "createdAt": "2026-10-27T10:55:26.826Z", "mandatory": true, "passMarks": 1, "questions": [{"id": "q1", "points": 1, "prompt": "Choose the correct option", "options": ["Correct", "Wrong"], "required": true, "correctIndex": 0}], "comparable": true, "attemptLimit": 1, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	2	t
10	TEST-FORM-e9519e0e3d	Integration assessment	FORM	\N	t	f	\N	\N	\N	\N	ASSESSMENT	POST_ASSESSMENT	\N	REPOSITORY	2	t	2026-10-27 16:56:58.680952+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-FORM-e9519e0e3d	{"id": "TEST-FORM-e9519e0e3d", "day": 1, "kind": "assessment", "stage": "post", "title": "Integration assessment", "source": "native", "grading": "graded", "maxMarks": 1, "planCode": "TST-e9519e0e3d", "createdAt": "2026-10-27T11:26:58.606Z", "mandatory": true, "passMarks": 1, "questions": [{"id": "q1", "points": 1, "prompt": "Choose the correct option", "options": ["Correct", "Wrong"], "required": true, "correctIndex": 0}], "comparable": true, "attemptLimit": 1, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	2	t
11	TEST-FEEDBACK-e9519e0e3d	Integration feedback	FORM	\N	t	f	\N	\N	\N	\N	FEEDBACK	DAILY_FEEDBACK	\N	REPOSITORY	2	t	2026-10-27 16:56:59.477078+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-FEEDBACK-e9519e0e3d	{"id": "TEST-FEEDBACK-e9519e0e3d", "day": 1, "kind": "feedback", "stage": "feedback", "title": "Integration feedback", "source": "native", "grading": "non-graded", "maxMarks": 1, "planCode": "TST-e9519e0e3d", "createdAt": "2026-10-27T11:26:58.606Z", "mandatory": true, "passMarks": 0, "questions": [{"id": "q1", "points": 0, "prompt": "Was it useful?", "options": ["Yes", "No"], "required": true}], "comparable": true, "attemptLimit": 1, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	2	t
12	TEST-FORM-92358f6105	Integration assessment	FORM	\N	t	f	\N	\N	\N	\N	ASSESSMENT	POST_ASSESSMENT	\N	REPOSITORY	2	t	2026-10-27 17:13:20.094705+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-FORM-92358f6105	{"id": "TEST-FORM-92358f6105", "day": 1, "kind": "assessment", "stage": "post", "title": "Integration assessment", "source": "native", "grading": "graded", "maxMarks": 1, "planCode": "TST-92358f6105", "createdAt": "2026-10-27T11:43:20.008Z", "mandatory": true, "passMarks": 1, "questions": [{"id": "q1", "points": 1, "prompt": "Choose the correct option", "options": ["Correct", "Wrong"], "required": true, "correctIndex": 0}], "timeLimit": 1, "comparable": true, "attemptLimit": 1, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	2	t
13	TEST-FEEDBACK-92358f6105	Integration feedback	FORM	\N	t	f	\N	\N	\N	\N	FEEDBACK	DAILY_FEEDBACK	\N	REPOSITORY	2	t	2026-10-27 17:13:20.924863+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-FEEDBACK-92358f6105	{"id": "TEST-FEEDBACK-92358f6105", "day": 1, "kind": "feedback", "stage": "feedback", "title": "Integration feedback", "source": "native", "grading": "non-graded", "maxMarks": 1, "planCode": "TST-92358f6105", "createdAt": "2026-10-27T11:43:20.008Z", "mandatory": true, "passMarks": 0, "questions": [{"id": "q1", "points": 0, "prompt": "Was it useful?", "options": ["Yes", "No"], "required": true}], "timeLimit": 0, "comparable": true, "attemptLimit": 1, "allowUnanswered": false}	teacher-training-assessment-form-master	\N	\N	\N	2	t
\.


--
-- Data for Name: m_block; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_block (block_id, district_id, block_code, block_name, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	\N	Burja	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
2	1	\N	Etcherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
3	1	\N	G.sigadam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
4	1	\N	Gara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
5	1	\N	Ichapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
6	1	\N	Jalumuru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
7	1	\N	Kanchili	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
8	1	\N	Kotabommali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
9	1	\N	L.n Peta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
10	1	\N	Laveru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
11	1	\N	Meliaputti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
12	1	\N	Nandigam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
13	1	\N	Polaki	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
14	1	\N	Ponduru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
15	1	\N	Ranasthalam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
16	1	\N	Santhabomma Li	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
17	1	\N	Saravakota	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
18	1	\N	Sompeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
19	1	\N	Srikakulam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
20	2	\N	Garugubilli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
21	2	\N	Gummalakshm Ipuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
22	2	\N	Jiyyammavala Sa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
23	2	\N	Komarada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
24	2	\N	Kurupam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
25	2	\N	Makkuva	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
26	2	\N	Pachipenta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
27	2	\N	Seethampeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
28	2	\N	Seethanagara M	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
29	3	\N	Bhogapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
30	3	\N	Bobbili	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
31	3	\N	Cheepurupalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
32	3	\N	Denkada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
33	3	\N	Gantyada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
34	3	\N	Garividi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
35	3	\N	Gurla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
36	3	\N	Kothavalasa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
37	3	\N	Nellimarla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
38	3	\N	R.b.puram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
39	3	\N	Rajam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
40	3	\N	Santhakaviti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
41	3	\N	Therlam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
42	3	\N	Vangara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
43	3	\N	Vepada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
44	4	\N	Anadapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
45	4	\N	Bheemunipatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
46	4	\N	Padmanabham	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
47	5	\N	Chodavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
48	5	\N	Deverapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
49	5	\N	Nakkapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
50	5	\N	K Kotapadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
51	5	\N	S.rayavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
52	5	\N	Rolugunta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
53	5	\N	Sabbavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
54	5	\N	Kotauratla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
55	5	\N	Golugonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
56	5	\N	Narsipatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
57	5	\N	Nathavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
58	5	\N	Makavarapalem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
59	5	\N	Ravikamatham	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
60	5	\N	Vaddadi, Butchiahpeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
61	6	\N	Koyyuru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
62	6	\N	Hukumpeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
63	6	\N	Munchingput	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
64	6	\N	Pedabayalu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
65	6	\N	Ananthagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
66	6	\N	Paderu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
67	6	\N	Chintapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
68	6	\N	G. Madugula	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
69	6	\N	G.k. Veedhi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
70	6	\N	Araku	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
71	6	\N	Dumbriguda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
72	6	\N	Chinturu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
73	6	\N	Rampachodavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
74	6	\N	Gangavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
75	6	\N	Maredumilli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
76	7	\N	Sankhavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
77	7	\N	Tuni	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
78	7	\N	Kotananduru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
79	7	\N	Thondangi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
80	8	\N	Reddygudem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
81	8	\N	Gampalagude M	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
82	9	\N	Atchampet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
83	9	\N	Bellamkonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
84	9	\N	Dachepalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
85	9	\N	Durgi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
86	9	\N	Gurazala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
87	9	\N	Karempudi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
88	9	\N	Krosuru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
89	9	\N	Macherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
90	9	\N	Muppalla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
91	9	\N	Nakarikallu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
92	9	\N	Nuzendla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
93	9	\N	Rajupalem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
94	9	\N	Rentachintala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
95	9	\N	Rompicherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
96	9	\N	Sattenapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
97	9	\N	Vinukonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
98	10	\N	Ballikurava	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
99	10	\N	Chinaganjam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
100	11	\N	Ardhaveedu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
101	11	\N	Komarolu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
102	11	\N	Kothapatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
103	11	\N	Kurichedu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
104	11	\N	Markapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
105	11	\N	Peddaraveedu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
106	11	\N	Tallur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
107	11	\N	Tarlupadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
108	11	\N	Y.palem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
109	11	\N	Zarugumalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
110	12	\N	Kondapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
111	12	\N	Kavali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
112	12	\N	Kaligiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
113	12	\N	Marripadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
114	12	\N	A.s.peta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
115	12	\N	Gudluru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
116	13	\N	Gudupalle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
117	13	\N	Rompicherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
118	13	\N	Santhipuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
119	13	\N	Baireddipalle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
120	13	\N	Punganur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
121	13	\N	Kuppam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
122	13	\N	Gangavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
123	13	\N	Ramakuppam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
124	14	\N	Venkatagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
125	14	\N	D.v.satram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
126	14	\N	Puram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
127	14	\N	Yerravaripalem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
128	15	\N	B.kodur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
129	15	\N	B.mattam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
130	15	\N	Chapadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
131	15	\N	Porumamilla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
132	15	\N	Mydukur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
133	15	\N	Vemula	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
134	16	\N	L.r.palli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
135	16	\N	T.sundupalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
136	16	\N	Kalakada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
137	16	\N	Kv Palle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
138	16	\N	Nimmanapalle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
139	17	\N	Atmakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
140	17	\N	Beluguppa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
141	17	\N	Bommanahal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
142	17	\N	Brahma Samudram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
143	17	\N	Bukkaraya Samudram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
144	17	\N	D Hirehal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
145	17	\N	Garladinne	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
146	17	\N	Gooty	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
147	17	\N	Gummagatta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
148	17	\N	Guntakal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
149	17	\N	Kalyandurg	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
150	17	\N	Kambadur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
151	17	\N	Kudair	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
152	17	\N	Kundurpi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
153	17	\N	Narpala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
154	17	\N	Pamidi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
155	17	\N	Peddapappur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
156	17	\N	Rapthadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
157	17	\N	Rayadurg	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
158	17	\N	Settur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
159	17	\N	Uravakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
160	17	\N	Vajrakarur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
161	18	\N	Agali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
162	18	\N	Amarapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
163	18	\N	Battalapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
164	18	\N	Bukkapatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
165	18	\N	Chennekothapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
166	18	\N	Dharmavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
167	18	\N	Kadiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
168	18	\N	Lepakshi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
169	18	\N	Madakasira	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
170	18	\N	Nallamada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
171	18	\N	Parigi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
172	18	\N	Ramagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
173	18	\N	Roddam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
174	19	\N	Adoni, (m)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
175	19	\N	Alur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
176	19	\N	Aspari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
177	19	\N	C.belgal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
178	19	\N	Devanakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
179	19	\N	Gudur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
180	19	\N	Kallur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
181	19	\N	Kodumur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
182	19	\N	Krishnagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
183	19	\N	Kurnool	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
184	19	\N	Maddikera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
185	19	\N	Mantralayam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
186	19	\N	Orvakal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
187	19	\N	Pathikonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
188	19	\N	Tuggali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
189	20	\N	Atmakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
190	20	\N	Banaganapalli (m)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
191	20	\N	Bethamcherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
192	20	\N	Chagalamarri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
193	20	\N	Gospadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
194	20	\N	Nandyal (g)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
195	20	\N	Nandyal (m)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
196	20	\N	Panyam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
197	21	\N	Tawang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
198	22	\N	Pakke-kesang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
199	23	\N	Sagalee	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
200	24	\N	Giba	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
201	25	\N	Boleng	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
202	26	\N	Namsai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
203	27	\N	Bordumsa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
204	27	\N	Miao	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
205	28	\N	Mebo	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
206	29	\N	Ramle Banggo	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
207	30	\N	Mazbat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
208	30	\N	Khoirabari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
209	31	\N	Hapjan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
210	32	\N	Mankachar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
211	33	\N	Dhekiajuli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
212	34	\N	Kaliabor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
213	34	\N	Urban	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
214	35	\N	Barkhetri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
215	36	\N	Laharighat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
216	37	\N	Lakhimpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
217	38	\N	Lumbajong	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
218	38	\N	Langsomepi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
219	39	\N	Kachugaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
220	39	\N	Kokrajhar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
221	40	\N	Patherkandi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
222	41	\N	Katlicherra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
223	42	\N	Balijana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
224	43	\N	Lahoal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
225	43	\N	Panitola	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
226	44	\N	Diyungbra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
227	45	\N	Gauripur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
228	46	\N	Murkongsele K	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
229	46	\N	Dhemaji	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
230	47	\N	Dalgaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
231	48	\N	Sonari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
232	49	\N	Borobazar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
233	50	\N	Salchapra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
234	51	\N	Behali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
235	52	\N	Jalah	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
236	53	\N	Bhawanipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
237	53	\N	Barpeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
238	53	\N	Gobardhana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
239	45	\N	Golakganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
240	53	\N	Chenga	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
241	54	\N	Balodabazar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
242	54	\N	Bhatapara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
243	55	\N	Wadrafnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
244	55	\N	Rajpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
245	56	\N	Tokapal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
246	57	\N	Bemetara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
247	58	\N	Bijapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
248	58	\N	Bhiramgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
249	58	\N	Usoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
250	59	\N	Geedam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
251	59	\N	Kuakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
252	59	\N	Katekalyan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
253	60	\N	Mainpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
254	60	\N	Devbhog	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
255	61	\N	S. Lohara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
256	61	\N	Bodla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
257	61	\N	Pandariya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
258	62	\N	Antagarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
259	63	\N	Keshkal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
260	63	\N	Kondagaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
261	64	\N	Korba	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
262	64	\N	Katghora	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
263	65	\N	Bagbahra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
264	65	\N	Pithora	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
265	66	\N	Khadgavan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
266	67	\N	Lormi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
267	68	\N	Narayanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
268	68	\N	Orchha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
269	69	\N	Dharamjaigarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
270	70	\N	Bilaigarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
271	71	\N	Chindgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
272	71	\N	Sukma	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
273	72	\N	Pratappur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
274	73	\N	Ambikapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
275	73	\N	Lakhanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
276	73	\N	Udaypur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
277	73	\N	Mainpat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
278	72	\N	Odgi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
279	72	\N	Premnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
280	73	\N	Batouli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
281	74	\N	Una	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
282	75	\N	Kawant	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
283	76	\N	Mangrol	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
284	77	\N	Tohana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
285	77	\N	Fatehabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
286	78	\N	Alewa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
287	78	\N	Narwana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
288	78	\N	Uchana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
289	79	\N	Nuh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
290	79	\N	Tauru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
291	79	\N	Ferozpur Jhirka	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
292	79	\N	Nagina	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
293	79	\N	Punahana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
294	80	\N	Hathin	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
295	81	\N	Bapoli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
296	82	\N	Nathusari Chopta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
297	82	\N	Dabwali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
298	83	\N	Bhandra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
299	84	\N	Gawan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
300	85	\N	Petarwar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
301	86	\N	Maheshpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
302	87	\N	Kanke	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
303	87	\N	Burmu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
304	88	\N	Karra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
305	89	\N	Chakradharpu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
306	90	\N	Bishnugarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
307	91	\N	Hunterganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
308	91	\N	Pathalgada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
309	87	\N	Chanho	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
310	89	\N	Manjhari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
311	87	\N	Angara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
312	89	\N	Noamundi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
313	84	\N	Gandey	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
314	92	\N	Poraiyahat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
315	91	\N	Pratappur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
316	93	\N	Ramkanda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
317	90	\N	Barhi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
318	90	\N	Padma	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
319	90	\N	Ichak	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
320	91	\N	Kunda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
321	92	\N	Godda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
322	94	\N	Seraikella	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
323	86	\N	Pakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
324	85	\N	Gomiya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
325	84	\N	Pirtand	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
326	95	\N	Garu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
327	95	\N	Barwadih	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
328	85	\N	Chas	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
329	84	\N	Jamua	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
330	96	\N	Jainagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
331	97	\N	Nirsa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
332	95	\N	Latehar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
333	98	\N	Kundahit	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
334	89	\N	Tonto	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
335	97	\N	Govindpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
336	87	\N	Namkum	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
337	98	\N	Jamtara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
338	90	\N	Keredari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
339	89	\N	Khuntpani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
340	84	\N	Giridih	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
341	83	\N	Kuru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
342	89	\N	Majhgaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
343	90	\N	Katkamsandi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
344	99	\N	Hospet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
345	100	\N	Gangavathi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
346	101	\N	Shorapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
347	101	\N	Shahapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
348	101	\N	Yadgiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
349	102	\N	Kalaghatagi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
350	103	\N	Basavana Bagadi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
351	103	\N	Mudyibihall	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
352	104	\N	Machi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
353	105	\N	Srinagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
354	106	\N	Rajgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
355	107	\N	Banswara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
356	108	\N	Atru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
357	108	\N	Baran	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
358	108	\N	Chabra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
359	108	\N	Shahbad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
360	109	\N	Gadraroad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
361	110	\N	Jaitaran	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
362	111	\N	Banera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
363	111	\N	Mandalgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
364	111	\N	Raypur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
365	112	\N	Poogal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
366	113	\N	Bundi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
367	113	\N	K.patan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
368	113	\N	Nainwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
369	114	\N	Bhadesar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
370	114	\N	Bhainsroadga	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
371	115	\N	Bari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
372	115	\N	Saramathura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
373	115	\N	Dholpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
374	115	\N	Rajakhera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
375	116	\N	Makrana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
376	117	\N	Aspur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
377	117	\N	Jhonthari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
378	117	\N	Dovda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
379	117	\N	Shimlawara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
380	118	\N	Hanumangarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
381	119	\N	Sanganer	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
382	120	\N	Sanchore	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
383	120	\N	Aahor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
384	121	\N	M.thana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
385	122	\N	Karauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
386	122	\N	Sapotra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
387	123	\N	Kishganrgh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
388	124	\N	Mundwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
389	124	\N	Khinwsar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
390	124	\N	Riyan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
391	125	\N	Rani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
392	126	\N	Pipalkhunt	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
393	127	\N	Delwada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
394	128	\N	Salumbar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
395	128	\N	Sarada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
396	129	\N	Reodar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
397	130	\N	Toda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
398	131	\N	Chongrang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
399	132	\N	Jainad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
400	132	\N	Bela	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
401	132	\N	Gadiguda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
402	132	\N	Adilabad (urban)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
403	132	\N	Talamadugu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
404	133	\N	Jainoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
405	133	\N	Rebbena	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
406	133	\N	Asifabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
407	133	\N	Kerameri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
408	133	\N	Sirpur T	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
409	133	\N	Chintalamanepally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
410	133	\N	Dahegaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
411	134	\N	Tandur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
412	134	\N	Bellampally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
413	134	\N	Mancherial	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
414	134	\N	Naspur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
415	134	\N	Bheemaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
416	134	\N	Chennur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
417	135	\N	Mudhole	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
418	135	\N	Bhainsa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
419	135	\N	Narsapur-g	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
420	135	\N	Dilawarpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
421	135	\N	Sarangapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
422	135	\N	Nirmal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
423	135	\N	Pembi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
424	135	\N	Kaddam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
425	136	\N	Nandipet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
426	136	\N	Armoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
427	136	\N	Balkonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
428	136	\N	Jakranpally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
429	136	\N	Nizamabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
430	136	\N	Dichpally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
431	137	\N	Ibrahimpatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
432	137	\N	Velgatoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
433	138	\N	Anthergaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
434	138	\N	Julapally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
435	138	\N	Sulthanabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
436	138	\N	Srirampoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
437	139	\N	Chityal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
438	139	\N	Tekumatla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
439	139	\N	Bhupalpally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
440	140	\N	Karakagudem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
441	140	\N	Chandrugonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
442	140	\N	Annapureddypalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
443	140	\N	Palvancha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
444	141	\N	Geesugonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
445	142	\N	Athmakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
446	141	\N	Nallabelly	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
447	141	\N	Chennaraopet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
448	142	\N	Bheemadevarapally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
449	142	\N	Kamalapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
450	142	\N	Inavole	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
451	143	\N	Jammikunta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
452	144	\N	Rudrangi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
453	144	\N	Marripally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
454	144	\N	Siricilla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
455	144	\N	Veernapally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
456	144	\N	Gambhiraopet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
457	144	\N	Thangalapally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
458	145	\N	Bichkunda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
459	145	\N	Birkoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
460	145	\N	Pitlam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
461	145	\N	Nizamsagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
462	145	\N	Yellareddy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
463	145	\N	Lingampet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
464	145	\N	Bhiknur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
465	145	\N	Bibipet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
466	146	\N	Narayankhed	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
467	146	\N	Raikode	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
468	146	\N	Jharasangam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
469	146	\N	Andole	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
470	146	\N	Pulkal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
471	146	\N	Sadashivpet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
472	146	\N	Kondapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
473	146	\N	Jinnaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
474	147	\N	Alladurg	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
475	147	\N	Medak	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
476	147	\N	Chippalthurthy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
477	147	\N	Yeldurthy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
478	147	\N	Toopran	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
479	148	\N	Siddipet Rural	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
480	148	\N	Siddipet Urban	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
481	148	\N	Mirdoddi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
482	148	\N	Gajwel	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
483	149	\N	Chilpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
484	149	\N	Zaffargadh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
485	149	\N	Ghanpur Stn	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
486	149	\N	Bachannapet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
487	149	\N	Jangaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
488	149	\N	Palakurthi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
489	150	\N	Bommalaramaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
490	150	\N	Choutuppal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
491	150	\N	Valigonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
492	150	\N	Addagudur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
493	151	\N	Shankarpally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
494	151	\N	Ibrahimpatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
495	151	\N	Manchal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
496	151	\N	Keshampet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
497	151	\N	Kandukur,2007	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
498	151	\N	Maheshwaram2011	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
499	151	\N	Shamshabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
500	151	\N	Shabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
501	151	\N	Kothur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
502	151	\N	Farooqnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
503	151	\N	Kondurge/m	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
504	152	\N	Mominpet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
505	152	\N	Pudur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
506	152	\N	Kulkacherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
507	152	\N	Doma	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
508	152	\N	Peddemul	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
509	152	\N	Tandur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
510	152	\N	Kodangal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
511	153	\N	Koilkonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
512	153	\N	Gandeed	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
513	153	\N	Devarkadara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
514	153	\N	Mahabubnagar (urban)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
515	153	\N	Mahabubnagar (rural)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
516	153	\N	Nawabpet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
517	154	\N	Gadwal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
518	154	\N	Gattu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
519	154	\N	Ieeja	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
520	154	\N	Manopad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
521	155	\N	Gopalpet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
522	155	\N	Wanaparthy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
523	155	\N	Athmakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
524	155	\N	Srirangapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
525	156	\N	Nagarkurnool	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
526	156	\N	Veldanda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
527	156	\N	Charakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
528	156	\N	Kalwakurthy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
529	156	\N	Amrabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
530	156	\N	Balmoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
531	156	\N	Kollapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
532	156	\N	Pentlavelly	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
533	157	\N	Kethepally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
534	157	\N	Munugode	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
535	157	\N	Nampally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
536	157	\N	Nagarjuna Sagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
537	157	\N	Miryalaguda,vemul Apally	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
538	157	\N	Miryalguda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
539	157	\N	Miryalaguda,	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
540	158	\N	Singareni	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
541	158	\N	Raghundhapalme	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
542	158	\N	Kusumanchi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
543	158	\N	Khammam Urban	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
544	159	\N	Venkatapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
545	159	\N	Govindaraopet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
546	160	\N	Damaragidda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
547	160	\N	Utkoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
548	160	\N	Krishna	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
549	160	\N	Makthal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
550	160	\N	Narwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
551	160	\N	Dhanwada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
552	132	\N	Bheempur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
553	132	\N	Boath	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
554	132	\N	Sirikonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
555	133	\N	Sirpur U	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
556	133	\N	Thiryani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
557	133	\N	Kagaznagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
558	134	\N	Nennel	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
559	134	\N	Mandamarri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
560	135	\N	Khanapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
561	136	\N	Morthad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
562	160	\N	Maddur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
563	161	\N	Jagner	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
564	161	\N	Bichpuri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
565	161	\N	Bah	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
566	162	\N	Khair	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
567	163	\N	Ramnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
568	163	\N	Katehari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
569	163	\N	Jalalpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
570	163	\N	Jahangirganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
571	163	\N	Bheeti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
572	163	\N	Bhiyaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
573	163	\N	Akbarpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
574	164	\N	Joya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
575	164	\N	Hasanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
576	164	\N	Gangeshwari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
577	164	\N	Gajraula	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
578	165	\N	Sohawal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
579	165	\N	Rudauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
580	165	\N	Milkipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
581	165	\N	Amaniganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
582	166	\N	Tarwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
583	166	\N	Mehnager	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
584	166	\N	Lalganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
585	166	\N	Jahanaganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
586	167	\N	Ujhani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
587	167	\N	Sahaswan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
588	167	\N	Islamnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
589	167	\N	Dataganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
590	167	\N	Bisauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
591	167	\N	Budaun City	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
592	167	\N	Ambiyapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
593	167	\N	Aasafpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
594	168	\N	Baraout Urban	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
595	169	\N	Chhaproli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
596	170	\N	Mihipurwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
597	171	\N	Tulsipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
598	171	\N	Pachperwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
599	172	\N	Tindwari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
600	172	\N	Jaspura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
601	173	\N	Vithari Chainpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
602	173	\N	Faridpur Town	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
603	173	\N	Bhojipura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
604	173	\N	Bareilly Town	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
605	173	\N	Shergarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
606	174	\N	Basti Sadar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
607	174	\N	Bankati	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
608	174	\N	Rudholi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
609	174	\N	Kudraha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
610	174	\N	Kaptanganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
611	174	\N	Saltova Gopalpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
612	174	\N	Vikramjot	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
613	174	\N	Bahadurpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
614	174	\N	Harriya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
615	174	\N	Gaur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
616	175	\N	Kiratpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
617	175	\N	Haldaur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
618	176	\N	Miaun	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
619	177	\N	Gulaoti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
620	177	\N	Debai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
621	178	\N	Niyamatabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
622	178	\N	Naugarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
623	179	\N	Rampur Karkhana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
624	179	\N	Patthrdeva	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
625	179	\N	Lar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
626	179	\N	Deoria Sadar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
627	179	\N	Bhatpar Rani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
628	179	\N	Barahaj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
629	180	\N	Jalesar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
630	180	\N	Sakeet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
631	181	\N	Etawah Nagar Chetra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
632	182	\N	Shamsabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
633	183	\N	Ashothar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
634	184	\N	T.a. Firozabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
635	184	\N	Eka	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
636	185	\N	Birno	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
637	185	\N	Saidpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
638	186	\N	Nawab Ganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
639	186	\N	Wazirganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
640	186	\N	Pandri Kripal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
641	186	\N	Chhapia	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
642	186	\N	Jhanjhri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
643	187	\N	Sardarnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
644	187	\N	Piprauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
645	187	\N	Pali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
646	187	\N	Charganwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
647	187	\N	Campiarganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
648	187	\N	Brahampur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
649	187	\N	Belghat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
650	187	\N	Bansgaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
651	188	\N	Bilgram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
652	188	\N	Sursa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
653	188	\N	Harpalpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
654	188	\N	Kachauna	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
655	189	\N	Sadabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
656	190	\N	Badla Pur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
657	190	\N	Sujanganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
658	190	\N	Machhali Shahar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
659	190	\N	Mugra Badshah Pur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
660	191	\N	Mauranipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
661	191	\N	Gursarai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
662	191	\N	Chirgaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
663	191	\N	Babina	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
664	192	\N	Jalalabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
665	192	\N	Chhibramau	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
666	193	\N	Amaraudha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
667	194	\N	Sidhpura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
668	194	\N	Sahawar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
669	194	\N	Dundwara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
670	195	\N	Sirathu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
671	195	\N	Newada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
672	195	\N	Manjhanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
673	195	\N	Kaushambi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
674	196	\N	Vishunpura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
675	196	\N	Sukrauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
676	196	\N	Seorahi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
677	196	\N	Tamkuhi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
678	196	\N	Motichuk	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
679	196	\N	Kasia	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
680	196	\N	Kaptanganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
681	196	\N	Hata	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
682	196	\N	Fazilnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
683	196	\N	Dudahi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
684	197	\N	Dhourahra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
685	198	\N	Birdha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
686	198	\N	Madawra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
687	199	\N	Sarojni Nagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
688	199	\N	Kakori	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
689	199	\N	Gosaiganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
690	199	\N	Bakshi Ka Talab	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
691	200	\N	Kabrai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
692	201	\N	Siswa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
693	202	\N	Goverdhan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
694	202	\N	Chhata	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
695	202	\N	Chaumuhan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
696	203	\N	Kopaganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
697	203	\N	Badraw	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
698	203	\N	Mohammadabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
699	204	\N	Rajgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
700	204	\N	Pahari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
701	205	\N	Chajlet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
702	205	\N	Bhagatpur Tanda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
703	205	\N	Mundapanday	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
704	206	\N	Gaura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
705	206	\N	Sadwa-chandrika	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
706	206	\N	Laxmanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
707	207	\N	Soraon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
708	207	\N	Sahson	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
709	207	\N	Handia	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
710	207	\N	Shankar Garh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
711	207	\N	Kaundhiyara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
712	208	\N	Unchahar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
713	208	\N	Gaura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
714	208	\N	Salon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
715	208	\N	Mahrajganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
716	209	\N	Chamrauva	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
717	210	\N	Punwarka	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
718	211	\N	Baniyakhera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
719	211	\N	Rajpura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
720	212	\N	Katra Khudaganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
721	212	\N	T.a.shahjahanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
722	212	\N	Tilhar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
723	212	\N	Mirjapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
724	212	\N	Kalan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
725	212	\N	Dadraul	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
726	212	\N	Kanth	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
727	212	\N	Puwaya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
728	212	\N	Jaitipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
729	212	\N	Sindhauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
730	212	\N	T.a.tilhar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
731	213	\N	Uska Bazar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
732	214	\N	Sidhauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
733	214	\N	Reusa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
734	214	\N	Behta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
735	215	\N	Robertsganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
736	216	\N	Kurebhar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
737	216	\N	Kadipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
738	217	\N	Hilouli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
739	217	\N	Safipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
740	218	\N	Pindra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
741	218	\N	:nagar Nigam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: m_cluster; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_cluster (cluster_id, district_id, block_id, cluster_code, cluster_name, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: m_district; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_district (district_id, state_id, district_code, district_name, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	\N	Srikakulam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
2	1	\N	Parvathipu Ram Manyam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
3	1	\N	Vizainagar Am	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
4	1	\N	Visakhapat Nam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
5	1	\N	Anakapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
6	1	\N	Asr	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
7	1	\N	Kakinada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
8	1	\N	Ntr	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
9	1	\N	Palnadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
10	1	\N	Bapatla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
11	1	\N	Prakasam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
12	1	\N	Sps Nellore	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
13	1	\N	Chittoor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
14	1	\N	Tirupati	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
15	1	\N	Ysr	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
16	1	\N	Annamayya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
17	1	\N	Ananthapu R	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
18	1	\N	Satya Sai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
19	1	\N	Kurnool	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
20	1	\N	Nandyal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
21	2	\N	Tawang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
22	2	\N	Pakke-kesang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
23	2	\N	Papum Pare	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
24	2	\N	Upper Subansiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
25	2	\N	Siang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
26	2	\N	Namsai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
27	2	\N	Changlang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
28	2	\N	East Siang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
29	2	\N	Lower Siang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
30	3	\N	Udalguri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
31	3	\N	Tinsukia	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
32	3	\N	South Salmara-mankachar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
33	3	\N	Sonitpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
34	3	\N	Nagaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
35	3	\N	Nalbari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
36	3	\N	Morigaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
37	3	\N	Lakhimpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
38	3	\N	Karbi Anglong	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
39	3	\N	Kokrajhar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
40	3	\N	Karimganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
41	3	\N	Hailakandi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
42	3	\N	Goalpara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
43	3	\N	Dibrugarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
44	3	\N	Dima Hasao	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
45	3	\N	Dhubri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
46	3	\N	Dhemaji	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
47	3	\N	Darrang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
48	3	\N	Charaideo	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
49	3	\N	Chirang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
50	3	\N	Cachar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
51	3	\N	Biswanath	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
52	3	\N	Baksa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
53	3	\N	Barpeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
54	4	\N	Balodabazar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
55	4	\N	Balrampur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
56	4	\N	Baster	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
57	4	\N	Bemetara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
58	4	\N	Bijapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
59	4	\N	Dantewada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
60	4	\N	Gariyaband	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
61	4	\N	Kabirdham	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
62	4	\N	Kanker	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
63	4	\N	Kondagaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
64	4	\N	Korba	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
65	4	\N	Mahasamund	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
66	4	\N	Mcb	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
67	4	\N	Mungeli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
68	4	\N	Narayanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
69	4	\N	Raigarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
70	4	\N	Sarangarh- Bilaigarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
71	4	\N	Sukma	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
72	4	\N	Surajpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
73	4	\N	Surguja	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
74	5	\N	Gir Somanath	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
75	5	\N	Chhotaudepu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
76	5	\N	Junagadh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
77	6	\N	Fatehabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
78	6	\N	Jind	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
79	6	\N	Mewat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
80	6	\N	Palwal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
81	6	\N	Panipat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
82	6	\N	Sirsa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
83	7	\N	Lohardaga	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
84	7	\N	Giridih	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
85	7	\N	Bokaro	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
86	7	\N	Pakaur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
87	7	\N	Ranchi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
88	7	\N	Khunti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
89	7	\N	Pashchimi Sin	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
90	7	\N	Hazaribag	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
91	7	\N	Chatra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
92	7	\N	Godda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
93	7	\N	Garhwa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
94	7	\N	Saraikela-k	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
95	7	\N	Latehar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
96	7	\N	Kodarma	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
97	7	\N	Dhanbad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
98	7	\N	Jamtara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
99	8	\N	Vijayanagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
100	8	\N	Koppal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
101	8	\N	Yadgiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
102	8	\N	Dharwad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
103	8	\N	Vijayapura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
104	9	\N	Tengnoupal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
105	10	\N	Ajmer	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
106	10	\N	Alwar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
107	10	\N	Banswara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
108	10	\N	Baran	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
109	10	\N	Barmer	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
110	10	\N	Beawar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
111	10	\N	Bhilwara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
112	10	\N	Bikaner	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
113	10	\N	Bundi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
114	10	\N	Chittorgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
115	10	\N	Dholpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
116	10	\N	Didwana-ku	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
117	10	\N	Dungarpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
118	10	\N	Hanumangarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
119	10	\N	Jaipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
120	10	\N	Jalore	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
121	10	\N	Jhalawar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
122	10	\N	Karauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
123	10	\N	Khairthal- Tijara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
124	10	\N	Nagaur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
125	10	\N	Pali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
126	10	\N	Pratapgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
127	10	\N	Rajsamand	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
128	10	\N	Salumbar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
129	10	\N	Sirohi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
130	10	\N	Tonk	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
131	11	\N	Gyalshing	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
132	12	\N	Adilabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
133	12	\N	Kumuram Bheem Asifabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
134	12	\N	Mancherial	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
135	12	\N	Nirmal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
136	12	\N	Nizamabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
137	12	\N	Jagtial	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
138	12	\N	Peddapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
139	12	\N	Jayashankar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
140	12	\N	Bhadradri Kothagudem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
141	12	\N	Warangal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
142	12	\N	Hanumakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
143	12	\N	Karimnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
144	12	\N	Rajanna Siricilla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
145	12	\N	Kamareddy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
146	12	\N	Sangareddy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
147	12	\N	Medak	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
148	12	\N	Siddipet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
149	12	\N	Jangaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
150	12	\N	Yadadri Bhuvanagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
151	12	\N	Rangareddy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
152	12	\N	Vikarabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
153	12	\N	Mahabubnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
154	12	\N	Jogulamba Gadwal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
155	12	\N	Wanaparthy	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
156	12	\N	Nagarkurnool	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
157	12	\N	Nalgonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
158	12	\N	Khammam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
159	12	\N	Mulugu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
160	12	\N	Narayanapet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
161	13	\N	Agra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
162	13	\N	Aligarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
163	13	\N	Ambedkar Nagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
164	13	\N	Amroha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
165	13	\N	Ayodhya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
166	13	\N	Azamgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
167	13	\N	Badaun	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
168	13	\N	Baghpat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
169	13	\N	Bahghpat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
170	13	\N	Bahraich	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
171	13	\N	Balrampur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
172	13	\N	Banda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
173	13	\N	Bareilly	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
174	13	\N	Basti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
175	13	\N	Bijnor	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
176	13	\N	Budaun	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
177	13	\N	Bulandshahr	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
178	13	\N	Chandauli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
179	13	\N	Deoria	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
180	13	\N	Etah	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
181	13	\N	Etawah	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
182	13	\N	Farrukhabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
183	13	\N	Fatehpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
184	13	\N	Firozabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
185	13	\N	Ghazipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
186	13	\N	Gonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
187	13	\N	Gorakhpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
188	13	\N	Hardoi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
189	13	\N	Hathras	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
190	13	\N	Jaunpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
191	13	\N	Jhansi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
192	13	\N	Kannauj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
193	13	\N	Kanpur Dehat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
194	13	\N	Kasganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
195	13	\N	Kaushambi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
196	13	\N	Kushinagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
197	13	\N	Lakhimpur Khiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
198	13	\N	Lalitpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
199	13	\N	Lucknow	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
200	13	\N	Mahoba	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
201	13	\N	Mahrajganj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
202	13	\N	Mathura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
203	13	\N	Mau	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
204	13	\N	Mirzapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
205	13	\N	Moradabad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
206	13	\N	Pratapgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
207	13	\N	Prayagraj	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
208	13	\N	Raebareli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
209	13	\N	Rampur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
210	13	\N	Saharanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
211	13	\N	Sambhal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
212	13	\N	Shahjahanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
213	13	\N	Siddharthnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
214	13	\N	Sitapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
215	13	\N	Sonbhadra	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
216	13	\N	Sultanpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
217	13	\N	Unnao	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
218	13	\N	Varanasi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: m_holiday; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_holiday (holiday_id, holiday_name, holiday_date, scope, state_id, district_id, project_id, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	Children’s Day	2026-11-14	NATIONAL	\N	\N	\N	t	2026-10-27 15:54:40.011432+05:30	\N	\N	\N	DEMO-SAMPLE-HOLIDAY-NATIONAL	{"id": "DEMO-SAMPLE-HOLIDAY-NATIONAL", "date": "2026-11-14", "name": "Children’s Day", "note": "Sample national holiday", "scope": "National", "state": "", "active": true, "school": "", "district": ""}	teacher-training-holidays	\N	\N	\N	1	f
2	Andhra Pradesh Formation Day	2026-11-01	STATE	1	\N	\N	t	2026-10-27 15:54:40.047314+05:30	\N	\N	\N	DEMO-SAMPLE-HOLIDAY-STATE	{"id": "DEMO-SAMPLE-HOLIDAY-STATE", "date": "2026-11-01", "name": "Andhra Pradesh Formation Day", "note": "Sample state holiday", "scope": "State", "state": "Andhra Pradesh", "active": true, "school": "", "district": ""}	teacher-training-holidays	\N	\N	\N	1	f
\.


--
-- Data for Name: m_module; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_module (module_id, module_code, module_name, sort_order, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: m_pii_field; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_pii_field (pii_field_id, field_code, table_name, column_base, mask_rule, description, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: m_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_role (role_id, role_code, role_name, role_rank, role_category, data_scope, description, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
9	schoolnet-super-admin	Schoolnet Super Admin	1	MANAGEMENT	ALL	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
10	sponsor-admin	Sponsor Admin	2	MANAGEMENT	GRANT	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
11	schoolnet-project-admin	Schoolnet Project Admin	3	MANAGEMENT	GRANT	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
12	state-admin	State Admin	4	MANAGEMENT	GRANT	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
13	school-admin	School Admin	5	MANAGEMENT	GRANT	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
14	trainer	Trainer	6	TRAINER	GRANT	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
15	trainee	Trainee	7	TRAINEE	SELF	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
16	reporting-audit-user	Reporting Audit User	8	MANAGEMENT	GRANT	\N	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: m_school; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_school (school_id, udise_code, school_name, state_id, district_id, block_id, cluster_id, actual_location, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	28111102307	KGBV BURJA	1	1	1	\N	KGBV BURJA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28111102307	{"id": "28111102307", "block": "Burja", "state": "Andhra Pradesh", "udise": "28111102307", "school": "KGBV BURJA", "district": "Srikakulam", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
2	28110801105	KGBV ETCHERLA	1	1	2	\N	KGBV ETCHERLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110801105	{"id": "28110801105", "block": "Etcherla", "state": "Andhra Pradesh", "udise": "28110801105", "school": "KGBV ETCHERLA", "district": "Srikakulam", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
3	28110501704	KGBV G.SIGADAM	1	1	3	\N	KGBV G.SIGADAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110501704	{"id": "28110501704", "block": "G.sigadam", "state": "Andhra Pradesh", "udise": "28110501704", "school": "KGBV G.SIGADAM", "district": "Srikakulam", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
4	28112000409	KGBV GARA	1	1	4	\N	KGBV GARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112000409	{"id": "28112000409", "block": "Gara", "state": "Andhra Pradesh", "udise": "28112000409", "school": "KGBV GARA", "district": "Srikakulam", "enrollment": 290}	teacher-training-schools	\N	\N	\N	1	f
5	28113790227	KGBV ICHAPURAM	1	1	5	\N	KGBV ICHAPURAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28113790227	{"id": "28113790227", "block": "Ichapuram", "state": "Andhra Pradesh", "udise": "28113790227", "school": "KGBV ICHAPURAM", "district": "Srikakulam", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
6	28112303212	KGBV JALUMURU	1	1	6	\N	KGBV JALUMURU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112303212	{"id": "28112303212", "block": "Jalumuru", "state": "Andhra Pradesh", "udise": "28112303212", "school": "KGBV JALUMURU", "district": "Srikakulam", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
7	28113504308	KGBV KANCHILI	1	1	7	\N	KGBV KANCHILI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28113504308	{"id": "28113504308", "block": "Kanchili", "state": "Andhra Pradesh", "udise": "28113504308", "school": "KGBV KANCHILI", "district": "Srikakulam", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
8	28112802422	KGBV KOTABOMMALI	1	1	8	\N	KGBV KOTABOMMALI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112802422	{"id": "28112802422", "block": "Kotabommali", "state": "Andhra Pradesh", "udise": "28112802422", "school": "KGBV KOTABOMMALI", "district": "Srikakulam", "enrollment": 284}	teacher-training-schools	\N	\N	\N	1	f
9	28113805502	KGBV L.N PETA	1	1	9	\N	KGBV L.N PETA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28113805502	{"id": "28113805502", "block": "L.n Peta", "state": "Andhra Pradesh", "udise": "28113805502", "school": "KGBV L.N PETA", "district": "Srikakulam", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
10	28110602112	KGBV LAVERU	1	1	10	\N	KGBV LAVERU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110602112	{"id": "28110602112", "block": "Laveru", "state": "Andhra Pradesh", "udise": "28110602112", "school": "KGBV LAVERU", "district": "Srikakulam", "enrollment": 285}	teacher-training-schools	\N	\N	\N	1	f
11	28112600210	KGBV MELIAPUTTI	1	1	11	\N	KGBV MELIAPUTTI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112600210	{"id": "28112600210", "block": "Meliaputti", "state": "Andhra Pradesh", "udise": "28112600210", "school": "KGBV MELIAPUTTI", "district": "Srikakulam", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
12	28113007814	KGBV NANDIGAM	1	1	12	\N	KGBV NANDIGAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28113007814	{"id": "28113007814", "block": "Nandigam", "state": "Andhra Pradesh", "udise": "28113007814", "school": "KGBV NANDIGAM", "district": "Srikakulam", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
13	28112103417	KGBV POLAKI	1	1	13	\N	KGBV POLAKI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112103417	{"id": "28112103417", "block": "Polaki", "state": "Andhra Pradesh", "udise": "28112103417", "school": "KGBV POLAKI", "district": "Srikakulam", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
14	28110901224	KGBV PONDURU	1	1	14	\N	KGBV PONDURU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110901224	{"id": "28110901224", "block": "Ponduru", "state": "Andhra Pradesh", "udise": "28110901224", "school": "KGBV PONDURU", "district": "Srikakulam", "enrollment": 288}	teacher-training-schools	\N	\N	\N	1	f
15	28110701913	KGBV RANASTHALAM	1	1	15	\N	KGBV RANASTHALAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110701913	{"id": "28110701913", "block": "Ranasthalam", "state": "Andhra Pradesh", "udise": "28110701913", "school": "KGBV RANASTHALAM", "district": "Srikakulam", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
16	28112903103	KGBV SANTHABOMMALI	1	1	16	\N	KGBV SANTHABOMMALI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112903103	{"id": "28112903103", "block": "Santhabomma Li", "state": "Andhra Pradesh", "udise": "28112903103", "school": "KGBV SANTHABOMMALI", "district": "Srikakulam", "enrollment": 300}	teacher-training-schools	\N	\N	\N	1	f
17	28112402609	KGBV SARAVAKOTA	1	1	17	\N	KGBV SARAVAKOTA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28112402609	{"id": "28112402609", "block": "Saravakota", "state": "Andhra Pradesh", "udise": "28112402609", "school": "KGBV SARAVAKOTA", "district": "Srikakulam", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
18	28113490509	KGBV SOMPETA	1	1	18	\N	KGBV SOMPETA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28113490509	{"id": "28113490509", "block": "Sompeta", "state": "Andhra Pradesh", "udise": "28113490509", "school": "KGBV SOMPETA", "district": "Srikakulam", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
19	28111901617	KGBV SRIKAKULAM	1	1	19	\N	KGBV SRIKAKULAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28111901617	{"id": "28111901617", "block": "Srikakulam", "state": "Andhra Pradesh", "udise": "28111901617", "school": "KGBV SRIKAKULAM", "district": "Srikakulam", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
20	28120501709	KGBV GARUGUBILLI	1	2	20	\N	KGBV GARUGUBILLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120501709	{"id": "28120501709", "block": "Garugubilli", "state": "Andhra Pradesh", "udise": "28120501709", "school": "KGBV GARUGUBILLI", "district": "Parvathipu Ram Manyam", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
21	28120207607	KGBV GUMMALAKSHMIPURAM	1	2	21	\N	KGBV GUMMALAKSHMIPURAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120207607	{"id": "28120207607", "block": "Gummalakshm Ipuram", "state": "Andhra Pradesh", "udise": "28120207607", "school": "KGBV GUMMALAKSHMIPURAM", "district": "Parvathipu Ram Manyam", "enrollment": 283}	teacher-training-schools	\N	\N	\N	1	f
22	28120400708	KGBV JIYYAMMAVALASA	1	2	22	\N	KGBV JIYYAMMAVALASA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120400708	{"id": "28120400708", "block": "Jiyyammavala Sa", "state": "Andhra Pradesh", "udise": "28120400708", "school": "KGBV JIYYAMMAVALASA", "district": "Parvathipu Ram Manyam", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
23	28120105413	KGBV KOMARADA	1	2	23	\N	KGBV KOMARADA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120105413	{"id": "28120105413", "block": "Komarada", "state": "Andhra Pradesh", "udise": "28120105413", "school": "KGBV KOMARADA", "district": "Parvathipu Ram Manyam", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
24	28120305823	KGBV KURUPAM	1	2	24	\N	KGBV KURUPAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120305823	{"id": "28120305823", "block": "Kurupam", "state": "Andhra Pradesh", "udise": "28120305823", "school": "KGBV KURUPAM", "district": "Parvathipu Ram Manyam", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
25	28120704721	KGBV MAKKUVA	1	2	25	\N	KGBV MAKKUVA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120704721	{"id": "28120704721", "block": "Makkuva", "state": "Andhra Pradesh", "udise": "28120704721", "school": "KGBV MAKKUVA", "district": "Parvathipu Ram Manyam", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
26	28121200704	KGBV PACHIPENTA	1	2	26	\N	KGBV PACHIPENTA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28121200704	{"id": "28121200704", "block": "Pachipenta", "state": "Andhra Pradesh", "udise": "28121200704", "school": "KGBV PACHIPENTA", "district": "Parvathipu Ram Manyam", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
27	28111304718	KGBV SEETHAMPETA	1	2	27	\N	KGBV SEETHAMPETA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28111304718	{"id": "28111304718", "block": "Seethampeta", "state": "Andhra Pradesh", "udise": "28111304718", "school": "KGBV SEETHAMPETA", "district": "Parvathipu Ram Manyam", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
28	28120802210	KGBV SEETHANAGARAM	1	2	28	\N	KGBV SEETHANAGARAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28120802210	{"id": "28120802210", "block": "Seethanagara M", "state": "Andhra Pradesh", "udise": "28120802210", "school": "KGBV SEETHANAGARAM", "district": "Parvathipu Ram Manyam", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
29	28122600117	KGBV BHOGAPURAM	1	3	29	\N	KGBV BHOGAPURAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122600117	{"id": "28122600117", "block": "Bhogapuram", "state": "Andhra Pradesh", "udise": "28122600117", "school": "KGBV BHOGAPURAM", "district": "Vizainagar Am", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
30	28121090173	KGBV BOBBILI	1	3	30	\N	KGBV BOBBILI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28121090173	{"id": "28121090173", "block": "Bobbili", "state": "Andhra Pradesh", "udise": "28121090173", "school": "KGBV BOBBILI", "district": "Vizainagar Am", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
31	28122300231	KGBV CHEEPURUPALLI	1	3	31	\N	KGBV CHEEPURUPALLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122300231	{"id": "28122300231", "block": "Cheepurupalli", "state": "Andhra Pradesh", "udise": "28122300231", "school": "KGBV CHEEPURUPALLI", "district": "Vizainagar Am", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
32	28122702706	KGBV DENKADA	1	3	32	\N	KGBV DENKADA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122702706	{"id": "28122702706", "block": "Denkada", "state": "Andhra Pradesh", "udise": "28122702706", "school": "KGBV DENKADA", "district": "Vizainagar Am", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
33	28122903212	KGBV GANTYADA	1	3	33	\N	KGBV GANTYADA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122903212	{"id": "28122903212", "block": "Gantyada", "state": "Andhra Pradesh", "udise": "28122903212", "school": "KGBV GANTYADA", "district": "Vizainagar Am", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
34	28122202801	KGBV GARIVIDI	1	3	34	\N	KGBV GARIVIDI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122202801	{"id": "28122202801", "block": "Garividi", "state": "Andhra Pradesh", "udise": "28122202801", "school": "KGBV GARIVIDI", "district": "Vizainagar Am", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
35	28122103504	KGBV GURLA	1	3	35	\N	KGBV GURLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122103504	{"id": "28122103504", "block": "Gurla", "state": "Andhra Pradesh", "udise": "28122103504", "school": "KGBV GURLA", "district": "Vizainagar Am", "enrollment": 282}	teacher-training-schools	\N	\N	\N	1	f
36	28123490716	KGBV KOTHAVALASA	1	3	36	\N	KGBV KOTHAVALASA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28123490716	{"id": "28123490716", "block": "Kothavalasa", "state": "Andhra Pradesh", "udise": "28123490716", "school": "KGBV KOTHAVALASA", "district": "Vizainagar Am", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
37	28122490825	KGBV NELLIMARLA	1	3	37	\N	KGBV NELLIMARLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28122490825	{"id": "28122490825", "block": "Nellimarla", "state": "Andhra Pradesh", "udise": "28122490825", "school": "KGBV NELLIMARLA", "district": "Vizainagar Am", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
38	28121300611	KGBV R.B.PURAM	1	3	38	\N	KGBV R.B.PURAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28121300611	{"id": "28121300611", "block": "R.b.puram", "state": "Andhra Pradesh", "udise": "28121300611", "school": "KGBV R.B.PURAM", "district": "Vizainagar Am", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
39	28110490422	KGBV RAJAM	1	3	39	\N	KGBV RAJAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110490422	{"id": "28110490422", "block": "Rajam", "state": "Andhra Pradesh", "udise": "28110490422", "school": "KGBV RAJAM", "district": "Vizainagar Am", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
40	28111001804	KGBV SANTHAKAVITI	1	3	40	\N	KGBV SANTHAKAVITI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28111001804	{"id": "28111001804", "block": "Santhakaviti", "state": "Andhra Pradesh", "udise": "28111001804", "school": "KGBV SANTHAKAVITI", "district": "Vizainagar Am", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
41	28121502410	KGBV THERLAM	1	3	41	\N	KGBV THERLAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28121502410	{"id": "28121502410", "block": "Therlam", "state": "Andhra Pradesh", "udise": "28121502410", "school": "KGBV THERLAM", "district": "Vizainagar Am", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
42	28110201703	KGBV VANGARA	1	3	42	\N	KGBV VANGARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28110201703	{"id": "28110201703", "block": "Vangara", "state": "Andhra Pradesh", "udise": "28110201703", "school": "KGBV VANGARA", "district": "Vizainagar Am", "enrollment": 285}	teacher-training-schools	\N	\N	\N	1	f
43	28123101009	KGBV VEPADA	1	3	43	\N	KGBV VEPADA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28123101009	{"id": "28123101009", "block": "Vepada", "state": "Andhra Pradesh", "udise": "28123101009", "school": "KGBV VEPADA", "district": "Vizainagar Am", "enrollment": 283}	teacher-training-schools	\N	\N	\N	1	f
44	28132502010	KGBV Anadapuram	1	4	44	\N	KGBV Anadapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132502010	{"id": "28132502010", "block": "Anadapuram", "state": "Andhra Pradesh", "udise": "28132502010", "school": "KGBV Anadapuram", "district": "Visakhapat Nam", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
45	28132790255	KGBV Bheemunipatnam	1	4	45	\N	KGBV Bheemunipatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132790255	{"id": "28132790255", "block": "Bheemunipatnam", "state": "Andhra Pradesh", "udise": "28132790255", "school": "KGBV Bheemunipatnam", "district": "Visakhapat Nam", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
251	22260804718	Rajpur	4	55	244	\N	Rajpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22260804718	{"id": "22260804718", "block": "Rajpur", "state": "Chhattisgarh", "udise": "22260804718", "school": "Rajpur", "district": "Balrampur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
46	28132601107	KGBV Padmanabham	1	4	46	\N	KGBV Padmanabham	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132601107	{"id": "28132601107", "block": "Padmanabham", "state": "Andhra Pradesh", "udise": "28132601107", "school": "KGBV Padmanabham", "district": "Visakhapat Nam", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
47	28132101636	KGBV Chodavaram	1	5	47	\N	KGBV Chodavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132101636	{"id": "28132101636", "block": "Chodavaram", "state": "Andhra Pradesh", "udise": "28132101636", "school": "KGBV Chodavaram", "district": "Anakapalli", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
48	28130700602	KGBV Deverapalli	1	5	48	\N	KGBV Deverapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130700602	{"id": "28130700602", "block": "Deverapalli", "state": "Andhra Pradesh", "udise": "28130700602", "school": "KGBV Deverapalli", "district": "Anakapalli", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
49	28133902313	KGBV Nakkapalli	1	5	49	\N	KGBV Nakkapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28133902313	{"id": "28133902313", "block": "Nakkapalli", "state": "Andhra Pradesh", "udise": "28133902313", "school": "KGBV Nakkapalli", "district": "Anakapalli", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
50	28132202010	KGBV K Kotapadu	1	5	50	\N	KGBV K Kotapadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132202010	{"id": "28132202010", "block": "K Kotapadu", "state": "Andhra Pradesh", "udise": "28132202010", "school": "KGBV K Kotapadu", "district": "Anakapalli", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
51	28134000711	KGBV S.Rayavaram	1	5	51	\N	KGBV S.Rayavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28134000711	{"id": "28134000711", "block": "S.rayavaram", "state": "Andhra Pradesh", "udise": "28134000711", "school": "KGBV S.Rayavaram", "district": "Anakapalli", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
52	28131802406	KGBV Rolugunta	1	5	52	\N	KGBV Rolugunta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131802406	{"id": "28131802406", "block": "Rolugunta", "state": "Andhra Pradesh", "udise": "28131802406", "school": "KGBV Rolugunta", "district": "Anakapalli", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
53	28132301320	KGBV Sabbavaram	1	5	53	\N	KGBV Sabbavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132301320	{"id": "28132301320", "block": "Sabbavaram", "state": "Andhra Pradesh", "udise": "28132301320", "school": "KGBV Sabbavaram", "district": "Anakapalli", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
54	28133701517	KGBV KOTAURATLA	1	5	54	\N	KGBV KOTAURATLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28133701517	{"id": "28133701517", "block": "Kotauratla", "state": "Andhra Pradesh", "udise": "28133701517", "school": "KGBV KOTAURATLA", "district": "Anakapalli", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
55	28131501009	KGBV GOLUGONDA	1	5	55	\N	KGBV GOLUGONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131501009	{"id": "28131501009", "block": "Golugonda", "state": "Andhra Pradesh", "udise": "28131501009", "school": "KGBV GOLUGONDA", "district": "Anakapalli", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
56	28131790617	KGBV Narsipatnam	1	5	56	\N	KGBV Narsipatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131790617	{"id": "28131790617", "block": "Narsipatnam", "state": "Andhra Pradesh", "udise": "28131790617", "school": "KGBV Narsipatnam", "district": "Anakapalli", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
57	28131601211	KGBV Nathavaram	1	5	57	\N	KGBV Nathavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131601211	{"id": "28131601211", "block": "Nathavaram", "state": "Andhra Pradesh", "udise": "28131601211", "school": "KGBV Nathavaram", "district": "Anakapalli", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
58	28133601609	KGBV Makavarapalem	1	5	58	\N	KGBV Makavarapalem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28133601609	{"id": "28133601609", "block": "Makavarapalem", "state": "Andhra Pradesh", "udise": "28133601609", "school": "KGBV Makavarapalem", "district": "Anakapalli", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
59	28131901914	KGBV Ravikamatham	1	5	59	\N	KGBV Ravikamatham	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131901914	{"id": "28131901914", "block": "Ravikamatham", "state": "Andhra Pradesh", "udise": "28131901914", "school": "KGBV Ravikamatham", "district": "Anakapalli", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
60	28132000511	KGBV VADDADI, BUTCHIAHPETA	1	5	60	\N	KGBV VADDADI, BUTCHIAHPETA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28132000511	{"id": "28132000511", "block": "Vaddadi, Butchiahpeta", "state": "Andhra Pradesh", "udise": "28132000511", "school": "KGBV VADDADI, BUTCHIAHPETA", "district": "Anakapalli", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
61	28131404007	KGBV Koyyuru	1	6	61	\N	KGBV Koyyuru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131404007	{"id": "28131404007", "block": "Koyyuru", "state": "Andhra Pradesh", "udise": "28131404007", "school": "KGBV Koyyuru", "district": "Asr", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
62	28130307404	KGBV Hukumpeta	1	6	62	\N	KGBV Hukumpeta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130307404	{"id": "28130307404", "block": "Hukumpeta", "state": "Andhra Pradesh", "udise": "28130307404", "school": "KGBV Hukumpeta", "district": "Asr", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
63	28130115706	KGBV Munchingput	1	6	63	\N	KGBV Munchingput	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130115706	{"id": "28130115706", "block": "Munchingput", "state": "Andhra Pradesh", "udise": "28130115706", "school": "KGBV Munchingput", "district": "Asr", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
64	28130202713	KGBV Pedabayalu	1	6	64	\N	KGBV Pedabayalu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130202713	{"id": "28130202713", "block": "Pedabayalu", "state": "Andhra Pradesh", "udise": "28130202713", "school": "KGBV Pedabayalu", "district": "Asr", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
65	28130607808	KGBV Ananthagiri	1	6	65	\N	KGBV Ananthagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130607808	{"id": "28130607808", "block": "Ananthagiri", "state": "Andhra Pradesh", "udise": "28130607808", "school": "KGBV Ananthagiri", "district": "Asr", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
66	28131003502	KGBV Paderu	1	6	66	\N	KGBV Paderu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131003502	{"id": "28131003502", "block": "Paderu", "state": "Andhra Pradesh", "udise": "28131003502", "school": "KGBV Paderu", "district": "Asr", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
67	28131210107	KGBV Chintapalli	1	6	67	\N	KGBV Chintapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131210107	{"id": "28131210107", "block": "Chintapalli", "state": "Andhra Pradesh", "udise": "28131210107", "school": "KGBV Chintapalli", "district": "Asr", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
68	28131112202	KGBV G. Madugula	1	6	68	\N	KGBV G. Madugula	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131112202	{"id": "28131112202", "block": "G. Madugula", "state": "Andhra Pradesh", "udise": "28131112202", "school": "KGBV G. Madugula", "district": "Asr", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
69	28131306709	KGBV G.K. Veedhi	1	6	69	\N	KGBV G.K. Veedhi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28131306709	{"id": "28131306709", "block": "G.k. Veedhi", "state": "Andhra Pradesh", "udise": "28131306709", "school": "KGBV G.K. Veedhi", "district": "Asr", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
70	28130590512	KGBV Araku	1	6	70	\N	KGBV Araku	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130590512	{"id": "28130590512", "block": "Araku", "state": "Andhra Pradesh", "udise": "28130590512", "school": "KGBV Araku", "district": "Asr", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
71	28130404607	KGBV Dumbriguda	1	6	71	\N	KGBV Dumbriguda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28130404607	{"id": "28130404607", "block": "Dumbriguda", "state": "Andhra Pradesh", "udise": "28130404607", "school": "KGBV Dumbriguda", "district": "Asr", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
72	28146205320	KGBV Chinturu	1	6	72	\N	KGBV Chinturu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28146205320	{"id": "28146205320", "block": "Chinturu", "state": "Andhra Pradesh", "udise": "28146205320", "school": "KGBV Chinturu", "district": "Asr", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
73	28141305603	KGBV Rampachodavaram	1	6	73	\N	KGBV Rampachodavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28141305603	{"id": "28141305603", "block": "Rampachodavaram", "state": "Andhra Pradesh", "udise": "28141305603", "school": "KGBV Rampachodavaram", "district": "Asr", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
74	28141203808	KGBV Gangavaram	1	6	74	\N	KGBV Gangavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28141203808	{"id": "28141203808", "block": "Gangavaram", "state": "Andhra Pradesh", "udise": "28141203808", "school": "KGBV Gangavaram", "district": "Asr", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
75	28140104906	KGBV Maredumilli	1	6	75	\N	KGBV Maredumilli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28140104906	{"id": "28140104906", "block": "Maredumilli", "state": "Andhra Pradesh", "udise": "28140104906", "school": "KGBV Maredumilli", "district": "Asr", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
76	28140903008	KGBV Sankhavaram	1	7	76	\N	KGBV Sankhavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28140903008	{"id": "28140903008", "block": "Sankhavaram", "state": "Andhra Pradesh", "udise": "28140903008", "school": "KGBV Sankhavaram", "district": "Kakinada", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
77	28140602307	KGBV Tuni	1	7	77	\N	KGBV Tuni	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28140602307	{"id": "28140602307", "block": "Tuni", "state": "Andhra Pradesh", "udise": "28140602307", "school": "KGBV Tuni", "district": "Kakinada", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
78	28140501112	KGBV Kotananduru	1	7	78	\N	KGBV Kotananduru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28140501112	{"id": "28140501112", "block": "Kotananduru", "state": "Andhra Pradesh", "udise": "28140501112", "school": "KGBV Kotananduru", "district": "Kakinada", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
79	28140700919	KGBV Thondangi	1	7	79	\N	KGBV Thondangi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28140700919	{"id": "28140700919", "block": "Thondangi", "state": "Andhra Pradesh", "udise": "28140700919", "school": "KGBV Thondangi", "district": "Kakinada", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
80	28161500912	KGBV REDDYGUDEM	1	8	80	\N	KGBV REDDYGUDEM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28161500912	{"id": "28161500912", "block": "Reddygudem", "state": "Andhra Pradesh", "udise": "28161500912", "school": "KGBV REDDYGUDEM", "district": "Ntr", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
81	28161201721	KGBV GAMPALAGUDEM	1	8	81	\N	KGBV GAMPALAGUDEM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28161201721	{"id": "28161201721", "block": "Gampalagude M", "state": "Andhra Pradesh", "udise": "28161201721", "school": "KGBV GAMPALAGUDEM", "district": "Ntr", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
82	28170700812	KGBV Atchampet	1	9	82	\N	KGBV Atchampet	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170700812	{"id": "28170700812", "block": "Atchampet", "state": "Andhra Pradesh", "udise": "28170700812", "school": "KGBV Atchampet", "district": "Palnadu", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
83	28170601310	KGBV Bellamkonda	1	9	83	\N	KGBV Bellamkonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170601310	{"id": "28170601310", "block": "Bellamkonda", "state": "Andhra Pradesh", "udise": "28170601310", "school": "KGBV Bellamkonda", "district": "Palnadu", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
84	28170400818	KGBV Dachepalli	1	9	84	\N	KGBV Dachepalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170400818	{"id": "28170400818", "block": "Dachepalli", "state": "Andhra Pradesh", "udise": "28170400818", "school": "KGBV Dachepalli", "district": "Palnadu", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
85	28171900814	KGBV Durgi	1	9	85	\N	KGBV Durgi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28171900814	{"id": "28171900814", "block": "Durgi", "state": "Andhra Pradesh", "udise": "28171900814", "school": "KGBV Durgi", "district": "Palnadu", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
86	28170300837	KGBV Gurazala	1	9	86	\N	KGBV Gurazala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170300837	{"id": "28170300837", "block": "Gurazala", "state": "Andhra Pradesh", "udise": "28170300837", "school": "KGBV Gurazala", "district": "Palnadu", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
87	28171801024	KGBV Karempudi	1	9	87	\N	KGBV Karempudi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28171801024	{"id": "28171801024", "block": "Karempudi", "state": "Andhra Pradesh", "udise": "28171801024", "school": "KGBV Karempudi", "district": "Palnadu", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
88	28170800416	KGBV Krosuru	1	9	88	\N	KGBV Krosuru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170800416	{"id": "28170800416", "block": "Krosuru", "state": "Andhra Pradesh", "udise": "28170800416", "school": "KGBV Krosuru", "district": "Palnadu", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
89	28170102126	KGBV Macherla	1	9	89	\N	KGBV Macherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170102126	{"id": "28170102126", "block": "Macherla", "state": "Andhra Pradesh", "udise": "28170102126", "school": "KGBV Macherla", "district": "Palnadu", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
90	28172300614	KGBV Muppalla	1	9	90	\N	KGBV Muppalla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28172300614	{"id": "28172300614", "block": "Muppalla", "state": "Andhra Pradesh", "udise": "28172300614", "school": "KGBV Muppalla", "district": "Palnadu", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
91	28172200411	KGBV Nakarikallu	1	9	91	\N	KGBV Nakarikallu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28172200411	{"id": "28172200411", "block": "Nakarikallu", "state": "Andhra Pradesh", "udise": "28172200411", "school": "KGBV Nakarikallu", "district": "Palnadu", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
92	28174401807	KGBV Nuzendla	1	9	92	\N	KGBV Nuzendla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28174401807	{"id": "28174401807", "block": "Nuzendla", "state": "Andhra Pradesh", "udise": "28174401807", "school": "KGBV Nuzendla", "district": "Palnadu", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
93	28171600405	KGBV Rajupalem	1	9	93	\N	KGBV Rajupalem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28171600405	{"id": "28171600405", "block": "Rajupalem", "state": "Andhra Pradesh", "udise": "28171600405", "school": "KGBV Rajupalem", "district": "Palnadu", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
94	28170200531	KGBV Rentachintala	1	9	94	\N	KGBV Rentachintala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28170200531	{"id": "28170200531", "block": "Rentachintala", "state": "Andhra Pradesh", "udise": "28170200531", "school": "KGBV Rentachintala", "district": "Palnadu", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
95	28174000312	KGBV Rompicherla	1	9	95	\N	KGBV Rompicherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28174000312	{"id": "28174000312", "block": "Rompicherla", "state": "Andhra Pradesh", "udise": "28174000312", "school": "KGBV Rompicherla", "district": "Palnadu", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
96	28171590986	KGBV Sattenapalli	1	9	96	\N	KGBV Sattenapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28171590986	{"id": "28171590986", "block": "Sattenapalli", "state": "Andhra Pradesh", "udise": "28171590986", "school": "KGBV Sattenapalli", "district": "Palnadu", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
97	28174301160	KGBV Vinukonda	1	9	97	\N	KGBV Vinukonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28174301160	{"id": "28174301160", "block": "Vinukonda", "state": "Andhra Pradesh", "udise": "28174301160", "school": "KGBV Vinukonda", "district": "Palnadu", "enrollment": 265}	teacher-training-schools	\N	\N	\N	1	f
98	28181700506	KGBV BALLIKURAVA	1	10	98	\N	KGBV BALLIKURAVA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28181700506	{"id": "28181700506", "block": "Ballikurava", "state": "Andhra Pradesh", "udise": "28181700506", "school": "KGBV BALLIKURAVA", "district": "Bapatla", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
99	28184600630	KGBV CHINAGANJAM	1	10	99	\N	KGBV CHINAGANJAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28184600630	{"id": "28184600630", "block": "Chinaganjam", "state": "Andhra Pradesh", "udise": "28184600630", "school": "KGBV CHINAGANJAM", "district": "Bapatla", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
100	28180800914	KGBV ARDHAVEEDU	1	11	100	\N	KGBV ARDHAVEEDU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28180800914	{"id": "28180800914", "block": "Ardhaveedu", "state": "Andhra Pradesh", "udise": "28180800914", "school": "KGBV ARDHAVEEDU", "district": "Prakasam", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
101	28183700513	KGBV KOMAROLU	1	11	101	\N	KGBV KOMAROLU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28183700513	{"id": "28183700513", "block": "Komarolu", "state": "Andhra Pradesh", "udise": "28183700513", "school": "KGBV KOMAROLU", "district": "Prakasam", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
102	28184700326	KGBV KOTHAPATNAM	1	11	102	\N	KGBV KOTHAPATNAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28184700326	{"id": "28184700326", "block": "Kothapatnam", "state": "Andhra Pradesh", "udise": "28184700326", "school": "KGBV KOTHAPATNAM", "district": "Prakasam", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
103	28180401113	KGBV KURICHEDU	1	11	103	\N	KGBV KURICHEDU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28180401113	{"id": "28180401113", "block": "Kurichedu", "state": "Andhra Pradesh", "udise": "28180401113", "school": "KGBV KURICHEDU", "district": "Prakasam", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
104	28180990461	KGBV MARKAPUR	1	11	104	\N	KGBV MARKAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28180990461	{"id": "28180990461", "block": "Markapur", "state": "Andhra Pradesh", "udise": "28180990461", "school": "KGBV MARKAPUR", "district": "Prakasam", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
105	28180601308	KGBV PEDDARAVEEDU	1	11	105	\N	KGBV PEDDARAVEEDU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28180601308	{"id": "28180601308", "block": "Peddaraveedu", "state": "Andhra Pradesh", "udise": "28180601308", "school": "KGBV PEDDARAVEEDU", "district": "Prakasam", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
106	28181500516	KGBV TALLUR	1	11	106	\N	KGBV TALLUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28181500516	{"id": "28181500516", "block": "Tallur", "state": "Andhra Pradesh", "udise": "28181500516", "school": "KGBV TALLUR", "district": "Prakasam", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
107	28181001415	KGBV TARLUPADU	1	11	107	\N	KGBV TARLUPADU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28181001415	{"id": "28181001415", "block": "Tarlupadu", "state": "Andhra Pradesh", "udise": "28181001415", "school": "KGBV TARLUPADU", "district": "Prakasam", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
108	28180101731	KGBV Y.PALEM	1	11	108	\N	KGBV Y.PALEM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28180101731	{"id": "28180101731", "block": "Y.palem", "state": "Andhra Pradesh", "udise": "28180101731", "school": "KGBV Y.PALEM", "district": "Prakasam", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
109	28184902010	KGBV ZARUGUMALLI	1	11	109	\N	KGBV ZARUGUMALLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28184902010	{"id": "28184902010", "block": "Zarugumalli", "state": "Andhra Pradesh", "udise": "28184902010", "school": "KGBV ZARUGUMALLI", "district": "Prakasam", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
110	28190300505	KGBV Kondapuram	1	12	110	\N	KGBV Kondapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28190300505	{"id": "28190300505", "block": "Kondapuram", "state": "Andhra Pradesh", "udise": "28190300505", "school": "KGBV Kondapuram", "district": "Sps Nellore", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
111	28190501036	KGBV Kavali	1	12	111	\N	KGBV Kavali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28190501036	{"id": "28190501036", "block": "Kavali", "state": "Andhra Pradesh", "udise": "28190501036", "school": "KGBV Kavali", "district": "Sps Nellore", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
112	28190700622	KGBV Kaligiri	1	12	112	\N	KGBV Kaligiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28190700622	{"id": "28190700622", "block": "Kaligiri", "state": "Andhra Pradesh", "udise": "28190700622", "school": "KGBV Kaligiri", "district": "Sps Nellore", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
113	28191101012	KGBV Marripadu	1	12	113	\N	KGBV Marripadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28191101012	{"id": "28191101012", "block": "Marripadu", "state": "Andhra Pradesh", "udise": "28191101012", "school": "KGBV Marripadu", "district": "Sps Nellore", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
114	28191300913	KGBV A.S.Peta	1	12	114	\N	KGBV A.S.Peta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28191300913	{"id": "28191300913", "block": "A.s.peta", "state": "Andhra Pradesh", "udise": "28191300913", "school": "KGBV A.S.Peta", "district": "Sps Nellore", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
115	28185400721	KGBV GUDLURU	1	12	115	\N	KGBV GUDLURU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28185400721	{"id": "28185400721", "block": "Gudluru", "state": "Andhra Pradesh", "udise": "28185400721", "school": "KGBV GUDLURU", "district": "Sps Nellore", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
116	28236501605	KGBV Gudupalle	1	13	116	\N	KGBV Gudupalle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28236501605	{"id": "28236501605", "block": "Gudupalle", "state": "Andhra Pradesh", "udise": "28236501605", "school": "KGBV Gudupalle", "district": "Chittoor", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
117	28233000418	KGBV Rompicherla	1	13	117	\N	KGBV Rompicherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28233000418	{"id": "28233000418", "block": "Rompicherla", "state": "Andhra Pradesh", "udise": "28233000418", "school": "KGBV Rompicherla", "district": "Chittoor", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
118	28236404102	KGBV Santhipuram	1	13	118	\N	KGBV Santhipuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28236404102	{"id": "28236404102", "block": "Santhipuram", "state": "Andhra Pradesh", "udise": "28236404102", "school": "KGBV Santhipuram", "district": "Chittoor", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
119	28236101313	KGBV Baireddipalle	1	13	119	\N	KGBV Baireddipalle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28236101313	{"id": "28236101313", "block": "Baireddipalle", "state": "Andhra Pradesh", "udise": "28236101313", "school": "KGBV Baireddipalle", "district": "Chittoor", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
120	28233790861	KGBV Punganur	1	13	120	\N	KGBV Punganur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28233790861	{"id": "28233790861", "block": "Punganur", "state": "Andhra Pradesh", "udise": "28233790861", "school": "KGBV Punganur", "district": "Chittoor", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
121	28236601305	KGBV Kuppam	1	13	121	\N	KGBV Kuppam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28236601305	{"id": "28236601305", "block": "Kuppam", "state": "Andhra Pradesh", "udise": "28236601305", "school": "KGBV Kuppam", "district": "Chittoor", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
122	28235901420	KGBV Gangavaram	1	13	122	\N	KGBV Gangavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28235901420	{"id": "28235901420", "block": "Gangavaram", "state": "Andhra Pradesh", "udise": "28235901420", "school": "KGBV Gangavaram", "district": "Chittoor", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
123	28236302205	KGBV Ramakuppam	1	13	123	\N	KGBV Ramakuppam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28236302205	{"id": "28236302205", "block": "Ramakuppam", "state": "Andhra Pradesh", "udise": "28236302205", "school": "KGBV Ramakuppam", "district": "Chittoor", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
124	28193590532	KGBV Venkatagiri	1	14	124	\N	KGBV Venkatagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28193590532	{"id": "28193590532", "block": "Venkatagiri", "state": "Andhra Pradesh", "udise": "28193590532", "school": "KGBV Venkatagiri", "district": "Tirupati", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
125	28194401713	KGBV D.V.Satram	1	14	125	\N	KGBV D.V.Satram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28194401713	{"id": "28194401713", "block": "D.v.satram", "state": "Andhra Pradesh", "udise": "28194401713", "school": "KGBV D.V.Satram", "district": "Tirupati", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
126	28232302304	KGBV Puram	1	14	126	\N	KGBV Puram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28232302304	{"id": "28232302304", "block": "Puram", "state": "Andhra Pradesh", "udise": "28232302304", "school": "KGBV Puram", "district": "Tirupati", "enrollment": 313}	teacher-training-schools	\N	\N	\N	1	f
127	28231000809	KGBV Yerravaripalem	1	14	127	\N	KGBV Yerravaripalem	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28231000809	{"id": "28231000809", "block": "Yerravaripalem", "state": "Andhra Pradesh", "udise": "28231000809", "school": "KGBV Yerravaripalem", "district": "Tirupati", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
128	28200801109	KGBV B.Kodur	1	15	128	\N	KGBV B.Kodur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28200801109	{"id": "28200801109", "block": "B.kodur", "state": "Andhra Pradesh", "udise": "28200801109", "school": "KGBV B.Kodur", "district": "Ysr", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
129	28200700624	KGBV B.Mattam	1	15	129	\N	KGBV B.Mattam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28200700624	{"id": "28200700624", "block": "B.mattam", "state": "Andhra Pradesh", "udise": "28200700624", "school": "KGBV B.Mattam", "district": "Ysr", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
130	28201401307	KGBV Chapadu	1	15	130	\N	KGBV Chapadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28201401307	{"id": "28201401307", "block": "Chapadu", "state": "Andhra Pradesh", "udise": "28201401307", "school": "KGBV Chapadu", "district": "Ysr", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
131	28201001239	KGBV Porumamilla	1	15	131	\N	KGBV Porumamilla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28201001239	{"id": "28201001239", "block": "Porumamilla", "state": "Andhra Pradesh", "udise": "28201001239", "school": "KGBV Porumamilla", "district": "Ysr", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
132	28200601538	KGBV Mydukur	1	15	132	\N	KGBV Mydukur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28200601538	{"id": "28200601538", "block": "Mydukur", "state": "Andhra Pradesh", "udise": "28200601538", "school": "KGBV Mydukur", "district": "Ysr", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
133	28202101010	KGBV Vemula	1	15	133	\N	KGBV Vemula	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28202101010	{"id": "28202101010", "block": "Vemula", "state": "Andhra Pradesh", "udise": "28202101010", "school": "KGBV Vemula", "district": "Ysr", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
134	28203600545	KGBV L.R.Palli	1	16	134	\N	KGBV L.R.Palli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28203600545	{"id": "28203600545", "block": "L.r.palli", "state": "Andhra Pradesh", "udise": "28203600545", "school": "KGBV L.R.Palli", "district": "Annamayya", "enrollment": 265}	teacher-training-schools	\N	\N	\N	1	f
135	28204601311	KGBV T.Sundupalli	1	16	135	\N	KGBV T.Sundupalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28204601311	{"id": "28204601311", "block": "T.sundupalli", "state": "Andhra Pradesh", "udise": "28204601311", "school": "KGBV T.Sundupalli", "district": "Annamayya", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
136	28230801543	KGBV Kalakada	1	16	136	\N	KGBV Kalakada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28230801543	{"id": "28230801543", "block": "Kalakada", "state": "Andhra Pradesh", "udise": "28230801543", "school": "KGBV Kalakada", "district": "Annamayya", "enrollment": 265}	teacher-training-schools	\N	\N	\N	1	f
137	28230900913	KGBV KV Palle	1	16	137	\N	KGBV KV Palle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28230900913	{"id": "28230900913", "block": "Kv Palle", "state": "Andhra Pradesh", "udise": "28230900913", "school": "KGBV KV Palle", "district": "Annamayya", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
138	28233400816	KGBV Nimmanapalle	1	16	138	\N	KGBV Nimmanapalle	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28233400816	{"id": "28233400816", "block": "Nimmanapalle", "state": "Andhra Pradesh", "udise": "28233400816", "school": "KGBV Nimmanapalle", "district": "Annamayya", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
139	28222400426	KGBV Atmakur	1	17	139	\N	KGBV Atmakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222400426	{"id": "28222400426", "block": "Atmakur", "state": "Andhra Pradesh", "udise": "28222400426", "school": "KGBV Atmakur", "district": "Ananthapu R", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
140	28221600313	KGBV Beluguppa	1	17	140	\N	KGBV Beluguppa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221600313	{"id": "28221600313", "block": "Beluguppa", "state": "Andhra Pradesh", "udise": "28221600313", "school": "KGBV Beluguppa", "district": "Ananthapu R", "enrollment": 281}	teacher-training-schools	\N	\N	\N	1	f
141	28220200506	KGBV Bommanahal	1	17	141	\N	KGBV Bommanahal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28220200506	{"id": "28220200506", "block": "Bommanahal", "state": "Andhra Pradesh", "udise": "28220200506", "school": "KGBV Bommanahal", "district": "Ananthapu R", "enrollment": 273}	teacher-training-schools	\N	\N	\N	1	f
142	28222001109	KGBV Brahma Samudram	1	17	142	\N	KGBV Brahma Samudram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222001109	{"id": "28222001109", "block": "Brahma Samudram", "state": "Andhra Pradesh", "udise": "28222001109", "school": "KGBV Brahma Samudram", "district": "Ananthapu R", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
143	28222601030	KGBV Bukkaraya Samudram	1	17	143	\N	KGBV Bukkaraya Samudram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222601030	{"id": "28222601030", "block": "Bukkaraya Samudram", "state": "Andhra Pradesh", "udise": "28222601030", "school": "KGBV Bukkaraya Samudram", "district": "Ananthapu R", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
144	28220100410	KGBV D Hirehal	1	17	144	\N	KGBV D Hirehal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28220100410	{"id": "28220100410", "block": "D Hirehal", "state": "Andhra Pradesh", "udise": "28220100410", "school": "KGBV D Hirehal", "district": "Ananthapu R", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
145	28221301612	KGBV Garladinne	1	17	145	\N	KGBV Garladinne	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221301612	{"id": "28221301612", "block": "Garladinne", "state": "Andhra Pradesh", "udise": "28221301612", "school": "KGBV Garladinne", "district": "Ananthapu R", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
146	28220600904	KGBV Gooty	1	17	146	\N	KGBV Gooty	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28220600904	{"id": "28220600904", "block": "Gooty", "state": "Andhra Pradesh", "udise": "28220600904", "school": "KGBV Gooty", "district": "Ananthapu R", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
147	28221901107	KGBV Gummagatta	1	17	147	\N	KGBV Gummagatta	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221901107	{"id": "28221901107", "block": "Gummagatta", "state": "Andhra Pradesh", "udise": "28221901107", "school": "KGBV Gummagatta", "district": "Ananthapu R", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
148	28220590512	KGBV Guntakal	1	17	148	\N	KGBV Guntakal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28220590512	{"id": "28220590512", "block": "Guntakal", "state": "Andhra Pradesh", "udise": "28220590512", "school": "KGBV Guntakal", "district": "Ananthapu R", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
149	28222301034	KGBV Kalyandurg	1	17	149	\N	KGBV Kalyandurg	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222301034	{"id": "28222301034", "block": "Kalyandurg", "state": "Andhra Pradesh", "udise": "28222301034", "school": "KGBV Kalyandurg", "district": "Ananthapu R", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
150	28223400919	KGBV Kambadur	1	17	150	\N	KGBV Kambadur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28223400919	{"id": "28223400919", "block": "Kambadur", "state": "Andhra Pradesh", "udise": "28223400919", "school": "KGBV Kambadur", "district": "Ananthapu R", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
151	28221400909	KGBV Kudair	1	17	151	\N	KGBV Kudair	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221400909	{"id": "28221400909", "block": "Kudair", "state": "Andhra Pradesh", "udise": "28221400909", "school": "KGBV Kudair", "district": "Ananthapu R", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
152	28222200716	KGBV Kundurpi	1	17	152	\N	KGBV Kundurpi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222200716	{"id": "28222200716", "block": "Kundurpi", "state": "Andhra Pradesh", "udise": "28222200716", "school": "KGBV Kundurpi", "district": "Ananthapu R", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
153	28222700422	KGBV Narpala	1	17	153	\N	KGBV Narpala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222700422	{"id": "28222700422", "block": "Narpala", "state": "Andhra Pradesh", "udise": "28222700422", "school": "KGBV Narpala", "district": "Ananthapu R", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
154	28221202031	KGBV Pamidi	1	17	154	\N	KGBV Pamidi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221202031	{"id": "28221202031", "block": "Pamidi", "state": "Andhra Pradesh", "udise": "28221202031", "school": "KGBV Pamidi", "district": "Ananthapu R", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
155	28221001307	KGBV Peddapappur	1	17	155	\N	KGBV Peddapappur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221001307	{"id": "28221001307", "block": "Peddapappur", "state": "Andhra Pradesh", "udise": "28221001307", "school": "KGBV Peddapappur", "district": "Ananthapu R", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
156	28223200123	KGBV Rapthadu	1	17	156	\N	KGBV Rapthadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28223200123	{"id": "28223200123", "block": "Rapthadu", "state": "Andhra Pradesh", "udise": "28223200123", "school": "KGBV Rapthadu", "district": "Ananthapu R", "enrollment": 275}	teacher-training-schools	\N	\N	\N	1	f
157	28221890966	KGBV Rayadurg	1	17	157	\N	KGBV Rayadurg	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221890966	{"id": "28221890966", "block": "Rayadurg", "state": "Andhra Pradesh", "udise": "28221890966", "school": "KGBV Rayadurg", "district": "Ananthapu R", "enrollment": 286}	teacher-training-schools	\N	\N	\N	1	f
158	28222100112	KGBV Settur	1	17	158	\N	KGBV Settur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28222100112	{"id": "28222100112", "block": "Settur", "state": "Andhra Pradesh", "udise": "28222100112", "school": "KGBV Settur", "district": "Ananthapu R", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
159	28221591148	KGBV Uravakonda	1	17	159	\N	KGBV Uravakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28221591148	{"id": "28221591148", "block": "Uravakonda", "state": "Andhra Pradesh", "udise": "28221591148", "school": "KGBV Uravakonda", "district": "Ananthapu R", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
160	28220400410	KGBV Vajrakarur	1	17	160	\N	KGBV Vajrakarur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28220400410	{"id": "28220400410", "block": "Vajrakarur", "state": "Andhra Pradesh", "udise": "28220400410", "school": "KGBV Vajrakarur", "district": "Ananthapu R", "enrollment": 269}	teacher-training-schools	\N	\N	\N	1	f
161	28226200813	KGBV Agali	1	18	161	\N	KGBV Agali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28226200813	{"id": "28226200813", "block": "Agali", "state": "Andhra Pradesh", "udise": "28226200813", "school": "KGBV Agali", "district": "Satya Sai", "enrollment": 272}	teacher-training-schools	\N	\N	\N	1	f
162	28226100321	KGBV Amarapuram	1	18	162	\N	KGBV Amarapuram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28226100321	{"id": "28226100321", "block": "Amarapuram", "state": "Andhra Pradesh", "udise": "28226100321", "school": "KGBV Amarapuram", "district": "Satya Sai", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
163	28223100417	KGBV Battalapalli	1	18	163	\N	KGBV Battalapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28223100417	{"id": "28223100417", "block": "Battalapalli", "state": "Andhra Pradesh", "udise": "28223100417", "school": "KGBV Battalapalli", "district": "Satya Sai", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
164	28225000719	KGBV Bukkapatnam	1	18	164	\N	KGBV Bukkapatnam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28225000719	{"id": "28225000719", "block": "Bukkapatnam", "state": "Andhra Pradesh", "udise": "28225000719", "school": "KGBV Bukkapatnam", "district": "Satya Sai", "enrollment": 280}	teacher-training-schools	\N	\N	\N	1	f
165	28223600319	KGBV Chennekothapalli	1	18	165	\N	KGBV Chennekothapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28223600319	{"id": "28223600319", "block": "Chennekothapalli", "state": "Andhra Pradesh", "udise": "28223600319", "school": "KGBV Chennekothapalli", "district": "Satya Sai", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
166	28223790296	KGBV Dharmavaram	1	18	166	\N	KGBV Dharmavaram	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28223790296	{"id": "28223790296", "block": "Dharmavaram", "state": "Andhra Pradesh", "udise": "28223790296", "school": "KGBV Dharmavaram", "district": "Satya Sai", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
167	28224490699	KGBV Kadiri	1	18	167	\N	KGBV Kadiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28224490699	{"id": "28224490699", "block": "Kadiri", "state": "Andhra Pradesh", "udise": "28224490699", "school": "KGBV Kadiri", "district": "Satya Sai", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
168	28225600322	KGBV LEPAKSHI	1	18	168	\N	KGBV LEPAKSHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28225600322	{"id": "28225600322", "block": "Lepakshi", "state": "Andhra Pradesh", "udise": "28225600322", "school": "KGBV LEPAKSHI", "district": "Satya Sai", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
169	28225900832	KGBV Madakasira	1	18	169	\N	KGBV Madakasira	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28225900832	{"id": "28225900832", "block": "Madakasira", "state": "Andhra Pradesh", "udise": "28225900832", "school": "KGBV Madakasira", "district": "Satya Sai", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
170	28224700530	KGBV Nallamada	1	18	170	\N	KGBV Nallamada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28224700530	{"id": "28224700530", "block": "Nallamada", "state": "Andhra Pradesh", "udise": "28224700530", "school": "KGBV Nallamada", "district": "Satya Sai", "enrollment": 265}	teacher-training-schools	\N	\N	\N	1	f
171	28225800922	KGBV Parigi	1	18	171	\N	KGBV Parigi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28225800922	{"id": "28225800922", "block": "Parigi", "state": "Andhra Pradesh", "udise": "28225800922", "school": "KGBV Parigi", "district": "Satya Sai", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
172	28223500609	KGBV Ramagiri	1	18	172	\N	KGBV Ramagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28223500609	{"id": "28223500609", "block": "Ramagiri", "state": "Andhra Pradesh", "udise": "28223500609", "school": "KGBV Ramagiri", "district": "Satya Sai", "enrollment": 282}	teacher-training-schools	\N	\N	\N	1	f
173	28225301121	KGBV Roddam	1	18	173	\N	KGBV Roddam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28225301121	{"id": "28225301121", "block": "Roddam", "state": "Andhra Pradesh", "udise": "28225301121", "school": "KGBV Roddam", "district": "Satya Sai", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
174	28212391339	KGBV Adoni, (M)	1	19	174	\N	KGBV Adoni, (M)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28212391339	{"id": "28212391339", "block": "Adoni, (m)", "state": "Andhra Pradesh", "udise": "28212391339", "school": "KGBV Adoni, (M)", "district": "Kurnool", "enrollment": 284}	teacher-training-schools	\N	\N	\N	1	f
175	28212501416	KGBV Alur	1	19	175	\N	KGBV Alur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28212501416	{"id": "28212501416", "block": "Alur", "state": "Andhra Pradesh", "udise": "28212501416", "school": "KGBV Alur", "district": "Kurnool", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
176	28212601909	KGBV Aspari	1	19	176	\N	KGBV Aspari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28212601909	{"id": "28212601909", "block": "Aspari", "state": "Andhra Pradesh", "udise": "28212601909", "school": "KGBV Aspari", "district": "Kurnool", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
177	28210500913	KGBV C.Belgal	1	19	177	\N	KGBV C.Belgal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28210500913	{"id": "28210500913", "block": "C.belgal", "state": "Andhra Pradesh", "udise": "28210500913", "school": "KGBV C.Belgal", "district": "Kurnool", "enrollment": 285}	teacher-training-schools	\N	\N	\N	1	f
178	28212701212	KGBV Devanakonda	1	19	178	\N	KGBV Devanakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28212701212	{"id": "28212701212", "block": "Devanakonda", "state": "Andhra Pradesh", "udise": "28212701212", "school": "KGBV Devanakonda", "district": "Kurnool", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
179	28210600629	KGBV Gudur	1	19	179	\N	KGBV Gudur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28210600629	{"id": "28210600629", "block": "Gudur", "state": "Andhra Pradesh", "udise": "28210600629", "school": "KGBV Gudur", "district": "Kurnool", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
180	28211800465	KGBV Kallur	1	19	180	\N	KGBV Kallur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28211800465	{"id": "28211800465", "block": "Kallur", "state": "Andhra Pradesh", "udise": "28211800465", "school": "KGBV Kallur", "district": "Kurnool", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
181	28211900338	KGBV Kodumur	1	19	181	\N	KGBV Kodumur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28211900338	{"id": "28211900338", "block": "Kodumur", "state": "Andhra Pradesh", "udise": "28211900338", "school": "KGBV Kodumur", "district": "Kurnool", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
182	28212800505	KGBV Krishnagiri	1	19	182	\N	KGBV Krishnagiri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28212800505	{"id": "28212800505", "block": "Krishnagiri", "state": "Andhra Pradesh", "udise": "28212800505", "school": "KGBV Krishnagiri", "district": "Kurnool", "enrollment": 278}	teacher-training-schools	\N	\N	\N	1	f
183	28210791310	KGBV Kurnool	1	19	183	\N	KGBV Kurnool	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28210791310	{"id": "28210791310", "block": "Kurnool", "state": "Andhra Pradesh", "udise": "28210791310", "school": "KGBV Kurnool", "district": "Kurnool", "enrollment": 288}	teacher-training-schools	\N	\N	\N	1	f
184	28215200201	KGBV Maddikera	1	19	184	\N	KGBV Maddikera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28215200201	{"id": "28215200201", "block": "Maddikera", "state": "Andhra Pradesh", "udise": "28215200201", "school": "KGBV Maddikera", "district": "Kurnool", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
185	28210302109	KGBV Mantralayam	1	19	185	\N	KGBV Mantralayam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28210302109	{"id": "28210302109", "block": "Mantralayam", "state": "Andhra Pradesh", "udise": "28210302109", "school": "KGBV Mantralayam", "district": "Kurnool", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
186	28211701111	KGBV Orvakal	1	19	186	\N	KGBV Orvakal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28211701111	{"id": "28211701111", "block": "Orvakal", "state": "Andhra Pradesh", "udise": "28211701111", "school": "KGBV Orvakal", "district": "Kurnool", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
187	28215100745	KGBV Pathikonda	1	19	187	\N	KGBV Pathikonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28215100745	{"id": "28215100745", "block": "Pathikonda", "state": "Andhra Pradesh", "udise": "28215100745", "school": "KGBV Pathikonda", "district": "Kurnool", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
188	28215000714	KGBV Tuggali	1	19	188	\N	KGBV Tuggali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28215000714	{"id": "28215000714", "block": "Tuggali", "state": "Andhra Pradesh", "udise": "28215000714", "school": "KGBV Tuggali", "district": "Kurnool", "enrollment": 277}	teacher-training-schools	\N	\N	\N	1	f
189	28211100158	KGBV Atmakur	1	20	189	\N	KGBV Atmakur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28211100158	{"id": "28211100158", "block": "Atmakur", "state": "Andhra Pradesh", "udise": "28211100158", "school": "KGBV Atmakur", "district": "Nandyal", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
190	28214403131	KGBV Banaganapalli (M)	1	20	190	\N	KGBV Banaganapalli (M)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28214403131	{"id": "28214403131", "block": "Banaganapalli (m)", "state": "Andhra Pradesh", "udise": "28214403131", "school": "KGBV Banaganapalli (M)", "district": "Nandyal", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
191	28213090229	KGBV Bethamcherla	1	20	191	\N	KGBV Bethamcherla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28213090229	{"id": "28213090229", "block": "Bethamcherla", "state": "Andhra Pradesh", "udise": "28213090229", "school": "KGBV Bethamcherla", "district": "Nandyal", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
192	28213901532	KGBV Chagalamarri	1	20	192	\N	KGBV Chagalamarri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28213901532	{"id": "28213901532", "block": "Chagalamarri", "state": "Andhra Pradesh", "udise": "28213901532", "school": "KGBV Chagalamarri", "district": "Nandyal", "enrollment": 271}	teacher-training-schools	\N	\N	\N	1	f
193	28214200909	KGBV Gospadu	1	20	193	\N	KGBV Gospadu	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28214200909	{"id": "28214200909", "block": "Gospadu", "state": "Andhra Pradesh", "udise": "28214200909", "school": "KGBV Gospadu", "district": "Nandyal", "enrollment": 274}	teacher-training-schools	\N	\N	\N	1	f
194	28213491457	KGBV Nandyal (G)	1	20	194	\N	KGBV Nandyal (G)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28213491457	{"id": "28213491457", "block": "Nandyal (g)", "state": "Andhra Pradesh", "udise": "28213491457", "school": "KGBV Nandyal (G)", "district": "Nandyal", "enrollment": 267}	teacher-training-schools	\N	\N	\N	1	f
195	28213491450	KGBV Nandyal (M)	1	20	195	\N	KGBV Nandyal (M)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28213491450	{"id": "28213491450", "block": "Nandyal (m)", "state": "Andhra Pradesh", "udise": "28213491450", "school": "KGBV Nandyal (M)", "district": "Nandyal", "enrollment": 276}	teacher-training-schools	\N	\N	\N	1	f
196	28213100621	KGBV Panyam	1	20	196	\N	KGBV Panyam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	28213100621	{"id": "28213100621", "block": "Panyam", "state": "Andhra Pradesh", "udise": "28213100621", "school": "KGBV Panyam", "district": "Nandyal", "enrollment": 268}	teacher-training-schools	\N	\N	\N	1	f
197	12010102703	KGBV, Tawang	2	21	197	\N	KGBV, Tawang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12010102703	{"id": "12010102703", "block": "Tawang", "state": "Arunachal Pradesh", "udise": "12010102703", "school": "KGBV, Tawang", "district": "Tawang", "enrollment": 197}	teacher-training-schools	\N	\N	\N	1	f
198	12240402102	KGBV, Pakke- Kesang(Nangnyo	2	22	198	\N	KGBV, Pakke- Kesang(Nangnyo	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12240402102	{"id": "12240402102", "block": "Pakke-kesang", "state": "Arunachal Pradesh", "udise": "12240402102", "school": "KGBV, Pakke- Kesang(Nangnyo", "district": "Pakke-kesang", "enrollment": 262}	teacher-training-schools	\N	\N	\N	1	f
199	12040207001	KGBV, Sagalee	2	23	199	\N	KGBV, Sagalee	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12040207001	{"id": "12040207001", "block": "Sagalee", "state": "Arunachal Pradesh", "udise": "12040207001", "school": "KGBV, Sagalee", "district": "Papum Pare", "enrollment": 184}	teacher-training-schools	\N	\N	\N	1	f
200	12060401502	KGBV, Giba	2	24	200	\N	KGBV, Giba	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12060401502	{"id": "12060401502", "block": "Giba", "state": "Arunachal Pradesh", "udise": "12060401502", "school": "KGBV, Giba", "district": "Upper Subansiri", "enrollment": 350}	teacher-training-schools	\N	\N	\N	1	f
201	12200402107	KGBV, Boleng	2	25	201	\N	KGBV, Boleng	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12200402107	{"id": "12200402107", "block": "Boleng", "state": "Arunachal Pradesh", "udise": "12200402107", "school": "KGBV, Boleng", "district": "Siang", "enrollment": 152}	teacher-training-schools	\N	\N	\N	1	f
202	12180100103	KGBV, Namsai	2	26	202	\N	KGBV, Namsai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12180100103	{"id": "12180100103", "block": "Namsai", "state": "Arunachal Pradesh", "udise": "12180100103", "school": "KGBV, Namsai", "district": "Namsai", "enrollment": 230}	teacher-training-schools	\N	\N	\N	1	f
203	12120300902	KGBV, Maghantong	2	27	203	\N	KGBV, Maghantong	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12120300902	{"id": "12120300902", "block": "Bordumsa", "state": "Arunachal Pradesh", "udise": "12120300902", "school": "KGBV, Maghantong", "district": "Changlang", "enrollment": 323}	teacher-training-schools	\N	\N	\N	1	f
204	12120214001	KGBV, Kharsang	2	27	204	\N	KGBV, Kharsang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12120214001	{"id": "12120214001", "block": "Miao", "state": "Arunachal Pradesh", "udise": "12120214001", "school": "KGBV, Kharsang", "district": "Changlang", "enrollment": 343}	teacher-training-schools	\N	\N	\N	1	f
205	12080301603	KGBV, Mottum	2	28	205	\N	KGBV, Mottum	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12080301603	{"id": "12080301603", "block": "Mebo", "state": "Arunachal Pradesh", "udise": "12080301603", "school": "KGBV, Mottum", "district": "East Siang", "enrollment": 144}	teacher-training-schools	\N	\N	\N	1	f
206	12080300902	KGBV, kiyit	2	28	205	\N	KGBV, kiyit	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12080300902	{"id": "12080300902", "block": "Mebo", "state": "Arunachal Pradesh", "udise": "12080300902", "school": "KGBV, kiyit", "district": "East Siang", "enrollment": 191}	teacher-training-schools	\N	\N	\N	1	f
207	12210202302	KGBV, Seren	2	29	206	\N	KGBV, Seren	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	12210202302	{"id": "12210202302", "block": "Ramle Banggo", "state": "Arunachal Pradesh", "udise": "12210202302", "school": "KGBV, Seren", "district": "Lower Siang", "enrollment": 250}	teacher-training-schools	\N	\N	\N	1	f
208	18260203012	KASTURBA GANDHI BALIKA VIDYALAYA	3	30	207	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18260203012	{"id": "18260203012", "block": "Mazbat", "state": "Assam", "udise": "18260203012", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Udalguri", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
209	18260109509	KASTURBA GANDHI BALIKA VIDYALAYA	3	30	208	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18260109509	{"id": "18260109509", "block": "Khoirabari", "state": "Assam", "udise": "18260109509", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Udalguri", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
210	18140104308	GUIJAN KGBV	3	31	209	\N	GUIJAN KGBV	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18140104308	{"id": "18140104308", "block": "Hapjan", "state": "Assam", "udise": "18140104308", "school": "GUIJAN KGBV", "district": "Tinsukia", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
211	18140111503	HAPJAN KGBV	3	31	209	\N	HAPJAN KGBV	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18140111503	{"id": "18140111503", "block": "Hapjan", "state": "Assam", "udise": "18140111503", "school": "HAPJAN KGBV", "district": "Tinsukia", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
212	18320601921	KGBV, FEKAMARI	3	32	210	\N	KGBV, FEKAMARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18320601921	{"id": "18320601921", "block": "Mankachar", "state": "Assam", "udise": "18320601921", "school": "KGBV, FEKAMARI", "district": "South Salmara-mankachar", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
213	18110207305	KGBV, BORCHALA	3	33	211	\N	KGBV, BORCHALA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18110207305	{"id": "18110207305", "block": "Dhekiajuli", "state": "Assam", "udise": "18110207305", "school": "KGBV, BORCHALA", "district": "Sonitpur", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
214	18110202707	KGBV DHEKIAJULI	3	33	211	\N	KGBV DHEKIAJULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18110202707	{"id": "18110202707", "block": "Dhekiajuli", "state": "Assam", "udise": "18110202707", "school": "KGBV DHEKIAJULI", "district": "Sonitpur", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
215	18100620201	KASTURBA GANDHI BALIKA VIDYALAYA	3	34	212	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18100620201	{"id": "18100620201", "block": "Kaliabor", "state": "Assam", "udise": "18100620201", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Nagaon", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
216	18101105711	KASTURBA GANDHI BALIKA VIDYALAYA	3	34	213	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18101105711	{"id": "18101105711", "block": "Urban", "state": "Assam", "udise": "18101105711", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Nagaon", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
217	18070108814	KGBV, BARKHETRI	3	35	214	\N	KGBV, BARKHETRI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18070108814	{"id": "18070108814", "block": "Barkhetri", "state": "Assam", "udise": "18070108814", "school": "KGBV, BARKHETRI", "district": "Nalbari", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
218	18090115314	KGBV, MOIRABARI	3	36	215	\N	KGBV, MOIRABARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18090115314	{"id": "18090115314", "block": "Laharighat", "state": "Assam", "udise": "18090115314", "school": "KGBV, MOIRABARI", "district": "Morigaon", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
219	18090118112	KGBV LAHARIGHAT	3	36	215	\N	KGBV LAHARIGHAT	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18090118112	{"id": "18090118112", "block": "Laharighat", "state": "Assam", "udise": "18090118112", "school": "KGBV LAHARIGHAT", "district": "Morigaon", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
220	18120400804	KGBV, LAKHIMPUR	3	37	216	\N	KGBV, LAKHIMPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18120400804	{"id": "18120400804", "block": "Lakhimpur", "state": "Assam", "udise": "18120400804", "school": "KGBV, LAKHIMPUR", "district": "Lakhimpur", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
221	18190510615	KGBV LUMBAJONG	3	38	217	\N	KGBV LUMBAJONG	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18190510615	{"id": "18190510615", "block": "Lumbajong", "state": "Assam", "udise": "18190510615", "school": "KGBV LUMBAJONG", "district": "Karbi Anglong", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
222	18191101309	LANGSOMEPI KGBV	3	38	218	\N	LANGSOMEPI KGBV	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18191101309	{"id": "18191101309", "block": "Langsomepi", "state": "Assam", "udise": "18191101309", "school": "LANGSOMEPI KGBV", "district": "Karbi Anglong", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
223	18010300309	KGBV, KACHUGAON	3	39	219	\N	KGBV, KACHUGAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18010300309	{"id": "18010300309", "block": "Kachugaon", "state": "Assam", "udise": "18010300309", "school": "KGBV, KACHUGAON", "district": "Kokrajhar", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
224	18010503309	KGBV, PATGAON	3	39	220	\N	KGBV, PATGAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18010503309	{"id": "18010503309", "block": "Kokrajhar", "state": "Assam", "udise": "18010503309", "school": "KGBV, PATGAON", "district": "Kokrajhar", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
225	18220325104	KASTURBA GANDHI BALIKA VIDYALAYA	3	40	221	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18220325104	{"id": "18220325104", "block": "Patherkandi", "state": "Assam", "udise": "18220325104", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Karimganj", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
226	18230200915	KASTURBA GANDHI BALIKA VIDYALAYA	3	41	222	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18230200915	{"id": "18230200915", "block": "Katlicherra", "state": "Assam", "udise": "18230200915", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Hailakandi", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
227	18030410603	KGBV KHARMUZA	3	42	223	\N	KGBV KHARMUZA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18030410603	{"id": "18030410603", "block": "Balijana", "state": "Assam", "udise": "18030410603", "school": "KGBV KHARMUZA", "district": "Goalpara", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
228	18150406405	KGBV,LAHOAL	3	43	224	\N	KGBV,LAHOAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18150406405	{"id": "18150406405", "block": "Lahoal", "state": "Assam", "udise": "18150406405", "school": "KGBV,LAHOAL", "district": "Dibrugarh", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
250	22261101916	Wadrafnagar	4	55	243	\N	Wadrafnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22261101916	{"id": "22261101916", "block": "Wadrafnagar", "state": "Chhattisgarh", "udise": "22261101916", "school": "Wadrafnagar", "district": "Balrampur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
229	18150503802	KASTURBA GANDHI VALIKA VIDYALAYA	3	43	225	\N	KASTURBA GANDHI VALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18150503802	{"id": "18150503802", "block": "Panitola", "state": "Assam", "udise": "18150503802", "school": "KASTURBA GANDHI VALIKA VIDYALAYA", "district": "Dibrugarh", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
230	18200104902	KASTURBA GANDHI BALIKA VIDYALAYA	3	44	226	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18200104902	{"id": "18200104902", "block": "Diyungbra", "state": "Assam", "udise": "18200104902", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Dima Hasao", "enrollment": 152}	teacher-training-schools	\N	\N	\N	1	f
231	18020339409	JAMADARHAT KGBV	3	45	227	\N	JAMADARHAT KGBV	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18020339409	{"id": "18020339409", "block": "Gauripur", "state": "Assam", "udise": "18020339409", "school": "JAMADARHAT KGBV", "district": "Dhubri", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
232	18020332909	BIRSHING JARUA KGBV	3	45	227	\N	BIRSHING JARUA KGBV	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18020332909	{"id": "18020332909", "block": "Gauripur", "state": "Assam", "udise": "18020332909", "school": "BIRSHING JARUA KGBV", "district": "Dhubri", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
233	18130321903	KASTURBA GANDHI BALIKA BIDYALAYA	3	46	228	\N	KASTURBA GANDHI BALIKA BIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18130321903	{"id": "18130321903", "block": "Murkongsele K", "state": "Assam", "udise": "18130321903", "school": "KASTURBA GANDHI BALIKA BIDYALAYA", "district": "Dhemaji", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
234	18130202002	KASTURBA GANDHI BALIKA VIDYALAYA	3	46	229	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18130202002	{"id": "18130202002", "block": "Dhemaji", "state": "Assam", "udise": "18130202002", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Dhemaji", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
235	18080312502	KASTURBA GANDHI BALIKA VIDYALYA- BECHIMARI	3	47	230	\N	KASTURBA GANDHI BALIKA VIDYALYA- BECHIMARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18080312502	{"id": "18080312502", "block": "Dalgaon", "state": "Assam", "udise": "18080312502", "school": "KASTURBA GANDHI BALIKA VIDYALYA- BECHIMARI", "district": "Darrang", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
236	18290515406	K. GANDHI BALIKA VIDYALAYA	3	48	231	\N	K. GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18290515406	{"id": "18290515406", "block": "Sonari", "state": "Assam", "udise": "18290515406", "school": "K. GANDHI BALIKA VIDYALAYA", "district": "Charaideo", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
237	18250108607	KASTURBA GANDHI BALIKA VIDYALAYA	3	49	232	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18250108607	{"id": "18250108607", "block": "Borobazar", "state": "Assam", "udise": "18250108607", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Chirang", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
238	18210609407	KGBV, TAPANG	3	50	233	\N	KGBV, TAPANG	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18210609407	{"id": "18210609407", "block": "Salchapra", "state": "Assam", "udise": "18210609407", "school": "KGBV, TAPANG", "district": "Cachar", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
239	18280601605	KGBV, BEHALI	3	51	234	\N	KGBV, BEHALI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18280601605	{"id": "18280601605", "block": "Behali", "state": "Assam", "udise": "18280601605", "school": "KGBV, BEHALI", "district": "Biswanath", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
240	18240120315	KASTURBA GANDHI BALIKA VIDYALAYA	3	52	235	\N	KASTURBA GANDHI BALIKA VIDYALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18240120315	{"id": "18240120315", "block": "Jalah", "state": "Assam", "udise": "18240120315", "school": "KASTURBA GANDHI BALIKA VIDYALAYA", "district": "Baksa", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
241	18050205711	KASTURBA GANDHI BALIKA VIDYALAYA,PAKA BETBARI	3	53	236	\N	KASTURBA GANDHI BALIKA VIDYALAYA,PAKA BETBARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18050205711	{"id": "18050205711", "block": "Bhawanipur", "state": "Assam", "udise": "18050205711", "school": "KASTURBA GANDHI BALIKA VIDYALAYA,PAKA BETBARI", "district": "Barpeta", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
242	18050612604	KASTURBA GANDHI BALIKA VIDYALAYA,BARPETA	3	53	237	\N	KASTURBA GANDHI BALIKA VIDYALAYA,BARPETA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18050612604	{"id": "18050612604", "block": "Barpeta", "state": "Assam", "udise": "18050612604", "school": "KASTURBA GANDHI BALIKA VIDYALAYA,BARPETA", "district": "Barpeta", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
243	18050710303	KASTURBA GANDHI BALIKA BIDYALAYA,GOBARDHAN A	3	53	238	\N	KASTURBA GANDHI BALIKA BIDYALAYA,GOBARDHAN A	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18050710303	{"id": "18050710303", "block": "Gobardhana", "state": "Assam", "udise": "18050710303", "school": "KASTURBA GANDHI BALIKA BIDYALAYA,GOBARDHAN A", "district": "Barpeta", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
244	18080313505	KASTURBA GANDHI BALIKA VIDYALAYA - DALGAON SIALMARI	3	47	230	\N	KASTURBA GANDHI BALIKA VIDYALAYA - DALGAON SIALMARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18080313505	{"id": "18080313505", "block": "Dalgaon", "state": "Assam", "udise": "18080313505", "school": "KASTURBA GANDHI BALIKA VIDYALAYA - DALGAON SIALMARI", "district": "Darrang", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
245	18080306607	KASTURBA GANDHI BALIKA VIDYALAYA - PUB MANGALDAI	3	47	230	\N	KASTURBA GANDHI BALIKA VIDYALAYA - PUB MANGALDAI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18080306607	{"id": "18080306607", "block": "Dalgaon", "state": "Assam", "udise": "18080306607", "school": "KASTURBA GANDHI BALIKA VIDYALAYA - PUB MANGALDAI", "district": "Darrang", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
246	18020110717	GOLAKGANJ KGVB	3	45	239	\N	GOLAKGANJ KGVB	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18020110717	{"id": "18020110717", "block": "Golakganj", "state": "Assam", "udise": "18020110717", "school": "GOLAKGANJ KGVB", "district": "Dhubri", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
247	18050514303	KASTURBA GANDHIBALIKA VIDYALAYA,CHENGA	3	53	240	\N	KASTURBA GANDHIBALIKA VIDYALAYA,CHENGA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	18050514303	{"id": "18050514303", "block": "Chenga", "state": "Assam", "udise": "18050514303", "school": "KASTURBA GANDHIBALIKA VIDYALAYA,CHENGA", "district": "Barpeta", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
248	22242002918	Balodabazar	4	54	241	\N	Balodabazar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22242002918	{"id": "22242002918", "block": "Balodabazar", "state": "Chhattisgarh", "udise": "22242002918", "school": "Balodabazar", "district": "Balodabazar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
249	22240204103	Bhatapara	4	54	242	\N	Bhatapara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22240204103	{"id": "22240204103", "block": "Bhatapara", "state": "Chhattisgarh", "udise": "22240204103", "school": "Bhatapara", "district": "Balodabazar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
252	22152300323	Bademordhapal	4	56	245	\N	Bademordhapal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22152300323	{"id": "22152300323", "block": "Tokapal", "state": "Chhattisgarh", "udise": "22152300323", "school": "Bademordhapal", "district": "Baster", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
253	22230204213	Bemetara	4	57	246	\N	Bemetara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22230204213	{"id": "22230204213", "block": "Bemetara", "state": "Chhattisgarh", "udise": "22230204213", "school": "Bemetara", "district": "Bemetara", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
254	22200600416	Bijapur	4	58	247	\N	Bijapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22200600416	{"id": "22200600416", "block": "Bijapur", "state": "Chhattisgarh", "udise": "22200600416", "school": "Bijapur", "district": "Bijapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
255	22203102716	Bhiramgarh	4	58	248	\N	Bhiramgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22203102716	{"id": "22203102716", "block": "Bhiramgarh", "state": "Chhattisgarh", "udise": "22203102716", "school": "Bhiramgarh", "district": "Bijapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
256	22201415001	Awapalli	4	58	249	\N	Awapalli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22201415001	{"id": "22201415001", "block": "Usoor", "state": "Chhattisgarh", "udise": "22201415001", "school": "Awapalli", "district": "Bijapur", "enrollment": 166}	teacher-training-schools	\N	\N	\N	1	f
257	22160805717	Geedam	4	59	250	\N	Geedam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22160805717	{"id": "22160805717", "block": "Geedam", "state": "Chhattisgarh", "udise": "22160805717", "school": "Geedam", "district": "Dantewada", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
258	22161917502	kuakonda	4	59	251	\N	kuakonda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22161917502	{"id": "22161917502", "block": "Kuakonda", "state": "Chhattisgarh", "udise": "22161917502", "school": "kuakonda", "district": "Dantewada", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
259	22161501209	Katekalyan	4	59	252	\N	Katekalyan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22161501209	{"id": "22161501209", "block": "Katekalyan", "state": "Chhattisgarh", "udise": "22161501209", "school": "Katekalyan", "district": "Dantewada", "enrollment": 191}	teacher-training-schools	\N	\N	\N	1	f
260	22252611608	Mainpur	4	60	253	\N	Mainpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22252611608	{"id": "22252611608", "block": "Mainpur", "state": "Chhattisgarh", "udise": "22252611608", "school": "Mainpur", "district": "Gariyaband", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
261	22251402804	Devbhog	4	60	254	\N	Devbhog	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22251402804	{"id": "22251402804", "block": "Devbhog", "state": "Chhattisgarh", "udise": "22251402804", "school": "Devbhog", "district": "Gariyaband", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
262	22081221103	S. Lohara	4	61	255	\N	S. Lohara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22081221103	{"id": "22081221103", "block": "S. Lohara", "state": "Chhattisgarh", "udise": "22081221103", "school": "S. Lohara", "district": "Kabirdham", "enrollment": 160}	teacher-training-schools	\N	\N	\N	1	f
263	22080100312	Bodla	4	61	256	\N	Bodla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22080100312	{"id": "22080100312", "block": "Bodla", "state": "Chhattisgarh", "udise": "22080100312", "school": "Bodla", "district": "Kabirdham", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
264	22081301503	Dullapur	4	61	257	\N	Dullapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22081301503	{"id": "22081301503", "block": "Pandariya", "state": "Chhattisgarh", "udise": "22081301503", "school": "Dullapur", "district": "Kabirdham", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
265	22140315316	Antagarh	4	62	258	\N	Antagarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22140315316	{"id": "22140315316", "block": "Antagarh", "state": "Chhattisgarh", "udise": "22140315316", "school": "Antagarh", "district": "Kanker", "enrollment": 170}	teacher-training-schools	\N	\N	\N	1	f
266	22171201315	Keshkal	4	63	259	\N	Keshkal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22171201315	{"id": "22171201315", "block": "Keshkal", "state": "Chhattisgarh", "udise": "22171201315", "school": "Keshkal", "district": "Kondagaon", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
267	22172604325	Kondagaon	4	63	260	\N	Kondagaon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22172604325	{"id": "22172604325", "block": "Kondagaon", "state": "Chhattisgarh", "udise": "22172604325", "school": "Kondagaon", "district": "Kondagaon", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
268	22051015018	Korba	4	64	261	\N	Korba	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22051015018	{"id": "22051015018", "block": "Korba", "state": "Chhattisgarh", "udise": "22051015018", "school": "Korba", "district": "Korba", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
269	22050900131	Katghora	4	64	262	\N	Katghora	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22050900131	{"id": "22050900131", "block": "Katghora", "state": "Chhattisgarh", "udise": "22050900131", "school": "Katghora", "district": "Korba", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
270	22120918720	Sunsunia	4	65	263	\N	Sunsunia	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22120918720	{"id": "22120918720", "block": "Bagbahra", "state": "Chhattisgarh", "udise": "22120918720", "school": "Sunsunia", "district": "Mahasamund", "enrollment": 160}	teacher-training-schools	\N	\N	\N	1	f
271	22121102702	Lakhagarh	4	65	264	\N	Lakhagarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22121102702	{"id": "22121102702", "block": "Pithora", "state": "Chhattisgarh", "udise": "22121102702", "school": "Lakhagarh", "district": "Mahasamund", "enrollment": 160}	teacher-training-schools	\N	\N	\N	1	f
272	22012201504	Podibachara	4	66	265	\N	Podibachara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22012201504	{"id": "22012201504", "block": "Khadgavan", "state": "Chhattisgarh", "udise": "22012201504", "school": "Podibachara", "district": "Mcb", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
273	22191200306	Sardha	4	67	266	\N	Sardha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22191200306	{"id": "22191200306", "block": "Lormi", "state": "Chhattisgarh", "udise": "22191200306", "school": "Sardha", "district": "Mungeli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
274	22183705417	Sulenga	4	68	267	\N	Sulenga	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22183705417	{"id": "22183705417", "block": "Narayanpur", "state": "Chhattisgarh", "udise": "22183705417", "school": "Sulenga", "district": "Narayanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
275	22182001625	Orchha	4	68	268	\N	Orchha	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22182001625	{"id": "22182001625", "block": "Orchha", "state": "Chhattisgarh", "udise": "22182001625", "school": "Orchha", "district": "Narayanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
276	22040310504	Jamraga	4	69	269	\N	Jamraga	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22040310504	{"id": "22040310504", "block": "Dharamjaigarh", "state": "Chhattisgarh", "udise": "22040310504", "school": "Jamraga", "district": "Raigarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
277	22241020807	Bilaigarh	4	70	270	\N	Bilaigarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22241020807	{"id": "22241020807", "block": "Bilaigarh", "state": "Chhattisgarh", "udise": "22241020807", "school": "Bilaigarh", "district": "Sarangarh- Bilaigarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
278	22213510308	Chindgarh	4	71	271	\N	Chindgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22213510308	{"id": "22213510308", "block": "Chindgarh", "state": "Chhattisgarh", "udise": "22213510308", "school": "Chindgarh", "district": "Sukma", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
279	22210204027	Sukma	4	71	272	\N	Sukma	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22210204027	{"id": "22210204027", "block": "Sukma", "state": "Chhattisgarh", "udise": "22210204027", "school": "Sukma", "district": "Sukma", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
280	22271702719	Pratappur	4	72	273	\N	Pratappur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22271702719	{"id": "22271702719", "block": "Pratappur", "state": "Chhattisgarh", "udise": "22271702719", "school": "Pratappur", "district": "Surajpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
281	22020102707	Sargava	4	73	274	\N	Sargava	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22020102707	{"id": "22020102707", "block": "Ambikapur", "state": "Chhattisgarh", "udise": "22020102707", "school": "Sargava", "district": "Surguja", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
282	22020606605	Rajpurikala	4	73	275	\N	Rajpurikala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22020606605	{"id": "22020606605", "block": "Lakhanpur", "state": "Chhattisgarh", "udise": "22020606605", "school": "Rajpurikala", "district": "Surguja", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
283	22020700113	Udaypur	4	73	276	\N	Udaypur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22020700113	{"id": "22020700113", "block": "Udaypur", "state": "Chhattisgarh", "udise": "22020700113", "school": "Udaypur", "district": "Surguja", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
284	22020405608	Narmadapur	4	73	277	\N	Narmadapur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22020405608	{"id": "22020405608", "block": "Mainpat", "state": "Chhattisgarh", "udise": "22020405608", "school": "Narmadapur", "district": "Surguja", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
285	22271603408	Odgi	4	72	278	\N	Odgi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22271603408	{"id": "22271603408", "block": "Odgi", "state": "Chhattisgarh", "udise": "22271603408", "school": "Odgi", "district": "Surajpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
286	22271900108	Premnagar	4	72	279	\N	Premnagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22271900108	{"id": "22271900108", "block": "Premnagar", "state": "Chhattisgarh", "udise": "22271900108", "school": "Premnagar", "district": "Surajpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
287	22020200409	Batouli	4	73	280	\N	Batouli	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	22020200409	{"id": "22020200409", "block": "Batouli", "state": "Chhattisgarh", "udise": "22020200409", "school": "Batouli", "district": "Surguja", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
288	24300422142	KGBV DELWADA (UNA-Urban)	5	74	281	\N	KGBV DELWADA (UNA-Urban)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	24300422142	{"id": "24300422142", "block": "Una", "state": "Gujarat", "udise": "24300422142", "school": "KGBV DELWADA (UNA-Urban)", "district": "Gir Somanath", "enrollment": 100}	teacher-training-schools	\N	\N	\N	1	f
289	24320307305	KGBV MOGARA	5	75	282	\N	KGBV MOGARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	24320307305	{"id": "24320307305", "block": "Kawant", "state": "Gujarat", "udise": "24320307305", "school": "KGBV MOGARA", "district": "Chhotaudepu", "enrollment": 100}	teacher-training-schools	\N	\N	\N	1	f
290	24120706462	KASTURBA GANDHI BALIKA V	5	76	283	\N	KASTURBA GANDHI BALIKA V	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	24120706462	{"id": "24120706462", "block": "Mangrol", "state": "Gujarat", "udise": "24120706462", "school": "KASTURBA GANDHI BALIKA V", "district": "Junagadh", "enrollment": 100}	teacher-training-schools	\N	\N	\N	1	f
291	6100501810	Jamalpur Shekhan	6	77	284	\N	Jamalpur Shekhan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6100501810	{"id": "6100501810", "block": "Tohana", "state": "Haryana", "udise": "6100501810", "school": "Jamalpur Shekhan", "district": "Fatehabad", "enrollment": 152}	teacher-training-schools	\N	\N	\N	1	f
292	6100104510	Kumharia	6	77	285	\N	Kumharia	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6100104510	{"id": "6100104510", "block": "Fatehabad", "state": "Haryana", "udise": "6100104510", "school": "Kumharia", "district": "Fatehabad", "enrollment": 195}	teacher-training-schools	\N	\N	\N	1	f
293	6090501504	Dhillowala	6	78	286	\N	Dhillowala	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6090501504	{"id": "6090501504", "block": "Alewa", "state": "Haryana", "udise": "6090501504", "school": "Dhillowala", "district": "Jind", "enrollment": 152}	teacher-training-schools	\N	\N	\N	1	f
294	6090705605	Phulllia Khurd	6	78	287	\N	Phulllia Khurd	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6090705605	{"id": "6090705605", "block": "Narwana", "state": "Haryana", "udise": "6090705605", "school": "Phulllia Khurd", "district": "Jind", "enrollment": 169}	teacher-training-schools	\N	\N	\N	1	f
295	6090602204	Kheri saffa	6	78	288	\N	Kheri saffa	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6090602204	{"id": "6090602204", "block": "Uchana", "state": "Haryana", "udise": "6090602204", "school": "Kheri saffa", "district": "Jind", "enrollment": 161}	teacher-training-schools	\N	\N	\N	1	f
296	6200508406	Nuh	6	79	289	\N	Nuh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6200508406	{"id": "6200508406", "block": "Nuh", "state": "Haryana", "udise": "6200508406", "school": "Nuh", "district": "Mewat", "enrollment": 304}	teacher-training-schools	\N	\N	\N	1	f
297	6200600113	Tauru	6	79	290	\N	Tauru	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6200600113	{"id": "6200600113", "block": "Tauru", "state": "Haryana", "udise": "6200600113", "school": "Tauru", "district": "Mewat", "enrollment": 236}	teacher-training-schools	\N	\N	\N	1	f
298	6200203215	Ferozpur Jhirka	6	79	291	\N	Ferozpur Jhirka	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6200203215	{"id": "6200203215", "block": "Ferozpur Jhirka", "state": "Haryana", "udise": "6200203215", "school": "Ferozpur Jhirka", "district": "Mewat", "enrollment": 179}	teacher-training-schools	\N	\N	\N	1	f
299	6200401604	Nagina	6	79	292	\N	Nagina	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6200401604	{"id": "6200401604", "block": "Nagina", "state": "Haryana", "udise": "6200401604", "school": "Nagina", "district": "Mewat", "enrollment": 227}	teacher-training-schools	\N	\N	\N	1	f
300	6200100109	Punahana	6	79	293	\N	Punahana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6200100109	{"id": "6200100109", "block": "Punahana", "state": "Haryana", "udise": "6200100109", "school": "Punahana", "district": "Mewat", "enrollment": 165}	teacher-training-schools	\N	\N	\N	1	f
301	6210307702	Buraka	6	80	294	\N	Buraka	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6210307702	{"id": "6210307702", "block": "Hathin", "state": "Haryana", "udise": "6210307702", "school": "Buraka", "district": "Palwal", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
302	6070601505	Jalmana	6	81	295	\N	Jalmana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6070601505	{"id": "6070601505", "block": "Bapoli", "state": "Haryana", "udise": "6070601505", "school": "Jalmana", "district": "Panipat", "enrollment": 152}	teacher-training-schools	\N	\N	\N	1	f
303	6110404406	Ram Pura Dhillon	6	82	296	\N	Ram Pura Dhillon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6110404406	{"id": "6110404406", "block": "Nathusari Chopta", "state": "Haryana", "udise": "6110404406", "school": "Ram Pura Dhillon", "district": "Sirsa", "enrollment": 151}	teacher-training-schools	\N	\N	\N	1	f
304	6110205603	Ratta Khera	6	82	297	\N	Ratta Khera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	6110205603	{"id": "6110205603", "block": "Dabwali", "state": "Haryana", "udise": "6110205603", "school": "Ratta Khera", "district": "Sirsa", "enrollment": 151}	teacher-training-schools	\N	\N	\N	1	f
305	20150401505	KGBV BHANDRA	7	83	298	\N	KGBV BHANDRA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20150401505	{"id": "20150401505", "block": "Bhandra", "state": "Jharkhand", "udise": "20150401505", "school": "KGBV BHANDRA", "district": "Lohardaga", "enrollment": 432}	teacher-training-schools	\N	\N	\N	1	f
306	20061214501	KGBV GAWAN	7	84	299	\N	KGBV GAWAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20061214501	{"id": "20061214501", "block": "Gawan", "state": "Jharkhand", "udise": "20061214501", "school": "KGBV GAWAN", "district": "Giridih", "enrollment": 433}	teacher-training-schools	\N	\N	\N	1	f
307	20131103214	KGBV PETARWAR	7	85	300	\N	KGBV PETARWAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20131103214	{"id": "20131103214", "block": "Petarwar", "state": "Jharkhand", "udise": "20131103214", "school": "KGBV PETARWAR", "district": "Bokaro", "enrollment": 433}	teacher-training-schools	\N	\N	\N	1	f
308	20100716805	KGBV MAHESHPUR	7	86	301	\N	KGBV MAHESHPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20100716805	{"id": "20100716805", "block": "Maheshpur", "state": "Jharkhand", "udise": "20100716805", "school": "KGBV MAHESHPUR", "district": "Pakaur", "enrollment": 438}	teacher-training-schools	\N	\N	\N	1	f
309	20140100104	KGBV KANKE	7	87	302	\N	KGBV KANKE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20140100104	{"id": "20140100104", "block": "Kanke", "state": "Jharkhand", "udise": "20140100104", "school": "KGBV KANKE", "district": "Ranchi", "enrollment": 438}	teacher-training-schools	\N	\N	\N	1	f
310	20140608604	KGBV BURMU	7	87	303	\N	KGBV BURMU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20140608604	{"id": "20140608604", "block": "Burmu", "state": "Jharkhand", "udise": "20140608604", "school": "KGBV BURMU", "district": "Ranchi", "enrollment": 438}	teacher-training-schools	\N	\N	\N	1	f
311	20230408712	KGBV KARRA	7	88	304	\N	KGBV KARRA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20230408712	{"id": "20230408712", "block": "Karra", "state": "Jharkhand", "udise": "20230408712", "school": "KGBV KARRA", "district": "Khunti", "enrollment": 438}	teacher-training-schools	\N	\N	\N	1	f
312	20170204105	KGBV CHAKRADHARPUR	7	89	305	\N	KGBV CHAKRADHARPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20170204105	{"id": "20170204105", "block": "Chakradharpu", "state": "Jharkhand", "udise": "20170204105", "school": "KGBV CHAKRADHARPUR", "district": "Pashchimi Sin", "enrollment": 442}	teacher-training-schools	\N	\N	\N	1	f
313	20040408708	K.G.B.V., BISHNUGARH	7	90	306	\N	K.G.B.V., BISHNUGARH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20040408708	{"id": "20040408708", "block": "Bishnugarh", "state": "Jharkhand", "udise": "20040408708", "school": "K.G.B.V., BISHNUGARH", "district": "Hazaribag", "enrollment": 443}	teacher-training-schools	\N	\N	\N	1	f
314	20030315007	KGBV HUNTERGANJ	7	91	307	\N	KGBV HUNTERGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20030315007	{"id": "20030315007", "block": "Hunterganj", "state": "Jharkhand", "udise": "20030315007", "school": "KGBV HUNTERGANJ", "district": "Chatra", "enrollment": 448}	teacher-training-schools	\N	\N	\N	1	f
315	20030701205	KGBV PATTHALGADA	7	91	308	\N	KGBV PATTHALGADA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20030701205	{"id": "20030701205", "block": "Pathalgada", "state": "Jharkhand", "udise": "20030701205", "school": "KGBV PATTHALGADA", "district": "Chatra", "enrollment": 450}	teacher-training-schools	\N	\N	\N	1	f
316	20140302002	KGBV CHANHO	7	87	309	\N	KGBV CHANHO	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20140302002	{"id": "20140302002", "block": "Chanho", "state": "Jharkhand", "udise": "20140302002", "school": "KGBV CHANHO", "district": "Ranchi", "enrollment": 451}	teacher-training-schools	\N	\N	\N	1	f
317	20171400103	KGBV MANJHARI	7	89	310	\N	KGBV MANJHARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20171400103	{"id": "20171400103", "block": "Manjhari", "state": "Jharkhand", "udise": "20171400103", "school": "KGBV MANJHARI", "district": "Pashchimi Sin", "enrollment": 451}	teacher-training-schools	\N	\N	\N	1	f
318	20141000307	KGBV ANGARA	7	87	311	\N	KGBV ANGARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20141000307	{"id": "20141000307", "block": "Angara", "state": "Jharkhand", "udise": "20141000307", "school": "KGBV ANGARA", "district": "Ranchi", "enrollment": 451}	teacher-training-schools	\N	\N	\N	1	f
319	20171700706	KGBV NOAMUNDI	7	89	312	\N	KGBV NOAMUNDI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20171700706	{"id": "20171700706", "block": "Noamundi", "state": "Jharkhand", "udise": "20171700706", "school": "KGBV NOAMUNDI", "district": "Pashchimi Sin", "enrollment": 464}	teacher-training-schools	\N	\N	\N	1	f
320	20061308402	KGBV GANDEY	7	84	313	\N	KGBV GANDEY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20061308402	{"id": "20061308402", "block": "Gandey", "state": "Jharkhand", "udise": "20061308402", "school": "KGBV GANDEY", "district": "Giridih", "enrollment": 466}	teacher-training-schools	\N	\N	\N	1	f
321	20080503803	KGBV RAGHUNATHPUR	7	92	314	\N	KGBV RAGHUNATHPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20080503803	{"id": "20080503803", "block": "Poraiyahat", "state": "Jharkhand", "udise": "20080503803", "school": "KGBV RAGHUNATHPUR", "district": "Godda", "enrollment": 468}	teacher-training-schools	\N	\N	\N	1	f
322	20030427602	KGBV PRATAPPUR	7	91	315	\N	KGBV PRATAPPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20030427602	{"id": "20030427602", "block": "Pratappur", "state": "Jharkhand", "udise": "20030427602", "school": "KGBV PRATAPPUR", "district": "Chatra", "enrollment": 469}	teacher-training-schools	\N	\N	\N	1	f
323	20010101105	KGBV RAMKANDA	7	93	316	\N	KGBV RAMKANDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20010101105	{"id": "20010101105", "block": "Ramkanda", "state": "Jharkhand", "udise": "20010101105", "school": "KGBV RAMKANDA", "district": "Garhwa", "enrollment": 471}	teacher-training-schools	\N	\N	\N	1	f
324	20040107107	K.G.B.V. BARHI	7	90	317	\N	K.G.B.V. BARHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20040107107	{"id": "20040107107", "block": "Barhi", "state": "Jharkhand", "udise": "20040107107", "school": "K.G.B.V. BARHI", "district": "Hazaribag", "enrollment": 472}	teacher-training-schools	\N	\N	\N	1	f
325	20041902804	K.G.B.V. PADMA	7	90	318	\N	K.G.B.V. PADMA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20041902804	{"id": "20041902804", "block": "Padma", "state": "Jharkhand", "udise": "20041902804", "school": "K.G.B.V. PADMA", "district": "Hazaribag", "enrollment": 473}	teacher-training-schools	\N	\N	\N	1	f
326	20040913205	K.G.B.V., ICHAK	7	90	319	\N	K.G.B.V., ICHAK	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20040913205	{"id": "20040913205", "block": "Ichak", "state": "Jharkhand", "udise": "20040913205", "school": "K.G.B.V., ICHAK", "district": "Hazaribag", "enrollment": 473}	teacher-training-schools	\N	\N	\N	1	f
327	20030900606	KGBV KUNDA	7	91	320	\N	KGBV KUNDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20030900606	{"id": "20030900606", "block": "Kunda", "state": "Jharkhand", "udise": "20030900606", "school": "KGBV KUNDA", "district": "Chatra", "enrollment": 474}	teacher-training-schools	\N	\N	\N	1	f
328	20081010902	KGBV GODDA	7	92	321	\N	KGBV GODDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20081010902	{"id": "20081010902", "block": "Godda", "state": "Jharkhand", "udise": "20081010902", "school": "KGBV GODDA", "district": "Godda", "enrollment": 478}	teacher-training-schools	\N	\N	\N	1	f
329	20202010603	K.G.B.V. SERAIKELLA	7	94	322	\N	K.G.B.V. SERAIKELLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20202010603	{"id": "20202010603", "block": "Seraikella", "state": "Jharkhand", "udise": "20202010603", "school": "K.G.B.V. SERAIKELLA", "district": "Saraikela-k", "enrollment": 479}	teacher-training-schools	\N	\N	\N	1	f
330	20101006803	KGBV PAKUR	7	86	323	\N	KGBV PAKUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20101006803	{"id": "20101006803", "block": "Pakur", "state": "Jharkhand", "udise": "20101006803", "school": "KGBV PAKUR", "district": "Pakaur", "enrollment": 479}	teacher-training-schools	\N	\N	\N	1	f
331	20131000404	KGBV GOMIA	7	85	324	\N	KGBV GOMIA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20131000404	{"id": "20131000404", "block": "Gomiya", "state": "Jharkhand", "udise": "20131000404", "school": "KGBV GOMIA", "district": "Bokaro", "enrollment": 479}	teacher-training-schools	\N	\N	\N	1	f
332	20061014202	KGBV PIRTAND	7	84	325	\N	KGBV PIRTAND	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20061014202	{"id": "20061014202", "block": "Pirtand", "state": "Jharkhand", "udise": "20061014202", "school": "KGBV PIRTAND", "district": "Giridih", "enrollment": 480}	teacher-training-schools	\N	\N	\N	1	f
333	20220401208	KGBV GARU	7	95	326	\N	KGBV GARU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20220401208	{"id": "20220401208", "block": "Garu", "state": "Jharkhand", "udise": "20220401208", "school": "KGBV GARU", "district": "Latehar", "enrollment": 482}	teacher-training-schools	\N	\N	\N	1	f
334	20220502203	KGBV BARWADIH	7	95	327	\N	KGBV BARWADIH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20220502203	{"id": "20220502203", "block": "Barwadih", "state": "Jharkhand", "udise": "20220502203", "school": "KGBV BARWADIH", "district": "Latehar", "enrollment": 483}	teacher-training-schools	\N	\N	\N	1	f
335	20130329202	KGBV CHAS	7	85	328	\N	KGBV CHAS	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20130329202	{"id": "20130329202", "block": "Chas", "state": "Jharkhand", "udise": "20130329202", "school": "KGBV CHAS", "district": "Bokaro", "enrollment": 483}	teacher-training-schools	\N	\N	\N	1	f
336	20060536401	KGBV JAMUA	7	84	329	\N	KGBV JAMUA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20060536401	{"id": "20060536401", "block": "Jamua", "state": "Jharkhand", "udise": "20060536401", "school": "KGBV JAMUA", "district": "Giridih", "enrollment": 485}	teacher-training-schools	\N	\N	\N	1	f
337	20050311702	GOVT KGBV JAINAGAR	7	96	330	\N	GOVT KGBV JAINAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20050311702	{"id": "20050311702", "block": "Jainagar", "state": "Jharkhand", "udise": "20050311702", "school": "GOVT KGBV JAINAGAR", "district": "Kodarma", "enrollment": 487}	teacher-training-schools	\N	\N	\N	1	f
338	20120718002	KGBV NIRSA	7	97	331	\N	KGBV NIRSA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20120718002	{"id": "20120718002", "block": "Nirsa", "state": "Jharkhand", "udise": "20120718002", "school": "KGBV NIRSA", "district": "Dhanbad", "enrollment": 488}	teacher-training-schools	\N	\N	\N	1	f
339	20220116528	KGBV LATEHAR	7	95	332	\N	KGBV LATEHAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20220116528	{"id": "20220116528", "block": "Latehar", "state": "Jharkhand", "udise": "20220116528", "school": "KGBV LATEHAR", "district": "Latehar", "enrollment": 491}	teacher-training-schools	\N	\N	\N	1	f
340	20191417407	KASTURBA GANDHI BALIKA	7	98	333	\N	KASTURBA GANDHI BALIKA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20191417407	{"id": "20191417407", "block": "Kundahit", "state": "Jharkhand", "udise": "20191417407", "school": "KASTURBA GANDHI BALIKA", "district": "Jamtara", "enrollment": 494}	teacher-training-schools	\N	\N	\N	1	f
341	20172301005	KGBV TONTO	7	89	334	\N	KGBV TONTO	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20172301005	{"id": "20172301005", "block": "Tonto", "state": "Jharkhand", "udise": "20172301005", "school": "KGBV TONTO", "district": "Pashchimi Sin", "enrollment": 494}	teacher-training-schools	\N	\N	\N	1	f
342	20120800603	KGBV GOVINDPUR	7	97	335	\N	KGBV GOVINDPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20120800603	{"id": "20120800603", "block": "Govindpur", "state": "Jharkhand", "udise": "20120800603", "school": "KGBV GOVINDPUR", "district": "Dhanbad", "enrollment": 495}	teacher-training-schools	\N	\N	\N	1	f
343	20140806605	KGBV NAMKUM	7	87	336	\N	KGBV NAMKUM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20140806605	{"id": "20140806605", "block": "Namkum", "state": "Jharkhand", "udise": "20140806605", "school": "KGBV NAMKUM", "district": "Ranchi", "enrollment": 497}	teacher-training-schools	\N	\N	\N	1	f
344	20191109902	KASTURBA GANDHI BALIKA	7	98	337	\N	KASTURBA GANDHI BALIKA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20191109902	{"id": "20191109902", "block": "Jamtara", "state": "Jharkhand", "udise": "20191109902", "school": "KASTURBA GANDHI BALIKA", "district": "Jamtara", "enrollment": 498}	teacher-training-schools	\N	\N	\N	1	f
345	20041102405	K.G.B.V. KEREDARI	7	90	338	\N	K.G.B.V. KEREDARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20041102405	{"id": "20041102405", "block": "Keredari", "state": "Jharkhand", "udise": "20041102405", "school": "K.G.B.V. KEREDARI", "district": "Hazaribag", "enrollment": 499}	teacher-training-schools	\N	\N	\N	1	f
346	20171009903	KGBV KHUNTPANI	7	89	339	\N	KGBV KHUNTPANI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20171009903	{"id": "20171009903", "block": "Khuntpani", "state": "Jharkhand", "udise": "20171009903", "school": "KGBV KHUNTPANI", "district": "Pashchimi Sin", "enrollment": 499}	teacher-training-schools	\N	\N	\N	1	f
347	20060904702	KGBV GIRIDIH	7	84	340	\N	KGBV GIRIDIH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20060904702	{"id": "20060904702", "block": "Giridih", "state": "Jharkhand", "udise": "20060904702", "school": "KGBV GIRIDIH", "district": "Giridih", "enrollment": 499}	teacher-training-schools	\N	\N	\N	1	f
348	20150503107	KGBV KURU	7	83	341	\N	KGBV KURU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20150503107	{"id": "20150503107", "block": "Kuru", "state": "Jharkhand", "udise": "20150503107", "school": "KGBV KURU", "district": "Lohardaga", "enrollment": 500}	teacher-training-schools	\N	\N	\N	1	f
349	20171308401	KGBV MAJHGAON	7	89	342	\N	KGBV MAJHGAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20171308401	{"id": "20171308401", "block": "Majhgaon", "state": "Jharkhand", "udise": "20171308401", "school": "KGBV MAJHGAON", "district": "Pashchimi Sin", "enrollment": 506}	teacher-training-schools	\N	\N	\N	1	f
350	20041003606	K.G.B.V. KATKAMSANDI	7	90	343	\N	K.G.B.V. KATKAMSANDI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	20041003606	{"id": "20041003606", "block": "Katkamsandi", "state": "Jharkhand", "udise": "20041003606", "school": "K.G.B.V. KATKAMSANDI", "district": "Hazaribag", "enrollment": 494}	teacher-training-schools	\N	\N	\N	1	f
351	29120515503	Kamalapura	8	99	344	\N	Kamalapura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29120515503	{"id": "29120515503", "block": "Hospet", "state": "Karnataka", "udise": "29120515503", "school": "Kamalapura", "district": "Vijayanagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
352	29070213115	Siddapur(Udru)	8	100	345	\N	Siddapur(Udru)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29070213115	{"id": "29070213115", "block": "Gangavathi", "state": "Karnataka", "udise": "29070213115", "school": "Siddapur(Udru)", "district": "Koppal", "enrollment": 250}	teacher-training-schools	\N	\N	\N	1	f
353	29330820406	Thinthani	8	101	346	\N	Thinthani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29330820406	{"id": "29330820406", "block": "Shorapur", "state": "Karnataka", "udise": "29330820406", "school": "Thinthani", "district": "Yadgiri", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
354	29330714221	Wadagera	8	101	347	\N	Wadagera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29330714221	{"id": "29330714221", "block": "Shahapur", "state": "Karnataka", "udise": "29330714221", "school": "Wadagera", "district": "Yadgiri", "enrollment": 146}	teacher-training-schools	\N	\N	\N	1	f
355	29331012705	Abbetumkur	8	101	348	\N	Abbetumkur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29331012705	{"id": "29331012705", "block": "Yadgiri", "state": "Karnataka", "udise": "29331012705", "school": "Abbetumkur", "district": "Yadgiri", "enrollment": 135}	teacher-training-schools	\N	\N	\N	1	f
356	29090303103	Ganjigatti	8	102	349	\N	Ganjigatti	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29090303103	{"id": "29090303103", "block": "Kalaghatagi", "state": "Karnataka", "udise": "29090303103", "school": "Ganjigatti", "district": "Dharwad", "enrollment": 150}	teacher-training-schools	\N	\N	\N	1	f
357	29030306105	Kamanakeri	8	103	350	\N	Kamanakeri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29030306105	{"id": "29030306105", "block": "Basavana Bagadi", "state": "Karnataka", "udise": "29030306105", "school": "Kamanakeri", "district": "Vijayapura", "enrollment": 228}	teacher-training-schools	\N	\N	\N	1	f
358	29031015804	Davalagi	8	103	351	\N	Davalagi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	29031015804	{"id": "29031015804", "block": "Mudyibihall", "state": "Karnataka", "udise": "29031015804", "school": "Davalagi", "district": "Vijayapura", "enrollment": 194}	teacher-training-schools	\N	\N	\N	1	f
359	14110100704	KGBV Langol	9	104	352	\N	KGBV Langol	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	14110100704	{"id": "14110100704", "block": "Machi", "state": "Manipur", "udise": "14110100704", "school": "KGBV Langol", "district": "Tengnoupal", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
360	8210300116	Srinagar	10	105	353	\N	Srinagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8210300116	{"id": "8210300116", "block": "Srinagar", "state": "Rajasthan", "udise": "8210300116", "school": "Srinagar", "district": "Ajmer", "enrollment": 213}	teacher-training-schools	\N	\N	\N	1	f
361	8061107616	Rajpurbada	10	106	354	\N	Rajpurbada	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8061107616	{"id": "8061107616", "block": "Rajgarh", "state": "Rajasthan", "udise": "8061107616", "school": "Rajpurbada", "district": "Alwar", "enrollment": 207}	teacher-training-schools	\N	\N	\N	1	f
362	8281000407	Anabapura	10	107	355	\N	Anabapura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8281000407	{"id": "8281000407", "block": "Banswara", "state": "Rajasthan", "udise": "8281000407", "school": "Anabapura", "district": "Banswara", "enrollment": 256}	teacher-training-schools	\N	\N	\N	1	f
363	8310307703	Chjava	10	108	356	\N	Chjava	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8310307703	{"id": "8310307703", "block": "Atru", "state": "Rajasthan", "udise": "8310307703", "school": "Chjava", "district": "Baran", "enrollment": 217}	teacher-training-schools	\N	\N	\N	1	f
364	8310111302	BARAN	10	108	357	\N	BARAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8310111302	{"id": "8310111302", "block": "Baran", "state": "Rajasthan", "udise": "8310111302", "school": "BARAN", "district": "Baran", "enrollment": 207}	teacher-training-schools	\N	\N	\N	1	f
365	8310405405	Kdeyanohr	10	108	358	\N	Kdeyanohr	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8310405405	{"id": "8310405405", "block": "Chabra", "state": "Rajasthan", "udise": "8310405405", "school": "Kdeyanohr", "district": "Baran", "enrollment": 215}	teacher-training-schools	\N	\N	\N	1	f
366	8310702610	Shahbad	10	108	359	\N	Shahbad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8310702610	{"id": "8310702610", "block": "Shahbad", "state": "Rajasthan", "udise": "8310702610", "school": "Shahbad", "district": "Baran", "enrollment": 220}	teacher-training-schools	\N	\N	\N	1	f
367	8171000206	Harsani	10	109	360	\N	Harsani	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8171000206	{"id": "8171000206", "block": "Gadraroad", "state": "Rajasthan", "udise": "8171000206", "school": "Harsani", "district": "Barmer", "enrollment": 209}	teacher-training-schools	\N	\N	\N	1	f
368	8200100206	Jaitaran	10	110	361	\N	Jaitaran	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8200100206	{"id": "8200100206", "block": "Jaitaran", "state": "Rajasthan", "udise": "8200100206", "school": "Jaitaran", "district": "Beawar", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
369	8240401910	Dabla	10	111	362	\N	Dabla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8240401910	{"id": "8240401910", "block": "Banera", "state": "Rajasthan", "udise": "8240401910", "school": "Dabla", "district": "Bhilwara", "enrollment": 231}	teacher-training-schools	\N	\N	\N	1	f
370	8241113914	Sarana	10	111	363	\N	Sarana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8241113914	{"id": "8241113914", "block": "Mandalgarh", "state": "Rajasthan", "udise": "8241113914", "school": "Sarana", "district": "Bhilwara", "enrollment": 254}	teacher-training-schools	\N	\N	\N	1	f
371	8240606107	Mokhunda	10	111	364	\N	Mokhunda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8240606107	{"id": "8240606107", "block": "Raypur", "state": "Rajasthan", "udise": "8240606107", "school": "Mokhunda", "district": "Bhilwara", "enrollment": 213}	teacher-training-schools	\N	\N	\N	1	f
372	8030604415	Poogal	10	112	365	\N	Poogal	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8030604415	{"id": "8030604415", "block": "Poogal", "state": "Rajasthan", "udise": "8030604415", "school": "Poogal", "district": "Bikaner", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
373	8230505911	Matunda	10	113	366	\N	Matunda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8230505911	{"id": "8230505911", "block": "Bundi", "state": "Rajasthan", "udise": "8230505911", "school": "Matunda", "district": "Bundi", "enrollment": 205}	teacher-training-schools	\N	\N	\N	1	f
374	8230233802	Lakheri	10	113	367	\N	Lakheri	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8230233802	{"id": "8230233802", "block": "K.patan", "state": "Rajasthan", "udise": "8230233802", "school": "Lakheri", "district": "Bundi", "enrollment": 219}	teacher-training-schools	\N	\N	\N	1	f
375	8230315529	Dei	10	113	368	\N	Dei	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8230315529	{"id": "8230315529", "block": "Nainwa", "state": "Rajasthan", "udise": "8230315529", "school": "Dei", "district": "Bundi", "enrollment": 210}	teacher-training-schools	\N	\N	\N	1	f
376	8290913003	Nahargarh	10	114	369	\N	Nahargarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8290913003	{"id": "8290913003", "block": "Bhadesar", "state": "Rajasthan", "udise": "8290913003", "school": "Nahargarh", "district": "Chittorgarh", "enrollment": 212}	teacher-training-schools	\N	\N	\N	1	f
377	8290418403	Mndersara	10	114	370	\N	Mndersara	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8290418403	{"id": "8290418403", "block": "Bhainsroadga", "state": "Rajasthan", "udise": "8290418403", "school": "Mndersara", "district": "Chittorgarh", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
378	8080210704	Hansai	10	115	371	\N	Hansai	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8080210704	{"id": "8080210704", "block": "Bari", "state": "Rajasthan", "udise": "8080210704", "school": "Hansai", "district": "Dholpur", "enrollment": 207}	teacher-training-schools	\N	\N	\N	1	f
379	8080112403	Mothiyapura	10	115	372	\N	Mothiyapura	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8080112403	{"id": "8080112403", "block": "Saramathura", "state": "Rajasthan", "udise": "8080112403", "school": "Mothiyapura", "district": "Dholpur", "enrollment": 220}	teacher-training-schools	\N	\N	\N	1	f
380	8080323808	Prerna Nagar	10	115	373	\N	Prerna Nagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8080323808	{"id": "8080323808", "block": "Dholpur", "state": "Rajasthan", "udise": "8080323808", "school": "Prerna Nagar", "district": "Dholpur", "enrollment": 219}	teacher-training-schools	\N	\N	\N	1	f
381	8080407508	Marena	10	115	374	\N	Marena	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8080407508	{"id": "8080407508", "block": "Rajakhera", "state": "Rajasthan", "udise": "8080407508", "school": "Marena", "district": "Dholpur", "enrollment": 208}	teacher-training-schools	\N	\N	\N	1	f
382	8141102142	Borawad	10	116	375	\N	Borawad	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8141102142	{"id": "8141102142", "block": "Makrana", "state": "Rajasthan", "udise": "8141102142", "school": "Borawad", "district": "Didwana-ku", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
383	8270305008	Dhani Ghati	10	117	376	\N	Dhani Ghati	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8270305008	{"id": "8270305008", "block": "Aspur", "state": "Rajasthan", "udise": "8270305008", "school": "Dhani Ghati", "district": "Dungarpur", "enrollment": 215}	teacher-training-schools	\N	\N	\N	1	f
384	8270901008	Ganji	10	117	377	\N	Ganji	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8270901008	{"id": "8270901008", "block": "Jhonthari", "state": "Rajasthan", "udise": "8270901008", "school": "Ganji", "district": "Dungarpur", "enrollment": 220}	teacher-training-schools	\N	\N	\N	1	f
385	8270701002	Bhachadiya	10	117	378	\N	Bhachadiya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8270701002	{"id": "8270701002", "block": "Dovda", "state": "Rajasthan", "udise": "8270701002", "school": "Bhachadiya", "district": "Dungarpur", "enrollment": 216}	teacher-training-schools	\N	\N	\N	1	f
386	8270512617	Peeth	10	117	379	\N	Peeth	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8270512617	{"id": "8270512617", "block": "Shimlawara", "state": "Rajasthan", "udise": "8270512617", "school": "Peeth", "district": "Dungarpur", "enrollment": 236}	teacher-training-schools	\N	\N	\N	1	f
387	8020710924	Tibbi	10	118	380	\N	Tibbi	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8020710924	{"id": "8020710924", "block": "Hanumangarh", "state": "Rajasthan", "udise": "8020710924", "school": "Tibbi", "district": "Hanumangarh", "enrollment": 385}	teacher-training-schools	\N	\N	\N	1	f
388	8121201308	Pnvaliya	10	119	381	\N	Pnvaliya	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8121201308	{"id": "8121201308", "block": "Sanganer", "state": "Rajasthan", "udise": "8121201308", "school": "Pnvaliya", "district": "Jaipur", "enrollment": 209}	teacher-training-schools	\N	\N	\N	1	f
389	8180507020	Arnay	10	120	382	\N	Arnay	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8180507020	{"id": "8180507020", "block": "Sanchore", "state": "Rajasthan", "udise": "8180507020", "school": "Arnay", "district": "Jalore", "enrollment": 210}	teacher-training-schools	\N	\N	\N	1	f
390	8180109119	Rama	10	120	383	\N	Rama	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8180109119	{"id": "8180109119", "block": "Aahor", "state": "Rajasthan", "udise": "8180109119", "school": "Rama", "district": "Jalore", "enrollment": 213}	teacher-training-schools	\N	\N	\N	1	f
391	8320300705	Jawar	10	121	384	\N	Jawar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8320300705	{"id": "8320300705", "block": "M.thana", "state": "Rajasthan", "udise": "8320300705", "school": "Jawar", "district": "Jhalawar", "enrollment": 217}	teacher-training-schools	\N	\N	\N	1	f
392	8090102917	Masalpur	10	122	385	\N	Masalpur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8090102917	{"id": "8090102917", "block": "Karauli", "state": "Rajasthan", "udise": "8090102917", "school": "Masalpur", "district": "Karauli", "enrollment": 212}	teacher-training-schools	\N	\N	\N	1	f
393	8090500217	Naroli Dang	10	122	386	\N	Naroli Dang	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8090500217	{"id": "8090500217", "block": "Sapotra", "state": "Rajasthan", "udise": "8090500217", "school": "Naroli Dang", "district": "Karauli", "enrollment": 210}	teacher-training-schools	\N	\N	\N	1	f
394	8060403211	B.K. Nagar	10	123	387	\N	B.K. Nagar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8060403211	{"id": "8060403211", "block": "Kishganrgh", "state": "Rajasthan", "udise": "8060403211", "school": "B.K. Nagar", "district": "Khairthal- Tijara", "enrollment": 210}	teacher-training-schools	\N	\N	\N	1	f
395	8141009818	Roon	10	124	388	\N	Roon	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8141009818	{"id": "8141009818", "block": "Mundwa", "state": "Rajasthan", "udise": "8141009818", "school": "Roon", "district": "Nagaur", "enrollment": 210}	teacher-training-schools	\N	\N	\N	1	f
396	8141209216	Tankla	10	124	389	\N	Tankla	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8141209216	{"id": "8141209216", "block": "Khinwsar", "state": "Rajasthan", "udise": "8141209216", "school": "Tankla", "district": "Nagaur", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
397	8140210532	Riyan	10	124	390	\N	Riyan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8140210532	{"id": "8140210532", "block": "Riyan", "state": "Rajasthan", "udise": "8140210532", "school": "Riyan", "district": "Nagaur", "enrollment": 205}	teacher-training-schools	\N	\N	\N	1	f
398	8201306510	Khod	10	125	391	\N	Khod	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8201306510	{"id": "8201306510", "block": "Rani", "state": "Rajasthan", "udise": "8201306510", "school": "Khod", "district": "Pali", "enrollment": 209}	teacher-training-schools	\N	\N	\N	1	f
399	8330204808	Ghantali	10	126	392	\N	Ghantali	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8330204808	{"id": "8330204808", "block": "Pipalkhunt", "state": "Rajasthan", "udise": "8330204808", "school": "Ghantali", "district": "Pratapgarh", "enrollment": 220}	teacher-training-schools	\N	\N	\N	1	f
400	8250517006	Nedach	10	127	393	\N	Nedach	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8250517006	{"id": "8250517006", "block": "Delwada", "state": "Rajasthan", "udise": "8250517006", "school": "Nedach", "district": "Rajsamand", "enrollment": 211}	teacher-training-schools	\N	\N	\N	1	f
401	8261013907	Intali khera	10	128	394	\N	Intali khera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8261013907	{"id": "8261013907", "block": "Salumbar", "state": "Rajasthan", "udise": "8261013907", "school": "Intali khera", "district": "Salumbar", "enrollment": 208}	teacher-training-schools	\N	\N	\N	1	f
402	8261402008	Semari	10	128	395	\N	Semari	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8261402008	{"id": "8261402008", "block": "Sarada", "state": "Rajasthan", "udise": "8261402008", "school": "Semari", "district": "Salumbar", "enrollment": 208}	teacher-training-schools	\N	\N	\N	1	f
403	8190508918	Mandar	10	129	396	\N	Mandar	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8190508918	{"id": "8190508918", "block": "Reodar", "state": "Rajasthan", "udise": "8190508918", "school": "Mandar", "district": "Sirohi", "enrollment": 220}	teacher-training-schools	\N	\N	\N	1	f
404	8220415802	Toda	10	130	397	\N	Toda	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	8220415802	{"id": "8220415802", "block": "Toda", "state": "Rajasthan", "udise": "8220415802", "school": "Toda", "district": "Tonk", "enrollment": 212}	teacher-training-schools	\N	\N	\N	1	f
405	11020601002	KGBV Labing	11	131	398	\N	KGBV Labing	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	11020601002	{"id": "11020601002", "block": "Chongrang", "state": "Sikkim", "udise": "11020601002", "school": "KGBV Labing", "district": "Gyalshing", "enrollment": 210}	teacher-training-schools	\N	\N	\N	1	f
406	36010204507	KGBV JAINAD	12	132	399	\N	KGBV JAINAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36010204507	{"id": "36010204507", "block": "Jainad", "state": "Telangana", "udise": "36010204507", "school": "KGBV JAINAD", "district": "Adilabad", "enrollment": 311}	teacher-training-schools	\N	\N	\N	1	f
407	36010302113	KGBV BELA	12	132	400	\N	KGBV BELA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36010302113	{"id": "36010302113", "block": "Bela", "state": "Telangana", "udise": "36010302113", "school": "KGBV BELA", "district": "Adilabad", "enrollment": 325}	teacher-training-schools	\N	\N	\N	1	f
408	36010402204	KGBV GADIGUDA	12	132	401	\N	KGBV GADIGUDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36010402204	{"id": "36010402204", "block": "Gadiguda", "state": "Telangana", "udise": "36010402204", "school": "KGBV GADIGUDA", "district": "Adilabad", "enrollment": 308}	teacher-training-schools	\N	\N	\N	1	f
409	36010990321	KGBV ADILABAD	12	132	402	\N	KGBV ADILABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36010990321	{"id": "36010990321", "block": "Adilabad (urban)", "state": "Telangana", "udise": "36010990321", "school": "KGBV ADILABAD", "district": "Adilabad", "enrollment": 375}	teacher-training-schools	\N	\N	\N	1	f
410	36011200503	KGBV TALAMADUGU	12	132	403	\N	KGBV TALAMADUGU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36011200503	{"id": "36011200503", "block": "Talamadugu", "state": "Telangana", "udise": "36011200503", "school": "KGBV TALAMADUGU", "district": "Adilabad", "enrollment": 301}	teacher-training-schools	\N	\N	\N	1	f
411	36020101818	KGBV JAINOOR	12	133	404	\N	KGBV JAINOOR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020101818	{"id": "36020101818", "block": "Jainoor", "state": "Telangana", "udise": "36020101818", "school": "KGBV JAINOOR", "district": "Kumuram Bheem Asifabad", "enrollment": 315}	teacher-training-schools	\N	\N	\N	1	f
412	36020501106	KGBV REBBENA	12	133	405	\N	KGBV REBBENA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020501106	{"id": "36020501106", "block": "Rebbena", "state": "Telangana", "udise": "36020501106", "school": "KGBV REBBENA", "district": "Kumuram Bheem Asifabad", "enrollment": 318}	teacher-training-schools	\N	\N	\N	1	f
413	36020606150	KGBV ASIFABAD	12	133	406	\N	KGBV ASIFABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020606150	{"id": "36020606150", "block": "Asifabad", "state": "Telangana", "udise": "36020606150", "school": "KGBV ASIFABAD", "district": "Kumuram Bheem Asifabad", "enrollment": 332}	teacher-training-schools	\N	\N	\N	1	f
414	36020702205	KGBV KERAMRI (MODI)	12	133	407	\N	KGBV KERAMRI (MODI)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020702205	{"id": "36020702205", "block": "Kerameri", "state": "Telangana", "udise": "36020702205", "school": "KGBV KERAMRI (MODI)", "district": "Kumuram Bheem Asifabad", "enrollment": 293}	teacher-training-schools	\N	\N	\N	1	f
415	36021001328	KGBV SIRPUR T	12	133	408	\N	KGBV SIRPUR T	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36021001328	{"id": "36021001328", "block": "Sirpur T", "state": "Telangana", "udise": "36021001328", "school": "KGBV SIRPUR T", "district": "Kumuram Bheem Asifabad", "enrollment": 330}	teacher-training-schools	\N	\N	\N	1	f
416	36021200707	KGBV CHINTHALAMANEPALLY	12	133	409	\N	KGBV CHINTHALAMANEPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36021200707	{"id": "36021200707", "block": "Chintalamanepally", "state": "Telangana", "udise": "36021200707", "school": "KGBV CHINTHALAMANEPALLY", "district": "Kumuram Bheem Asifabad", "enrollment": 313}	teacher-training-schools	\N	\N	\N	1	f
417	36021501109	KGBV DAHEGAON	12	133	410	\N	KGBV DAHEGAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36021501109	{"id": "36021501109", "block": "Dahegaon", "state": "Telangana", "udise": "36021501109", "school": "KGBV DAHEGAON", "district": "Kumuram Bheem Asifabad", "enrollment": 291}	teacher-training-schools	\N	\N	\N	1	f
418	36030601917	KGBV TANDUR	12	134	411	\N	KGBV TANDUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36030601917	{"id": "36030601917", "block": "Tandur", "state": "Telangana", "udise": "36030601917", "school": "KGBV TANDUR", "district": "Mancherial", "enrollment": 346}	teacher-training-schools	\N	\N	\N	1	f
419	36031101395	KGBV BELLAMPALLY	12	134	412	\N	KGBV BELLAMPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031101395	{"id": "36031101395", "block": "Bellampally", "state": "Telangana", "udise": "36031101395", "school": "KGBV BELLAMPALLY", "district": "Mancherial", "enrollment": 327}	teacher-training-schools	\N	\N	\N	1	f
420	36031300140	KGBV MANCHERIAL	12	134	413	\N	KGBV MANCHERIAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031300140	{"id": "36031300140", "block": "Mancherial", "state": "Telangana", "udise": "36031300140", "school": "KGBV MANCHERIAL", "district": "Mancherial", "enrollment": 340}	teacher-training-schools	\N	\N	\N	1	f
421	36031400257	KGBV NASPUR	12	134	414	\N	KGBV NASPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031400257	{"id": "36031400257", "block": "Naspur", "state": "Telangana", "udise": "36031400257", "school": "KGBV NASPUR", "district": "Mancherial", "enrollment": 310}	teacher-training-schools	\N	\N	\N	1	f
422	36031500310	KGBV JAIPUR	12	134	415	\N	KGBV JAIPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031500310	{"id": "36031500310", "block": "Bheemaram", "state": "Telangana", "udise": "36031500310", "school": "KGBV JAIPUR", "district": "Mancherial", "enrollment": 325}	teacher-training-schools	\N	\N	\N	1	f
423	36031703452	KGBV CHENNUR	12	134	416	\N	KGBV CHENNUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031703452	{"id": "36031703452", "block": "Chennur", "state": "Telangana", "udise": "36031703452", "school": "KGBV CHENNUR", "district": "Mancherial", "enrollment": 336}	teacher-training-schools	\N	\N	\N	1	f
424	36040402231	KGBV MUDHOLE	12	135	417	\N	KGBV MUDHOLE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36040402231	{"id": "36040402231", "block": "Mudhole", "state": "Telangana", "udise": "36040402231", "school": "KGBV MUDHOLE", "district": "Nirmal", "enrollment": 351}	teacher-training-schools	\N	\N	\N	1	f
425	36040504802	KGBV BHAINSA	12	135	418	\N	KGBV BHAINSA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36040504802	{"id": "36040504802", "block": "Bhainsa", "state": "Telangana", "udise": "36040504802", "school": "KGBV BHAINSA", "district": "Nirmal", "enrollment": 436}	teacher-training-schools	\N	\N	\N	1	f
426	36040701714	KGBV NARSAPUR (G)	12	135	419	\N	KGBV NARSAPUR (G)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36040701714	{"id": "36040701714", "block": "Narsapur-g", "state": "Telangana", "udise": "36040701714", "school": "KGBV NARSAPUR (G)", "district": "Nirmal", "enrollment": 455}	teacher-training-schools	\N	\N	\N	1	f
427	36040900810	KGBV DILAWARPUR	12	135	420	\N	KGBV DILAWARPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36040900810	{"id": "36040900810", "block": "Dilawarpur", "state": "Telangana", "udise": "36040900810", "school": "KGBV DILAWARPUR", "district": "Nirmal", "enrollment": 422}	teacher-training-schools	\N	\N	\N	1	f
428	36041000809	KGBV JAM	12	135	421	\N	KGBV JAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36041000809	{"id": "36041000809", "block": "Sarangapur", "state": "Telangana", "udise": "36041000809", "school": "KGBV JAM", "district": "Nirmal", "enrollment": 445}	teacher-training-schools	\N	\N	\N	1	f
429	36041192815	KGBV NIRMAL	12	135	422	\N	KGBV NIRMAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36041192815	{"id": "36041192815", "block": "Nirmal", "state": "Telangana", "udise": "36041192815", "school": "KGBV NIRMAL", "district": "Nirmal", "enrollment": 347}	teacher-training-schools	\N	\N	\N	1	f
430	36041601107	KGBV MANDAPALLY	12	135	423	\N	KGBV MANDAPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36041601107	{"id": "36041601107", "block": "Pembi", "state": "Telangana", "udise": "36041601107", "school": "KGBV MANDAPALLY", "district": "Nirmal", "enrollment": 322}	teacher-training-schools	\N	\N	\N	1	f
431	36041801212	KGBV KADDAM	12	135	424	\N	KGBV KADDAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36041801212	{"id": "36041801212", "block": "Kaddam", "state": "Telangana", "udise": "36041801212", "school": "KGBV KADDAM", "district": "Nirmal", "enrollment": 311}	teacher-training-schools	\N	\N	\N	1	f
432	36050202647	KGBV NANDIPET	12	136	425	\N	KGBV NANDIPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36050202647	{"id": "36050202647", "block": "Nandipet", "state": "Telangana", "udise": "36050202647", "school": "KGBV NANDIPET", "district": "Nizamabad", "enrollment": 299}	teacher-training-schools	\N	\N	\N	1	f
433	36050302239	KGBV ARMOOR	12	136	426	\N	KGBV ARMOOR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36050302239	{"id": "36050302239", "block": "Armoor", "state": "Telangana", "udise": "36050302239", "school": "KGBV ARMOOR", "district": "Nizamabad", "enrollment": 323}	teacher-training-schools	\N	\N	\N	1	f
434	36050400822	KGBV BALKONDA	12	136	427	\N	KGBV BALKONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36050400822	{"id": "36050400822", "block": "Balkonda", "state": "Telangana", "udise": "36050400822", "school": "KGBV BALKONDA", "district": "Nizamabad", "enrollment": 361}	teacher-training-schools	\N	\N	\N	1	f
435	36051100813	KGBV JAKRANAPALLY	12	136	428	\N	KGBV JAKRANAPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36051100813	{"id": "36051100813", "block": "Jakranpally", "state": "Telangana", "udise": "36051100813", "school": "KGBV JAKRANAPALLY", "district": "Nizamabad", "enrollment": 330}	teacher-training-schools	\N	\N	\N	1	f
436	36052200611	KGBV NIZAMABAD	12	136	429	\N	KGBV NIZAMABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36052200611	{"id": "36052200611", "block": "Nizamabad", "state": "Telangana", "udise": "36052200611", "school": "KGBV NIZAMABAD", "district": "Nizamabad", "enrollment": 315}	teacher-training-schools	\N	\N	\N	1	f
437	36052301529	KGBV DICHPALLY	12	136	430	\N	KGBV DICHPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36052301529	{"id": "36052301529", "block": "Dichpally", "state": "Telangana", "udise": "36052301529", "school": "KGBV DICHPALLY", "district": "Nizamabad", "enrollment": 349}	teacher-training-schools	\N	\N	\N	1	f
438	36060101111	KGBV IBRAHIMPATNAM	12	137	431	\N	KGBV IBRAHIMPATNAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36060101111	{"id": "36060101111", "block": "Ibrahimpatnam", "state": "Telangana", "udise": "36060101111", "school": "KGBV IBRAHIMPATNAM", "district": "Jagtial", "enrollment": 325}	teacher-training-schools	\N	\N	\N	1	f
439	36061800318	KGBV VELGATOOR	12	137	432	\N	KGBV VELGATOOR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36061800318	{"id": "36061800318", "block": "Velgatoor", "state": "Telangana", "udise": "36061800318", "school": "KGBV VELGATOOR", "district": "Jagtial", "enrollment": 332}	teacher-training-schools	\N	\N	\N	1	f
440	36070300502	KGBV ANTHERGOAN	12	138	433	\N	KGBV ANTHERGOAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36070300502	{"id": "36070300502", "block": "Anthergaon", "state": "Telangana", "udise": "36070300502", "school": "KGBV ANTHERGOAN", "district": "Peddapalli", "enrollment": 341}	teacher-training-schools	\N	\N	\N	1	f
441	36070301306	KGBV RAMAGUNDAM	12	138	433	\N	KGBV RAMAGUNDAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36070301306	{"id": "36070301306", "block": "Anthergaon", "state": "Telangana", "udise": "36070301306", "school": "KGBV RAMAGUNDAM", "district": "Peddapalli", "enrollment": 364}	teacher-training-schools	\N	\N	\N	1	f
442	36070800607	KGBV JULAPALLY	12	138	434	\N	KGBV JULAPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36070800607	{"id": "36070800607", "block": "Julapally", "state": "Telangana", "udise": "36070800607", "school": "KGBV JULAPALLY", "district": "Peddapalli", "enrollment": 293}	teacher-training-schools	\N	\N	\N	1	f
443	36071000204	KGBV SULTHANABAD	12	138	435	\N	KGBV SULTHANABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36071000204	{"id": "36071000204", "block": "Sulthanabad", "state": "Telangana", "udise": "36071000204", "school": "KGBV SULTHANABAD", "district": "Peddapalli", "enrollment": 353}	teacher-training-schools	\N	\N	\N	1	f
444	36071201118	KGBV SRIRAMPUR	12	138	436	\N	KGBV SRIRAMPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36071201118	{"id": "36071201118", "block": "Srirampoor", "state": "Telangana", "udise": "36071201118", "school": "KGBV SRIRAMPUR", "district": "Peddapalli", "enrollment": 298}	teacher-training-schools	\N	\N	\N	1	f
445	36080601113	KGBV VENKATRAOPALLY @ CHITYAL	12	139	437	\N	KGBV VENKATRAOPALLY @ CHITYAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36080601113	{"id": "36080601113", "block": "Chityal", "state": "Telangana", "udise": "36080601113", "school": "KGBV VENKATRAOPALLY @ CHITYAL", "district": "Jayashankar", "enrollment": 297}	teacher-training-schools	\N	\N	\N	1	f
446	36080700205	KGBV RAGHAVAREDDYPET @ TEKUMATLA	12	139	438	\N	KGBV RAGHAVAREDDYPET @ TEKUMATLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36080700205	{"id": "36080700205", "block": "Tekumatla", "state": "Telangana", "udise": "36080700205", "school": "KGBV RAGHAVAREDDYPET @ TEKUMATLA", "district": "Jayashankar", "enrollment": 333}	teacher-training-schools	\N	\N	\N	1	f
447	36081102070	KGBV BHUPALPALLY	12	139	439	\N	KGBV BHUPALPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36081102070	{"id": "36081102070", "block": "Bhupalpally", "state": "Telangana", "udise": "36081102070", "school": "KGBV BHUPALPALLY", "district": "Jayashankar", "enrollment": 292}	teacher-training-schools	\N	\N	\N	1	f
448	36090100705	KGBV KARAKAGUDEM	12	140	440	\N	KGBV KARAKAGUDEM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36090100705	{"id": "36090100705", "block": "Karakagudem", "state": "Telangana", "udise": "36090100705", "school": "KGBV KARAKAGUDEM", "district": "Bhadradri Kothagudem", "enrollment": 317}	teacher-training-schools	\N	\N	\N	1	f
449	36091200810	KGBV CHANDRUGONDA	12	140	441	\N	KGBV CHANDRUGONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36091200810	{"id": "36091200810", "block": "Chandrugonda", "state": "Telangana", "udise": "36091200810", "school": "KGBV CHANDRUGONDA", "district": "Bhadradri Kothagudem", "enrollment": 301}	teacher-training-schools	\N	\N	\N	1	f
450	36091300409	KGBV ANNAPUREDDYPALLY	12	140	442	\N	KGBV ANNAPUREDDYPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36091300409	{"id": "36091300409", "block": "Annapureddypalli", "state": "Telangana", "udise": "36091300409", "school": "KGBV ANNAPUREDDYPALLY", "district": "Bhadradri Kothagudem", "enrollment": 337}	teacher-training-schools	\N	\N	\N	1	f
451	36091891307	KGBV PALONCHA	12	140	443	\N	KGBV PALONCHA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36091891307	{"id": "36091891307", "block": "Palvancha", "state": "Telangana", "udise": "36091891307", "school": "KGBV PALONCHA", "district": "Bhadradri Kothagudem", "enrollment": 344}	teacher-training-schools	\N	\N	\N	1	f
452	36110400905	KGBV GEESUGONDA	12	141	444	\N	KGBV GEESUGONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36110400905	{"id": "36110400905", "block": "Geesugonda", "state": "Telangana", "udise": "36110400905", "school": "KGBV GEESUGONDA", "district": "Warangal", "enrollment": 311}	teacher-training-schools	\N	\N	\N	1	f
453	36110500819	KGBV ATMAKUR	12	142	445	\N	KGBV ATMAKUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36110500819	{"id": "36110500819", "block": "Athmakur", "state": "Telangana", "udise": "36110500819", "school": "KGBV ATMAKUR", "district": "Hanumakonda", "enrollment": 312}	teacher-training-schools	\N	\N	\N	1	f
454	36110701409	KGBV NALLABELLY	12	141	446	\N	KGBV NALLABELLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36110701409	{"id": "36110701409", "block": "Nallabelly", "state": "Telangana", "udise": "36110701409", "school": "KGBV NALLABELLY", "district": "Warangal", "enrollment": 308}	teacher-training-schools	\N	\N	\N	1	f
455	36111000310	KGBV CHENNARAOPET	12	141	447	\N	KGBV CHENNARAOPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36111000310	{"id": "36111000310", "block": "Chennaraopet", "state": "Telangana", "udise": "36111000310", "school": "KGBV CHENNARAOPET", "district": "Warangal", "enrollment": 297}	teacher-training-schools	\N	\N	\N	1	f
456	36120100204	KGBV BHEEMADEVARAPALLY	12	142	448	\N	KGBV BHEEMADEVARAPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36120100204	{"id": "36120100204", "block": "Bheemadevarapally", "state": "Telangana", "udise": "36120100204", "school": "KGBV BHEEMADEVARAPALLY", "district": "Hanumakonda", "enrollment": 299}	teacher-training-schools	\N	\N	\N	1	f
457	36120400831	KGBV KAMALAPUR	12	142	449	\N	KGBV KAMALAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36120400831	{"id": "36120400831", "block": "Kamalapur", "state": "Telangana", "udise": "36120400831", "school": "KGBV KAMALAPUR", "district": "Hanumakonda", "enrollment": 351}	teacher-training-schools	\N	\N	\N	1	f
458	36121100517	KGBV INAVOLE	12	142	450	\N	KGBV INAVOLE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36121100517	{"id": "36121100517", "block": "Inavole", "state": "Telangana", "udise": "36121100517", "school": "KGBV INAVOLE", "district": "Hanumakonda", "enrollment": 332}	teacher-training-schools	\N	\N	\N	1	f
459	36131500768	KGBV JAMMIKUNTA	12	143	451	\N	KGBV JAMMIKUNTA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36131500768	{"id": "36131500768", "block": "Jammikunta", "state": "Telangana", "udise": "36131500768", "school": "KGBV JAMMIKUNTA", "district": "Karimnagar", "enrollment": 294}	teacher-training-schools	\N	\N	\N	1	f
460	36140100223	KGBV RUDRANGI	12	144	452	\N	KGBV RUDRANGI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36140100223	{"id": "36140100223", "block": "Rudrangi", "state": "Telangana", "udise": "36140100223", "school": "KGBV RUDRANGI", "district": "Rajanna Siricilla", "enrollment": 312}	teacher-training-schools	\N	\N	\N	1	f
461	36140300409	KGBV VEMULAWADA RURAL	12	144	453	\N	KGBV VEMULAWADA RURAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36140300409	{"id": "36140300409", "block": "Marripally", "state": "Telangana", "udise": "36140300409", "school": "KGBV VEMULAWADA RURAL", "district": "Rajanna Siricilla", "enrollment": 314}	teacher-training-schools	\N	\N	\N	1	f
462	36140600652	KGBV SIRICILLA	12	144	454	\N	KGBV SIRICILLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36140600652	{"id": "36140600652", "block": "Siricilla", "state": "Telangana", "udise": "36140600652", "school": "KGBV SIRICILLA", "district": "Rajanna Siricilla", "enrollment": 365}	teacher-training-schools	\N	\N	\N	1	f
463	36140800510	KGBV VEERNAPALLI	12	144	455	\N	KGBV VEERNAPALLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36140800510	{"id": "36140800510", "block": "Veernapally", "state": "Telangana", "udise": "36140800510", "school": "KGBV VEERNAPALLI", "district": "Rajanna Siricilla", "enrollment": 297}	teacher-training-schools	\N	\N	\N	1	f
464	36141001016	KGBV GAMBHIRAOPET	12	144	456	\N	KGBV GAMBHIRAOPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36141001016	{"id": "36141001016", "block": "Gambhiraopet", "state": "Telangana", "udise": "36141001016", "school": "KGBV GAMBHIRAOPET", "district": "Rajanna Siricilla", "enrollment": 297}	teacher-training-schools	\N	\N	\N	1	f
465	36141200411	KGBV THANGALLAPALLI	12	144	457	\N	KGBV THANGALLAPALLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36141200411	{"id": "36141200411", "block": "Thangalapally", "state": "Telangana", "udise": "36141200411", "school": "KGBV THANGALLAPALLI", "district": "Rajanna Siricilla", "enrollment": 305}	teacher-training-schools	\N	\N	\N	1	f
466	36150401023	KGBV BICHKUNDA	12	145	458	\N	KGBV BICHKUNDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36150401023	{"id": "36150401023", "block": "Bichkunda", "state": "Telangana", "udise": "36150401023", "school": "KGBV BICHKUNDA", "district": "Kamareddy", "enrollment": 393}	teacher-training-schools	\N	\N	\N	1	f
467	36150500816	KGBV BIRKUR	12	145	459	\N	KGBV BIRKUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36150500816	{"id": "36150500816", "block": "Birkoor", "state": "Telangana", "udise": "36150500816", "school": "KGBV BIRKUR", "district": "Kamareddy", "enrollment": 400}	teacher-training-schools	\N	\N	\N	1	f
468	36150802614	KGBV (R) PITLAM	12	145	460	\N	KGBV (R) PITLAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36150802614	{"id": "36150802614", "block": "Pitlam", "state": "Telangana", "udise": "36150802614", "school": "KGBV (R) PITLAM", "district": "Kamareddy", "enrollment": 396}	teacher-training-schools	\N	\N	\N	1	f
469	36150902911	KGBV NIZAMSAGAR	12	145	461	\N	KGBV NIZAMSAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36150902911	{"id": "36150902911", "block": "Nizamsagar", "state": "Telangana", "udise": "36150902911", "school": "KGBV NIZAMSAGAR", "district": "Kamareddy", "enrollment": 375}	teacher-training-schools	\N	\N	\N	1	f
470	36151103134	KGBV YELLAREDDY	12	145	462	\N	KGBV YELLAREDDY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36151103134	{"id": "36151103134", "block": "Yellareddy", "state": "Telangana", "udise": "36151103134", "school": "KGBV YELLAREDDY", "district": "Kamareddy", "enrollment": 311}	teacher-training-schools	\N	\N	\N	1	f
471	36151201741	KGBV LINGAMPET	12	145	463	\N	KGBV LINGAMPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36151201741	{"id": "36151201741", "block": "Lingampet", "state": "Telangana", "udise": "36151201741", "school": "KGBV LINGAMPET", "district": "Kamareddy", "enrollment": 375}	teacher-training-schools	\N	\N	\N	1	f
472	36151700735	KGBV BHIKNOOR	12	145	464	\N	KGBV BHIKNOOR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36151700735	{"id": "36151700735", "block": "Bhiknur", "state": "Telangana", "udise": "36151700735", "school": "KGBV BHIKNOOR", "district": "Kamareddy", "enrollment": 300}	teacher-training-schools	\N	\N	\N	1	f
473	36152200615	KGBV BIBIPET	12	145	465	\N	KGBV BIBIPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36152200615	{"id": "36152200615", "block": "Bibipet", "state": "Telangana", "udise": "36152200615", "school": "KGBV BIBIPET", "district": "Kamareddy", "enrollment": 305}	teacher-training-schools	\N	\N	\N	1	f
474	36160403541	KGBV NARAYANKHED	12	146	466	\N	KGBV NARAYANKHED	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36160403541	{"id": "36160403541", "block": "Narayankhed", "state": "Telangana", "udise": "36160403541", "school": "KGBV NARAYANKHED", "district": "Sangareddy", "enrollment": 316}	teacher-training-schools	\N	\N	\N	1	f
475	36160701508	KGBV RAIKODE	12	146	467	\N	KGBV RAIKODE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36160701508	{"id": "36160701508", "block": "Raikode", "state": "Telangana", "udise": "36160701508", "school": "KGBV RAIKODE", "district": "Sangareddy", "enrollment": 360}	teacher-training-schools	\N	\N	\N	1	f
476	36161201607	KGBV JHARASANGAM	12	146	468	\N	KGBV JHARASANGAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36161201607	{"id": "36161201607", "block": "Jharasangam", "state": "Telangana", "udise": "36161201607", "school": "KGBV JHARASANGAM", "district": "Sangareddy", "enrollment": 294}	teacher-training-schools	\N	\N	\N	1	f
477	36161502731	KGBV ANDOLE	12	146	469	\N	KGBV ANDOLE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36161502731	{"id": "36161502731", "block": "Andole", "state": "Telangana", "udise": "36161502731", "school": "KGBV ANDOLE", "district": "Sangareddy", "enrollment": 353}	teacher-training-schools	\N	\N	\N	1	f
478	36161600906	KGBV PULKAL	12	146	470	\N	KGBV PULKAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36161600906	{"id": "36161600906", "block": "Pulkal", "state": "Telangana", "udise": "36161600906", "school": "KGBV PULKAL", "district": "Sangareddy", "enrollment": 301}	teacher-training-schools	\N	\N	\N	1	f
479	36161703072	KGBV SADASIVAPET	12	146	471	\N	KGBV SADASIVAPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36161703072	{"id": "36161703072", "block": "Sadashivpet", "state": "Telangana", "udise": "36161703072", "school": "KGBV SADASIVAPET", "district": "Sangareddy", "enrollment": 329}	teacher-training-schools	\N	\N	\N	1	f
480	36161800508	KGBV KONDAPUR	12	146	472	\N	KGBV KONDAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36161800508	{"id": "36161800508", "block": "Kondapur", "state": "Telangana", "udise": "36161800508", "school": "KGBV KONDAPUR", "district": "Sangareddy", "enrollment": 336}	teacher-training-schools	\N	\N	\N	1	f
481	36162201729	KGBV JINNRAM	12	146	473	\N	KGBV JINNRAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36162201729	{"id": "36162201729", "block": "Jinnaram", "state": "Telangana", "udise": "36162201729", "school": "KGBV JINNRAM", "district": "Sangareddy", "enrollment": 332}	teacher-training-schools	\N	\N	\N	1	f
482	36170300121	KGBV ALLADURG	12	147	474	\N	KGBV ALLADURG	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36170300121	{"id": "36170300121", "block": "Alladurg", "state": "Telangana", "udise": "36170300121", "school": "KGBV ALLADURG", "district": "Medak", "enrollment": 327}	teacher-training-schools	\N	\N	\N	1	f
483	36171201666	KGBV MEDAK	12	147	475	\N	KGBV MEDAK	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36171201666	{"id": "36171201666", "block": "Medak", "state": "Telangana", "udise": "36171201666", "school": "KGBV MEDAK", "district": "Medak", "enrollment": 292}	teacher-training-schools	\N	\N	\N	1	f
484	36171600505	KGBV CHIPPALTURTHI	12	147	476	\N	KGBV CHIPPALTURTHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36171600505	{"id": "36171600505", "block": "Chippalthurthy", "state": "Telangana", "udise": "36171600505", "school": "KGBV CHIPPALTURTHI", "district": "Medak", "enrollment": 302}	teacher-training-schools	\N	\N	\N	1	f
485	36171801314	KGBV YELDURTHY	12	147	477	\N	KGBV YELDURTHY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36171801314	{"id": "36171801314", "block": "Yeldurthy", "state": "Telangana", "udise": "36171801314", "school": "KGBV YELDURTHY", "district": "Medak", "enrollment": 307}	teacher-training-schools	\N	\N	\N	1	f
486	36172001005	KGBV TOOPRAN	12	147	478	\N	KGBV TOOPRAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36172001005	{"id": "36172001005", "block": "Toopran", "state": "Telangana", "udise": "36172001005", "school": "KGBV TOOPRAN", "district": "Medak", "enrollment": 320}	teacher-training-schools	\N	\N	\N	1	f
487	36180200710	KGBV RAGHAVAPUR	12	148	479	\N	KGBV RAGHAVAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36180200710	{"id": "36180200710", "block": "Siddipet Rural", "state": "Telangana", "udise": "36180200710", "school": "KGBV RAGHAVAPUR", "district": "Siddipet", "enrollment": 332}	teacher-training-schools	\N	\N	\N	1	f
488	36180900609	KGBV SIDDIPET URBAN	12	148	480	\N	KGBV SIDDIPET URBAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36180900609	{"id": "36180900609", "block": "Siddipet Urban", "state": "Telangana", "udise": "36180900609", "school": "KGBV SIDDIPET URBAN", "district": "Siddipet", "enrollment": 353}	teacher-training-schools	\N	\N	\N	1	f
489	36181100615	KGBV MIRDODDI	12	148	481	\N	KGBV MIRDODDI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36181100615	{"id": "36181100615", "block": "Mirdoddi", "state": "Telangana", "udise": "36181100615", "school": "KGBV MIRDODDI", "district": "Siddipet", "enrollment": 337}	teacher-training-schools	\N	\N	\N	1	f
490	36181802749	KGBV GAJWEL	12	148	482	\N	KGBV GAJWEL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36181802749	{"id": "36181802749", "block": "Gajwel", "state": "Telangana", "udise": "36181802749", "school": "KGBV GAJWEL", "district": "Siddipet", "enrollment": 340}	teacher-training-schools	\N	\N	\N	1	f
491	36190201110	KGBV CHILPUR	12	149	483	\N	KGBV CHILPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36190201110	{"id": "36190201110", "block": "Chilpur", "state": "Telangana", "udise": "36190201110", "school": "KGBV CHILPUR", "district": "Jangaon", "enrollment": 306}	teacher-training-schools	\N	\N	\N	1	f
492	36190300917	KGBV ZAFFARGADH	12	149	484	\N	KGBV ZAFFARGADH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36190300917	{"id": "36190300917", "block": "Zaffargadh", "state": "Telangana", "udise": "36190300917", "school": "KGBV ZAFFARGADH", "district": "Jangaon", "enrollment": 335}	teacher-training-schools	\N	\N	\N	1	f
493	36190400703	KGBV GHANPUR (STN)	12	149	485	\N	KGBV GHANPUR (STN)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36190400703	{"id": "36190400703", "block": "Ghanpur Stn", "state": "Telangana", "udise": "36190400703", "school": "KGBV GHANPUR (STN)", "district": "Jangaon", "enrollment": 344}	teacher-training-schools	\N	\N	\N	1	f
494	36190701914	KGBV BACHANNAPET	12	149	486	\N	KGBV BACHANNAPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36190701914	{"id": "36190701914", "block": "Bachannapet", "state": "Telangana", "udise": "36190701914", "school": "KGBV BACHANNAPET", "district": "Jangaon", "enrollment": 306}	teacher-training-schools	\N	\N	\N	1	f
495	36190801804	KGBV JANGAON	12	149	487	\N	KGBV JANGAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36190801804	{"id": "36190801804", "block": "Jangaon", "state": "Telangana", "udise": "36190801804", "school": "KGBV JANGAON", "district": "Jangaon", "enrollment": 356}	teacher-training-schools	\N	\N	\N	1	f
496	36191101125	KGBV PALAKURTHY	12	149	488	\N	KGBV PALAKURTHY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36191101125	{"id": "36191101125", "block": "Palakurthi", "state": "Telangana", "udise": "36191101125", "school": "KGBV PALAKURTHY", "district": "Jangaon", "enrollment": 331}	teacher-training-schools	\N	\N	\N	1	f
497	36200701705	KGBV BOMMALARAMARAM	12	150	489	\N	KGBV BOMMALARAMARAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36200701705	{"id": "36200701705", "block": "Bommalaramaram", "state": "Telangana", "udise": "36200701705", "school": "KGBV BOMMALARAMARAM", "district": "Yadadri Bhuvanagiri", "enrollment": 315}	teacher-training-schools	\N	\N	\N	1	f
498	36201001729	KGBV CHOUTUPPAL	12	150	490	\N	KGBV CHOUTUPPAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36201001729	{"id": "36201001729", "block": "Choutuppal", "state": "Telangana", "udise": "36201001729", "school": "KGBV CHOUTUPPAL", "district": "Yadadri Bhuvanagiri", "enrollment": 302}	teacher-training-schools	\N	\N	\N	1	f
499	36201302228	KGBV VALIGONDA	12	150	491	\N	KGBV VALIGONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36201302228	{"id": "36201302228", "block": "Valigonda", "state": "Telangana", "udise": "36201302228", "school": "KGBV VALIGONDA", "district": "Yadadri Bhuvanagiri", "enrollment": 330}	teacher-training-schools	\N	\N	\N	1	f
500	36201600612	KGBV ADDAGUDUR	12	150	492	\N	KGBV ADDAGUDUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36201600612	{"id": "36201600612", "block": "Addagudur", "state": "Telangana", "udise": "36201600612", "school": "KGBV ADDAGUDUR", "district": "Yadadri Bhuvanagiri", "enrollment": 315}	teacher-training-schools	\N	\N	\N	1	f
501	36230100433	KGBV SHANKARPALLY	12	151	493	\N	KGBV SHANKARPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36230100433	{"id": "36230100433", "block": "Shankarpally", "state": "Telangana", "udise": "36230100433", "school": "KGBV SHANKARPALLY", "district": "Rangareddy", "enrollment": 402}	teacher-training-schools	\N	\N	\N	1	f
502	36230900754	KGBV IBRAHIMPATAN HS	12	151	494	\N	KGBV IBRAHIMPATAN HS	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36230900754	{"id": "36230900754", "block": "Ibrahimpatnam", "state": "Telangana", "udise": "36230900754", "school": "KGBV IBRAHIMPATAN HS", "district": "Rangareddy", "enrollment": 390}	teacher-training-schools	\N	\N	\N	1	f
503	36231000910	KGBV MANCHAL	12	151	495	\N	KGBV MANCHAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36231000910	{"id": "36231000910", "block": "Manchal", "state": "Telangana", "udise": "36231000910", "school": "KGBV MANCHAL", "district": "Rangareddy", "enrollment": 386}	teacher-training-schools	\N	\N	\N	1	f
504	36231501307	KGBV KESHAMPET	12	151	496	\N	KGBV KESHAMPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36231501307	{"id": "36231501307", "block": "Keshampet", "state": "Telangana", "udise": "36231501307", "school": "KGBV KESHAMPET", "district": "Rangareddy", "enrollment": 426}	teacher-training-schools	\N	\N	\N	1	f
505	36231701819	KGBV KANDUKUR	12	151	497	\N	KGBV KANDUKUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36231701819	{"id": "36231701819", "block": "Kandukur,2007", "state": "Telangana", "udise": "36231701819", "school": "KGBV KANDUKUR", "district": "Rangareddy", "enrollment": 518}	teacher-training-schools	\N	\N	\N	1	f
506	36231801922	KGBV MAHESHWARAM	12	151	498	\N	KGBV MAHESHWARAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36231801922	{"id": "36231801922", "block": "Maheshwaram2011", "state": "Telangana", "udise": "36231801922", "school": "KGBV MAHESHWARAM", "district": "Rangareddy", "enrollment": 450}	teacher-training-schools	\N	\N	\N	1	f
507	36231902512	KGBV SHAMSHABAD	12	151	499	\N	KGBV SHAMSHABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36231902512	{"id": "36231902512", "block": "Shamshabad", "state": "Telangana", "udise": "36231902512", "school": "KGBV SHAMSHABAD", "district": "Rangareddy", "enrollment": 315}	teacher-training-schools	\N	\N	\N	1	f
508	36232202030	KGBV SHABAD	12	151	500	\N	KGBV SHABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36232202030	{"id": "36232202030", "block": "Shabad", "state": "Telangana", "udise": "36232202030", "school": "KGBV SHABAD", "district": "Rangareddy", "enrollment": 352}	teacher-training-schools	\N	\N	\N	1	f
509	36232301118	KGBV KOTHUR	12	151	501	\N	KGBV KOTHUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36232301118	{"id": "36232301118", "block": "Kothur", "state": "Telangana", "udise": "36232301118", "school": "KGBV KOTHUR", "district": "Rangareddy", "enrollment": 393}	teacher-training-schools	\N	\N	\N	1	f
510	36232503688	KGBV FAROOQNAGAR	12	151	502	\N	KGBV FAROOQNAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36232503688	{"id": "36232503688", "block": "Farooqnagar", "state": "Telangana", "udise": "36232503688", "school": "KGBV FAROOQNAGAR", "district": "Rangareddy", "enrollment": 386}	teacher-training-schools	\N	\N	\N	1	f
511	36232600123	KGBV KONDURG	12	151	503	\N	KGBV KONDURG	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36232600123	{"id": "36232600123", "block": "Kondurge/m", "state": "Telangana", "udise": "36232600123", "school": "KGBV KONDURG", "district": "Rangareddy", "enrollment": 421}	teacher-training-schools	\N	\N	\N	1	f
512	36240201020	KGBV MOMINPET	12	152	504	\N	KGBV MOMINPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36240201020	{"id": "36240201020", "block": "Mominpet", "state": "Telangana", "udise": "36240201020", "school": "KGBV MOMINPET", "district": "Vikarabad", "enrollment": 333}	teacher-training-schools	\N	\N	\N	1	f
513	36240500401	KGBV PUDUR	12	152	505	\N	KGBV PUDUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36240500401	{"id": "36240500401", "block": "Pudur", "state": "Telangana", "udise": "36240500401", "school": "KGBV PUDUR", "district": "Vikarabad", "enrollment": 304}	teacher-training-schools	\N	\N	\N	1	f
514	36240700415	KGBV KULKACHERLA	12	152	506	\N	KGBV KULKACHERLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36240700415	{"id": "36240700415", "block": "Kulkacherla", "state": "Telangana", "udise": "36240700415", "school": "KGBV KULKACHERLA", "district": "Vikarabad", "enrollment": 331}	teacher-training-schools	\N	\N	\N	1	f
515	36240801107	KGBV DOMA	12	152	507	\N	KGBV DOMA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36240801107	{"id": "36240801107", "block": "Doma", "state": "Telangana", "udise": "36240801107", "school": "KGBV DOMA", "district": "Vikarabad", "enrollment": 345}	teacher-training-schools	\N	\N	\N	1	f
516	36241301110	KGBV PEDDEMUL	12	152	508	\N	KGBV PEDDEMUL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36241301110	{"id": "36241301110", "block": "Peddemul", "state": "Telangana", "udise": "36241301110", "school": "KGBV PEDDEMUL", "district": "Vikarabad", "enrollment": 334}	teacher-training-schools	\N	\N	\N	1	f
517	36241400602	KGBV TANDUR	12	152	509	\N	KGBV TANDUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36241400602	{"id": "36241400602", "block": "Tandur", "state": "Telangana", "udise": "36241400602", "school": "KGBV TANDUR", "district": "Vikarabad", "enrollment": 355}	teacher-training-schools	\N	\N	\N	1	f
518	36241700736	KGBV KODANGAL	12	152	510	\N	KGBV KODANGAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36241700736	{"id": "36241700736", "block": "Kodangal", "state": "Telangana", "udise": "36241700736", "school": "KGBV KODANGAL", "district": "Vikarabad", "enrollment": 406}	teacher-training-schools	\N	\N	\N	1	f
519	36250202811	KGBV KOILKONDA	12	153	511	\N	KGBV KOILKONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36250202811	{"id": "36250202811", "block": "Koilkonda", "state": "Telangana", "udise": "36250202811", "school": "KGBV KOILKONDA", "district": "Mahabubnagar", "enrollment": 345}	teacher-training-schools	\N	\N	\N	1	f
520	36250302823	KGBV GANDEED MOHAMMADABAD	12	153	512	\N	KGBV GANDEED MOHAMMADABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36250302823	{"id": "36250302823", "block": "Gandeed", "state": "Telangana", "udise": "36250302823", "school": "KGBV GANDEED MOHAMMADABAD", "district": "Mahabubnagar", "enrollment": 397}	teacher-training-schools	\N	\N	\N	1	f
521	36250601222	KGBV DEVARKADRA	12	153	513	\N	KGBV DEVARKADRA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36250601222	{"id": "36250601222", "block": "Devarkadara", "state": "Telangana", "udise": "36250601222", "school": "KGBV DEVARKADRA", "district": "Mahabubnagar", "enrollment": 363}	teacher-training-schools	\N	\N	\N	1	f
522	36251000636	KGBV MAHABUBNAGAR (EM), YENUGONDA, MBNR	12	153	514	\N	KGBV MAHABUBNAGAR (EM), YENUGONDA, MBNR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36251000636	{"id": "36251000636", "block": "Mahabubnagar (urban)", "state": "Telangana", "udise": "36251000636", "school": "KGBV MAHABUBNAGAR (EM), YENUGONDA, MBNR", "district": "Mahabubnagar", "enrollment": 322}	teacher-training-schools	\N	\N	\N	1	f
523	36251000705	KGBV MAHABUBNAGAR(RURAL)	12	153	515	\N	KGBV MAHABUBNAGAR(RURAL)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36251000705	{"id": "36251000705", "block": "Mahabubnagar (rural)", "state": "Telangana", "udise": "36251000705", "school": "KGBV MAHABUBNAGAR(RURAL)", "district": "Mahabubnagar", "enrollment": 393}	teacher-training-schools	\N	\N	\N	1	f
524	36251102023	KGBV NAWABPET	12	153	516	\N	KGBV NAWABPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36251102023	{"id": "36251102023", "block": "Nawabpet", "state": "Telangana", "udise": "36251102023", "school": "KGBV NAWABPET", "district": "Mahabubnagar", "enrollment": 378}	teacher-training-schools	\N	\N	\N	1	f
525	36260300703	KGBV GADWAL	12	154	517	\N	KGBV GADWAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36260300703	{"id": "36260300703", "block": "Gadwal", "state": "Telangana", "udise": "36260300703", "school": "KGBV GADWAL", "district": "Jogulamba Gadwal", "enrollment": 355}	teacher-training-schools	\N	\N	\N	1	f
526	36260600813	KGBV GATTU	12	154	518	\N	KGBV GATTU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36260600813	{"id": "36260600813", "block": "Gattu", "state": "Telangana", "udise": "36260600813", "school": "KGBV GATTU", "district": "Jogulamba Gadwal", "enrollment": 416}	teacher-training-schools	\N	\N	\N	1	f
527	36260701042	KGBV IEEJA	12	154	519	\N	KGBV IEEJA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36260701042	{"id": "36260701042", "block": "Ieeja", "state": "Telangana", "udise": "36260701042", "school": "KGBV IEEJA", "district": "Jogulamba Gadwal", "enrollment": 366}	teacher-training-schools	\N	\N	\N	1	f
528	36261001008	KGBV MANOPAD	12	154	520	\N	KGBV MANOPAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36261001008	{"id": "36261001008", "block": "Manopad", "state": "Telangana", "udise": "36261001008", "school": "KGBV MANOPAD", "district": "Jogulamba Gadwal", "enrollment": 327}	teacher-training-schools	\N	\N	\N	1	f
529	36270500611	KGBV GOPALPET	12	155	521	\N	KGBV GOPALPET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36270500611	{"id": "36270500611", "block": "Gopalpet", "state": "Telangana", "udise": "36270500611", "school": "KGBV GOPALPET", "district": "Wanaparthy", "enrollment": 358}	teacher-training-schools	\N	\N	\N	1	f
530	36270801807	KGBV WANAPARTHY	12	155	522	\N	KGBV WANAPARTHY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36270801807	{"id": "36270801807", "block": "Wanaparthy", "state": "Telangana", "udise": "36270801807", "school": "KGBV WANAPARTHY", "district": "Wanaparthy", "enrollment": 370}	teacher-training-schools	\N	\N	\N	1	f
531	36271001738	KGBV ATMAKUR	12	155	523	\N	KGBV ATMAKUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36271001738	{"id": "36271001738", "block": "Athmakur", "state": "Telangana", "udise": "36271001738", "school": "KGBV ATMAKUR", "district": "Wanaparthy", "enrollment": 348}	teacher-training-schools	\N	\N	\N	1	f
532	36271200413	KGBV SRIRANGAPUR	12	155	524	\N	KGBV SRIRANGAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36271200413	{"id": "36271200413", "block": "Srirangapur", "state": "Telangana", "udise": "36271200413", "school": "KGBV SRIRANGAPUR", "district": "Wanaparthy", "enrollment": 343}	teacher-training-schools	\N	\N	\N	1	f
533	36280301304	KGBV NAGARKURNOOL	12	156	525	\N	KGBV NAGARKURNOOL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36280301304	{"id": "36280301304", "block": "Nagarkurnool", "state": "Telangana", "udise": "36280301304", "school": "KGBV NAGARKURNOOL", "district": "Nagarkurnool", "enrollment": 359}	teacher-training-schools	\N	\N	\N	1	f
534	36280601213	KGBV VELDANDA	12	156	526	\N	KGBV VELDANDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36280601213	{"id": "36280601213", "block": "Veldanda", "state": "Telangana", "udise": "36280601213", "school": "KGBV VELDANDA", "district": "Nagarkurnool", "enrollment": 313}	teacher-training-schools	\N	\N	\N	1	f
535	36280700613	KGBV CHARAKONDA	12	156	527	\N	KGBV CHARAKONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36280700613	{"id": "36280700613", "block": "Charakonda", "state": "Telangana", "udise": "36280700613", "school": "KGBV CHARAKONDA", "district": "Nagarkurnool", "enrollment": 312}	teacher-training-schools	\N	\N	\N	1	f
536	36280901968	KGBV KALWAKURTHY	12	156	528	\N	KGBV KALWAKURTHY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36280901968	{"id": "36280901968", "block": "Kalwakurthy", "state": "Telangana", "udise": "36280901968", "school": "KGBV KALWAKURTHY", "district": "Nagarkurnool", "enrollment": 398}	teacher-training-schools	\N	\N	\N	1	f
537	36281300113	KGBV RAYALAGANDI AMRABAD	12	156	529	\N	KGBV RAYALAGANDI AMRABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36281300113	{"id": "36281300113", "block": "Amrabad", "state": "Telangana", "udise": "36281300113", "school": "KGBV RAYALAGANDI AMRABAD", "district": "Nagarkurnool", "enrollment": 337}	teacher-training-schools	\N	\N	\N	1	f
538	36281501504	KGBV BALMOOR	12	156	530	\N	KGBV BALMOOR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36281501504	{"id": "36281501504", "block": "Balmoor", "state": "Telangana", "udise": "36281501504", "school": "KGBV BALMOOR", "district": "Nagarkurnool", "enrollment": 387}	teacher-training-schools	\N	\N	\N	1	f
539	36281901631	KGBV KOLLPUR	12	156	531	\N	KGBV KOLLPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36281901631	{"id": "36281901631", "block": "Kollapur", "state": "Telangana", "udise": "36281901631", "school": "KGBV KOLLPUR", "district": "Nagarkurnool", "enrollment": 408}	teacher-training-schools	\N	\N	\N	1	f
540	36282000527	KGBV PENTLAVELLI	12	156	532	\N	KGBV PENTLAVELLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36282000527	{"id": "36282000527", "block": "Pentlavelly", "state": "Telangana", "udise": "36282000527", "school": "KGBV PENTLAVELLI", "district": "Nagarkurnool", "enrollment": 352}	teacher-training-schools	\N	\N	\N	1	f
541	36290600904	KGBV CHERUKUPALLY	12	157	533	\N	KGBV CHERUKUPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36290600904	{"id": "36290600904", "block": "Kethepally", "state": "Telangana", "udise": "36290600904", "school": "KGBV CHERUKUPALLY", "district": "Nalgonda", "enrollment": 350}	teacher-training-schools	\N	\N	\N	1	f
542	36291002027	KGBV MUNUGODE	12	157	534	\N	KGBV MUNUGODE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36291002027	{"id": "36291002027", "block": "Munugode", "state": "Telangana", "udise": "36291002027", "school": "KGBV MUNUGODE", "district": "Nalgonda", "enrollment": 400}	teacher-training-schools	\N	\N	\N	1	f
543	36291401007	KGBV NAMPALLY	12	157	535	\N	KGBV NAMPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36291401007	{"id": "36291401007", "block": "Nampally", "state": "Telangana", "udise": "36291401007", "school": "KGBV NAMPALLY", "district": "Nalgonda", "enrollment": 297}	teacher-training-schools	\N	\N	\N	1	f
544	36291601535	KGBV HALIYA	12	157	536	\N	KGBV HALIYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36291601535	{"id": "36291601535", "block": "Nagarjuna Sagar", "state": "Telangana", "udise": "36291601535", "school": "KGBV HALIYA", "district": "Nalgonda", "enrollment": 353}	teacher-training-schools	\N	\N	\N	1	f
545	36292000314	KGBV VEMULAPALLY	12	157	537	\N	KGBV VEMULAPALLY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36292000314	{"id": "36292000314", "block": "Miryalaguda,vemul Apally", "state": "Telangana", "udise": "36292000314", "school": "KGBV VEMULAPALLY", "district": "Nalgonda", "enrollment": 367}	teacher-training-schools	\N	\N	\N	1	f
546	36292190106	KGBV MIRYALGUDA	12	157	538	\N	KGBV MIRYALGUDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36292190106	{"id": "36292190106", "block": "Miryalguda", "state": "Telangana", "udise": "36292190106", "school": "KGBV MIRYALGUDA", "district": "Nalgonda", "enrollment": 328}	teacher-training-schools	\N	\N	\N	1	f
547	36292200618	KGBV DAMERACHARLA	12	157	539	\N	KGBV DAMERACHARLA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36292200618	{"id": "36292200618", "block": "Miryalaguda,", "state": "Telangana", "udise": "36292200618", "school": "KGBV DAMERACHARLA", "district": "Nalgonda", "enrollment": 337}	teacher-training-schools	\N	\N	\N	1	f
548	36310100413	KGBV SINGARENI	12	158	540	\N	KGBV SINGARENI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36310100413	{"id": "36310100413", "block": "Singareni", "state": "Telangana", "udise": "36310100413", "school": "KGBV SINGARENI", "district": "Khammam", "enrollment": 329}	teacher-training-schools	\N	\N	\N	1	f
549	36310301008	KGBV RAGHUNADHAPALEM	12	158	541	\N	KGBV RAGHUNADHAPALEM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36310301008	{"id": "36310301008", "block": "Raghundhapalme", "state": "Telangana", "udise": "36310301008", "school": "KGBV RAGHUNADHAPALEM", "district": "Khammam", "enrollment": 319}	teacher-training-schools	\N	\N	\N	1	f
550	36310601605	KGBV KUSUMANCHI	12	158	542	\N	KGBV KUSUMANCHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36310601605	{"id": "36310601605", "block": "Kusumanchi", "state": "Telangana", "udise": "36310601605", "school": "KGBV KUSUMANCHI", "district": "Khammam", "enrollment": 302}	teacher-training-schools	\N	\N	\N	1	f
551	36311092204	KGBV KHAMMAM U	12	158	543	\N	KGBV KHAMMAM U	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36311092204	{"id": "36311092204", "block": "Khammam Urban", "state": "Telangana", "udise": "36311092204", "school": "KGBV KHAMMAM U", "district": "Khammam", "enrollment": 336}	teacher-training-schools	\N	\N	\N	1	f
552	36320101017	KGBV VENKATAPUR	12	159	544	\N	KGBV VENKATAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36320101017	{"id": "36320101017", "block": "Venkatapur", "state": "Telangana", "udise": "36320101017", "school": "KGBV VENKATAPUR", "district": "Mulugu", "enrollment": 300}	teacher-training-schools	\N	\N	\N	1	f
553	36320300411	KGBV CHALVAI (GOVINDARAOPET)	12	159	545	\N	KGBV CHALVAI (GOVINDARAOPET)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36320300411	{"id": "36320300411", "block": "Govindaraopet", "state": "Telangana", "udise": "36320300411", "school": "KGBV CHALVAI (GOVINDARAOPET)", "district": "Mulugu", "enrollment": 304}	teacher-training-schools	\N	\N	\N	1	f
554	36330102207	KGBV DAMARAGIDDA	12	160	546	\N	KGBV DAMARAGIDDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36330102207	{"id": "36330102207", "block": "Damaragidda", "state": "Telangana", "udise": "36330102207", "school": "KGBV DAMARAGIDDA", "district": "Narayanapet", "enrollment": 361}	teacher-training-schools	\N	\N	\N	1	f
555	36330301319	KGBV UTKUR	12	160	547	\N	KGBV UTKUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36330301319	{"id": "36330301319", "block": "Utkoor", "state": "Telangana", "udise": "36330301319", "school": "KGBV UTKUR", "district": "Narayanapet", "enrollment": 419}	teacher-training-schools	\N	\N	\N	1	f
556	36330501504	KGBV KRISHNA	12	160	548	\N	KGBV KRISHNA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36330501504	{"id": "36330501504", "block": "Krishna", "state": "Telangana", "udise": "36330501504", "school": "KGBV KRISHNA", "district": "Narayanapet", "enrollment": 404}	teacher-training-schools	\N	\N	\N	1	f
557	36330601334	KGBV MAKTHAL	12	160	549	\N	KGBV MAKTHAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36330601334	{"id": "36330601334", "block": "Makthal", "state": "Telangana", "udise": "36330601334", "school": "KGBV MAKTHAL", "district": "Narayanapet", "enrollment": 294}	teacher-training-schools	\N	\N	\N	1	f
558	36330700604	KGBV NARWA	12	160	550	\N	KGBV NARWA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36330700604	{"id": "36330700604", "block": "Narwa", "state": "Telangana", "udise": "36330700604", "school": "KGBV NARWA", "district": "Narayanapet", "enrollment": 391}	teacher-training-schools	\N	\N	\N	1	f
559	36330900217	KGBV DHANWADA	12	160	551	\N	KGBV DHANWADA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36330900217	{"id": "36330900217", "block": "Dhanwada", "state": "Telangana", "udise": "36330900217", "school": "KGBV DHANWADA", "district": "Narayanapet", "enrollment": 347}	teacher-training-schools	\N	\N	\N	1	f
560	36011100911	KGBV BHEEMPUR	12	132	552	\N	KGBV BHEEMPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36011100911	{"id": "36011100911", "block": "Bheempur", "state": "Telangana", "udise": "36011100911", "school": "KGBV BHEEMPUR", "district": "Adilabad", "enrollment": 261}	teacher-training-schools	\N	\N	\N	1	f
561	36011402133	KGBV BOATH	12	132	553	\N	KGBV BOATH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36011402133	{"id": "36011402133", "block": "Boath", "state": "Telangana", "udise": "36011402133", "school": "KGBV BOATH", "district": "Adilabad", "enrollment": 236}	teacher-training-schools	\N	\N	\N	1	f
562	36011603544	KGBV SIRIKONDA	12	132	554	\N	KGBV SIRIKONDA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36011603544	{"id": "36011603544", "block": "Sirikonda", "state": "Telangana", "udise": "36011603544", "school": "KGBV SIRIKONDA", "district": "Adilabad", "enrollment": 232}	teacher-training-schools	\N	\N	\N	1	f
563	36020201007	KGBV SIRPURU	12	133	555	\N	KGBV SIRPURU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020201007	{"id": "36020201007", "block": "Sirpur U", "state": "Telangana", "udise": "36020201007", "school": "KGBV SIRPURU", "district": "Kumuram Bheem Asifabad", "enrollment": 279}	teacher-training-schools	\N	\N	\N	1	f
564	36020403905	KGBV MANIKYAPUR	12	133	556	\N	KGBV MANIKYAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020403905	{"id": "36020403905", "block": "Thiryani", "state": "Telangana", "udise": "36020403905", "school": "KGBV MANIKYAPUR", "district": "Kumuram Bheem Asifabad", "enrollment": 239}	teacher-training-schools	\N	\N	\N	1	f
565	36020990180	KGBV KAGAZNAGAR	12	133	557	\N	KGBV KAGAZNAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36020990180	{"id": "36020990180", "block": "Kagaznagar", "state": "Telangana", "udise": "36020990180", "school": "KGBV KAGAZNAGAR", "district": "Kumuram Bheem Asifabad", "enrollment": 284}	teacher-training-schools	\N	\N	\N	1	f
566	36031000107	KGBV NENNEL	12	134	558	\N	KGBV NENNEL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031000107	{"id": "36031000107", "block": "Nennel", "state": "Telangana", "udise": "36031000107", "school": "KGBV NENNEL", "district": "Mancherial", "enrollment": 266}	teacher-training-schools	\N	\N	\N	1	f
567	36031290207	KGBV MANDAMARRY (URDU)	12	134	559	\N	KGBV MANDAMARRY (URDU)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36031290207	{"id": "36031290207", "block": "Mandamarri", "state": "Telangana", "udise": "36031290207", "school": "KGBV MANDAMARRY (URDU)", "district": "Mancherial", "enrollment": 270}	teacher-training-schools	\N	\N	\N	1	f
568	36041701512	KGBV MASKAPUR	12	135	560	\N	KGBV MASKAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36041701512	{"id": "36041701512", "block": "Khanapur", "state": "Telangana", "udise": "36041701512", "school": "KGBV MASKAPUR", "district": "Nirmal", "enrollment": 236}	teacher-training-schools	\N	\N	\N	1	f
569	36050900634	KGBV MORTHAD	12	136	561	\N	KGBV MORTHAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36050900634	{"id": "36050900634", "block": "Morthad", "state": "Telangana", "udise": "36050900634", "school": "KGBV MORTHAD", "district": "Nizamabad", "enrollment": 248}	teacher-training-schools	\N	\N	\N	1	f
570	36331001220	KGBV MADDUR	12	160	562	\N	KGBV MADDUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	36331001220	{"id": "36331001220", "block": "Maddur", "state": "Telangana", "udise": "36331001220", "school": "KGBV MADDUR", "district": "Narayanapet", "enrollment": 309}	teacher-training-schools	\N	\N	\N	1	f
571	9150805515	KASTURBA GANDHI BALIKA VIDHY.JAGNER	13	161	563	\N	KASTURBA GANDHI BALIKA VIDHY.JAGNER	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9150805515	{"id": "9150805515", "block": "Jagner", "state": "Uttar Pradesh", "udise": "9150805515", "school": "KASTURBA GANDHI BALIKA VIDHY.JAGNER", "district": "Agra", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
572	9150503510	K.G.B.V.MIDHAKUR BICHPURI	13	161	564	\N	K.G.B.V.MIDHAKUR BICHPURI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9150503510	{"id": "9150503510", "block": "Bichpuri", "state": "Uttar Pradesh", "udise": "9150503510", "school": "K.G.B.V.MIDHAKUR BICHPURI", "district": "Agra", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
573	9150301235	K.G.B.V.BAH	13	161	565	\N	K.G.B.V.BAH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9150301235	{"id": "9150301235", "block": "Bah", "state": "Uttar Pradesh", "udise": "9150301235", "school": "K.G.B.V.BAH", "district": "Agra", "enrollment": 164}	teacher-training-schools	\N	\N	\N	1	f
574	9120808404	KGBV SUJANPUR	13	162	566	\N	KGBV SUJANPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9120808404	{"id": "9120808404", "block": "Khair", "state": "Uttar Pradesh", "udise": "9120808404", "school": "KGBV SUJANPUR", "district": "Aligarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
575	9480802213	K G B V RAMNAGAR	13	163	567	\N	K G B V RAMNAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480802213	{"id": "9480802213", "block": "Ramnagar", "state": "Uttar Pradesh", "udise": "9480802213", "school": "K G B V RAMNAGAR", "district": "Ambedkar Nagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
576	9480510406	K G B V KATEHARI	13	163	568	\N	K G B V KATEHARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480510406	{"id": "9480510406", "block": "Katehari", "state": "Uttar Pradesh", "udise": "9480510406", "school": "K G B V KATEHARI", "district": "Ambedkar Nagar", "enrollment": 176}	teacher-training-schools	\N	\N	\N	1	f
577	9480601204	K G B V JALALPUR	13	163	569	\N	K G B V JALALPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480601204	{"id": "9480601204", "block": "Jalalpur", "state": "Uttar Pradesh", "udise": "9480601204", "school": "K G B V JALALPUR", "district": "Ambedkar Nagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
578	9480700105	K G B V JAHANGIRGANJ	13	163	570	\N	K G B V JAHANGIRGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480700105	{"id": "9480700105", "block": "Jahangirganj", "state": "Uttar Pradesh", "udise": "9480700105", "school": "K G B V JAHANGIRGANJ", "district": "Ambedkar Nagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
579	9480308304	K G B V BHEETI	13	163	571	\N	K G B V BHEETI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480308304	{"id": "9480308304", "block": "Bheeti", "state": "Uttar Pradesh", "udise": "9480308304", "school": "K G B V BHEETI", "district": "Ambedkar Nagar", "enrollment": 158}	teacher-training-schools	\N	\N	\N	1	f
580	9480401208	K G B V BHIYAON	13	163	572	\N	K G B V BHIYAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480401208	{"id": "9480401208", "block": "Bhiyaon", "state": "Uttar Pradesh", "udise": "9480401208", "school": "K G B V BHIYAON", "district": "Ambedkar Nagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
581	9480110916	K G B V AKBARPUR	13	163	573	\N	K G B V AKBARPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9480110916	{"id": "9480110916", "block": "Akbarpur", "state": "Uttar Pradesh", "udise": "9480110916", "school": "K G B V AKBARPUR", "district": "Ambedkar Nagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
582	9062108308	K.G.BALIKA V. JOYA AMROHA	13	164	574	\N	K.G.BALIKA V. JOYA AMROHA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9062108308	{"id": "9062108308", "block": "Joya", "state": "Uttar Pradesh", "udise": "9062108308", "school": "K.G.BALIKA V. JOYA AMROHA", "district": "Amroha", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
583	9062406720	K.G.B.V. UJHARI	13	164	575	\N	K.G.B.V. UJHARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9062406720	{"id": "9062406720", "block": "Hasanpur", "state": "Uttar Pradesh", "udise": "9062406720", "school": "K.G.B.V. UJHARI", "district": "Amroha", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
584	9061614401	KGBV GANGESHWARI	13	164	576	\N	KGBV GANGESHWARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9061614401	{"id": "9061614401", "block": "Gangeshwari", "state": "Uttar Pradesh", "udise": "9061614401", "school": "KGBV GANGESHWARI", "district": "Amroha", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
585	9061701040	KGBV GAJRAULA	13	164	577	\N	KGBV GAJRAULA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9061701040	{"id": "9061701040", "block": "Gajraula", "state": "Uttar Pradesh", "udise": "9061701040", "school": "KGBV GAJRAULA", "district": "Amroha", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
586	9471008602	KASTURABA GANDHI BALIKA VIDYALAYA ARKUNA	13	165	578	\N	KASTURABA GANDHI BALIKA VIDYALAYA ARKUNA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9471008602	{"id": "9471008602", "block": "Sohawal", "state": "Uttar Pradesh", "udise": "9471008602", "school": "KASTURABA GANDHI BALIKA VIDYALAYA ARKUNA", "district": "Ayodhya", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
587	9470901506	KASTOORVA GANDHI BALIKA VIDYALY, KHAIRANPUR, RUDAULI	13	165	579	\N	KASTOORVA GANDHI BALIKA VIDYALY, KHAIRANPUR, RUDAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9470901506	{"id": "9470901506", "block": "Rudauli", "state": "Uttar Pradesh", "udise": "9470901506", "school": "KASTOORVA GANDHI BALIKA VIDYALY, KHAIRANPUR, RUDAULI", "district": "Ayodhya", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
588	9471208614	KASTORBA GANDHI BALIKA VIDYALAY KUCHERA	13	165	580	\N	KASTORBA GANDHI BALIKA VIDYALAY KUCHERA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9471208614	{"id": "9471208614", "block": "Milkipur", "state": "Uttar Pradesh", "udise": "9471208614", "school": "KASTORBA GANDHI BALIKA VIDYALAY KUCHERA", "district": "Ayodhya", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
589	9470104001	K.G.B.V., PMV AMANIGANJ	13	165	581	\N	K.G.B.V., PMV AMANIGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9470104001	{"id": "9470104001", "block": "Amaniganj", "state": "Uttar Pradesh", "udise": "9470104001", "school": "K.G.B.V., PMV AMANIGANJ", "district": "Ayodhya", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
590	9610601405	K.G.B.V. TARWA	13	166	582	\N	K.G.B.V. TARWA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9610601405	{"id": "9610601405", "block": "Tarwa", "state": "Uttar Pradesh", "udise": "9610601405", "school": "K.G.B.V. TARWA", "district": "Azamgarh", "enrollment": 182}	teacher-training-schools	\N	\N	\N	1	f
591	9610503116	K.G.B.V. MEHNAGAR	13	166	583	\N	K.G.B.V. MEHNAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9610503116	{"id": "9610503116", "block": "Mehnager", "state": "Uttar Pradesh", "udise": "9610503116", "school": "K.G.B.V. MEHNAGAR", "district": "Azamgarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
592	9610400204	K.G.B.V. LALGANJ	13	166	584	\N	K.G.B.V. LALGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9610400204	{"id": "9610400204", "block": "Lalganj", "state": "Uttar Pradesh", "udise": "9610400204", "school": "K.G.B.V. LALGANJ", "district": "Azamgarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
593	9612007804	K.G.B.V. JAHANAGANJ	13	166	585	\N	K.G.B.V. JAHANAGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9612007804	{"id": "9612007804", "block": "Jahanaganj", "state": "Uttar Pradesh", "udise": "9612007804", "school": "K.G.B.V. JAHANAGANJ", "district": "Azamgarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
594	9190214001	KGBV,UJHANI	13	167	586	\N	KGBV,UJHANI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9190214001	{"id": "9190214001", "block": "Ujhani", "state": "Uttar Pradesh", "udise": "9190214001", "school": "KGBV,UJHANI", "district": "Badaun", "enrollment": 120}	teacher-training-schools	\N	\N	\N	1	f
595	9190500104	KGBV,SHASWAN	13	167	587	\N	KGBV,SHASWAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9190500104	{"id": "9190500104", "block": "Sahaswan", "state": "Uttar Pradesh", "udise": "9190500104", "school": "KGBV,SHASWAN", "district": "Badaun", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
596	9190307719	KGBV,ISLAMNAGAR	13	167	588	\N	KGBV,ISLAMNAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9190307719	{"id": "9190307719", "block": "Islamnagar", "state": "Uttar Pradesh", "udise": "9190307719", "school": "KGBV,ISLAMNAGAR", "district": "Badaun", "enrollment": 138}	teacher-training-schools	\N	\N	\N	1	f
597	9190800127	KGBV,DATAGANJ	13	167	589	\N	KGBV,DATAGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9190800127	{"id": "9190800127", "block": "Dataganj", "state": "Uttar Pradesh", "udise": "9190800127", "school": "KGBV,DATAGANJ", "district": "Badaun", "enrollment": 138}	teacher-training-schools	\N	\N	\N	1	f
598	9191600144	KGBV,BISOULI	13	167	590	\N	KGBV,BISOULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9191600144	{"id": "9191600144", "block": "Bisauli", "state": "Uttar Pradesh", "udise": "9191600144", "school": "KGBV,BISOULI", "district": "Badaun", "enrollment": 120}	teacher-training-schools	\N	\N	\N	1	f
599	9192100339	KGBV (MB),BUDAUN	13	167	591	\N	KGBV (MB),BUDAUN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9192100339	{"id": "9192100339", "block": "Budaun City", "state": "Uttar Pradesh", "udise": "9192100339", "school": "KGBV (MB),BUDAUN", "district": "Badaun", "enrollment": 180}	teacher-training-schools	\N	\N	\N	1	f
600	9191306905	KGBV,AMBIYAPUR	13	167	592	\N	KGBV,AMBIYAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9191306905	{"id": "9191306905", "block": "Ambiyapur", "state": "Uttar Pradesh", "udise": "9191306905", "school": "KGBV,AMBIYAPUR", "district": "Badaun", "enrollment": 169}	teacher-training-schools	\N	\N	\N	1	f
601	9191508507	KGBV,FAIZGANJ	13	167	593	\N	KGBV,FAIZGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9191508507	{"id": "9191508507", "block": "Aasafpur", "state": "Uttar Pradesh", "udise": "9191508507", "school": "KGBV,FAIZGANJ", "district": "Badaun", "enrollment": 106}	teacher-training-schools	\N	\N	\N	1	f
602	9080400805	KGBV BAROUT	13	168	594	\N	KGBV BAROUT	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9080400805	{"id": "9080400805", "block": "Baraout Urban", "state": "Uttar Pradesh", "udise": "9080400805", "school": "KGBV BAROUT", "district": "Baghpat", "enrollment": 176}	teacher-training-schools	\N	\N	\N	1	f
603	9080503001	KGBV CHHAPROLI	13	169	595	\N	KGBV CHHAPROLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9080503001	{"id": "9080503001", "block": "Chhaproli", "state": "Uttar Pradesh", "udise": "9080503001", "school": "KGBV CHHAPROLI", "district": "Bahghpat", "enrollment": 175}	teacher-training-schools	\N	\N	\N	1	f
604	9501100907	KGBV MIHIPURWA	13	170	596	\N	KGBV MIHIPURWA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9501100907	{"id": "9501100907", "block": "Mihipurwa", "state": "Uttar Pradesh", "udise": "9501100907", "school": "KGBV MIHIPURWA", "district": "Bahraich", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
605	9522015803	KASTURBA GANDHI AWASIYE BALIKA VIDYALAY TULSIPUR BALRAMPUR	13	171	597	\N	KASTURBA GANDHI AWASIYE BALIKA VIDYALAY TULSIPUR BALRAMPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9522015803	{"id": "9522015803", "block": "Tulsipur", "state": "Uttar Pradesh", "udise": "9522015803", "school": "KASTURBA GANDHI AWASIYE BALIKA VIDYALAY TULSIPUR BALRAMPUR", "district": "Balrampur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
606	9522200306	K.G.B. VIDYALAYA PACHPERWA	13	171	598	\N	K.G.B. VIDYALAYA PACHPERWA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9522200306	{"id": "9522200306", "block": "Pachperwa", "state": "Uttar Pradesh", "udise": "9522200306", "school": "K.G.B. VIDYALAYA PACHPERWA", "district": "Balrampur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
607	9400200306	K.G.B.V. TINDWARI TERHIMAFI	13	172	599	\N	K.G.B.V. TINDWARI TERHIMAFI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9400200306	{"id": "9400200306", "block": "Tindwari", "state": "Uttar Pradesh", "udise": "9400200306", "school": "K.G.B.V. TINDWARI TERHIMAFI", "district": "Banda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
608	9400800114	K.G.B.V. JASPURA	13	172	600	\N	K.G.B.V. JASPURA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9400800114	{"id": "9400800114", "block": "Jaspura", "state": "Uttar Pradesh", "udise": "9400800114", "school": "K.G.B.V. JASPURA", "district": "Banda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
609	9201800905	KASTURBA GANDHI BALIKA VIDYALAY	13	173	601	\N	KASTURBA GANDHI BALIKA VIDYALAY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9201800905	{"id": "9201800905", "block": "Vithari Chainpur", "state": "Uttar Pradesh", "udise": "9201800905", "school": "KASTURBA GANDHI BALIKA VIDYALAY", "district": "Bareilly", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
610	9201600813	KASTURBA GANDHI B VIDYALAY URBAN	13	173	602	\N	KASTURBA GANDHI B VIDYALAY URBAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9201600813	{"id": "9201600813", "block": "Faridpur Town", "state": "Uttar Pradesh", "udise": "9201600813", "school": "KASTURBA GANDHI B VIDYALAY URBAN", "district": "Bareilly", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
611	9201600814	KASTURBA GANDHI B VIDYALAY RURAL	13	173	602	\N	KASTURBA GANDHI B VIDYALAY RURAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9201600814	{"id": "9201600814", "block": "Faridpur Town", "state": "Uttar Pradesh", "udise": "9201600814", "school": "KASTURBA GANDHI B VIDYALAY RURAL", "district": "Bareilly", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
612	9201100119	KASTURBA GANDHI BALIKA VIDYALAY	13	173	603	\N	KASTURBA GANDHI BALIKA VIDYALAY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9201100119	{"id": "9201100119", "block": "Bhojipura", "state": "Uttar Pradesh", "udise": "9201100119", "school": "KASTURBA GANDHI BALIKA VIDYALAY", "district": "Bareilly", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
613	9201906210	KASTURBA GANDI BALIKA VIDYALAY	13	173	604	\N	KASTURBA GANDI BALIKA VIDYALAY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9201906210	{"id": "9201906210", "block": "Bareilly Town", "state": "Uttar Pradesh", "udise": "9201906210", "school": "KASTURBA GANDI BALIKA VIDYALAY", "district": "Bareilly", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
614	9200909410	KASTURBA GANDHI BV	13	173	605	\N	KASTURBA GANDHI BV	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9200909410	{"id": "9200909410", "block": "Shergarh", "state": "Uttar Pradesh", "udise": "9200909410", "school": "KASTURBA GANDHI BV", "district": "Bareilly", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
615	9550708904	K G B V BASTI SADAR	13	174	606	\N	K G B V BASTI SADAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550708904	{"id": "9550708904", "block": "Basti Sadar", "state": "Uttar Pradesh", "udise": "9550708904", "school": "K G B V BASTI SADAR", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
616	9550400335	K G B V BANKATI	13	174	607	\N	K G B V BANKATI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550400335	{"id": "9550400335", "block": "Bankati", "state": "Uttar Pradesh", "udise": "9550400335", "school": "K G B V BANKATI", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
617	9550300820	K G B V RUDHAULI	13	174	608	\N	K G B V RUDHAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550300820	{"id": "9550300820", "block": "Rudholi", "state": "Uttar Pradesh", "udise": "9550300820", "school": "K G B V RUDHAULI", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
618	9551000918	K G B V KHUDRAHA	13	174	609	\N	K G B V KHUDRAHA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9551000918	{"id": "9551000918", "block": "Kudraha", "state": "Uttar Pradesh", "udise": "9551000918", "school": "K G B V KHUDRAHA", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
619	9550218520	K G B V KAPTANGANJ	13	174	610	\N	K G B V KAPTANGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550218520	{"id": "9550218520", "block": "Kaptanganj", "state": "Uttar Pradesh", "udise": "9550218520", "school": "K G B V KAPTANGANJ", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
620	9550602521	K G B V SALTOVA	13	174	611	\N	K G B V SALTOVA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550602521	{"id": "9550602521", "block": "Saltova Gopalpur", "state": "Uttar Pradesh", "udise": "9550602521", "school": "K G B V SALTOVA", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
621	9550905020	K G B V VIKRAMJOT	13	174	612	\N	K G B V VIKRAMJOT	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550905020	{"id": "9550905020", "block": "Vikramjot", "state": "Uttar Pradesh", "udise": "9550905020", "school": "K G B V VIKRAMJOT", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
622	9550108120	K G B V BAHDURPUR	13	174	613	\N	K G B V BAHDURPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550108120	{"id": "9550108120", "block": "Bahadurpur", "state": "Uttar Pradesh", "udise": "9550108120", "school": "K G B V BAHDURPUR", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
623	9551313215	K G B V HARRIYA	13	174	614	\N	K G B V HARRIYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9551313215	{"id": "9551313215", "block": "Harriya", "state": "Uttar Pradesh", "udise": "9551313215", "school": "K G B V HARRIYA", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
624	9550511405	K G B V GAUR	13	174	615	\N	K G B V GAUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9550511405	{"id": "9550511405", "block": "Gaur", "state": "Uttar Pradesh", "udise": "9550511405", "school": "K G B V GAUR", "district": "Basti", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
625	9030704745	KGBV KIRATPUR (RURAL)	13	175	616	\N	KGBV KIRATPUR (RURAL)	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9030704745	{"id": "9030704745", "block": "Kiratpur", "state": "Uttar Pradesh", "udise": "9030704745", "school": "KGBV KIRATPUR (RURAL)", "district": "Bijnor", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
626	9030510405	KGBV HALDAUR	13	175	617	\N	KGBV HALDAUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9030510405	{"id": "9030510405", "block": "Haldaur", "state": "Uttar Pradesh", "udise": "9030510405", "school": "KGBV HALDAUR", "district": "Bijnor", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
627	9191003914	KGBV ALAPUR, MIAUN	13	176	618	\N	KGBV ALAPUR, MIAUN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9191003914	{"id": "9191003914", "block": "Miaun", "state": "Uttar Pradesh", "udise": "9191003914", "school": "KGBV ALAPUR, MIAUN", "district": "Budaun", "enrollment": 198}	teacher-training-schools	\N	\N	\N	1	f
628	9111006822	KGBV GULAOTI	13	177	619	\N	KGBV GULAOTI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9111006822	{"id": "9111006822", "block": "Gulaoti", "state": "Uttar Pradesh", "udise": "9111006822", "school": "KGBV GULAOTI", "district": "Bulandshahr", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
629	9110804207	KGBV DEBAI	13	177	620	\N	KGBV DEBAI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9110804207	{"id": "9110804207", "block": "Debai", "state": "Uttar Pradesh", "udise": "9110804207", "school": "KGBV DEBAI", "district": "Bulandshahr", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
630	9660804503	K.G.B.V. NIYAMATABAD [MAHILA SAMAKHYA]	13	178	621	\N	K.G.B.V. NIYAMATABAD [MAHILA SAMAKHYA]	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9660804503	{"id": "9660804503", "block": "Niyamatabad", "state": "Uttar Pradesh", "udise": "9660804503", "school": "K.G.B.V. NIYAMATABAD [MAHILA SAMAKHYA]", "district": "Chandauli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
631	9660901304	K.G.B.V. NAUGARH	13	178	622	\N	K.G.B.V. NAUGARH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9660901304	{"id": "9660901304", "block": "Naugarh", "state": "Uttar Pradesh", "udise": "9660901304", "school": "K.G.B.V. NAUGARH", "district": "Chandauli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
632	9600903903	K.G.B.V.RAMPUR KARKHANA	13	179	623	\N	K.G.B.V.RAMPUR KARKHANA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9600903903	{"id": "9600903903", "block": "Rampur Karkhana", "state": "Uttar Pradesh", "udise": "9600903903", "school": "K.G.B.V.RAMPUR KARKHANA", "district": "Deoria", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
633	9600515301	K.G.B.V.PATHARDEVA	13	179	624	\N	K.G.B.V.PATHARDEVA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9600515301	{"id": "9600515301", "block": "Patthrdeva", "state": "Uttar Pradesh", "udise": "9600515301", "school": "K.G.B.V.PATHARDEVA", "district": "Deoria", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
634	9601408712	K.G.A.B.B.LAR	13	179	625	\N	K.G.A.B.B.LAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9601408712	{"id": "9601408712", "block": "Lar", "state": "Uttar Pradesh", "udise": "9601408712", "school": "K.G.A.B.B.LAR", "district": "Deoria", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
635	9600307108	K.G.B.V.DEORIA SADAR	13	179	626	\N	K.G.B.V.DEORIA SADAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9600307108	{"id": "9600307108", "block": "Deoria Sadar", "state": "Uttar Pradesh", "udise": "9600307108", "school": "K.G.B.V.DEORIA SADAR", "district": "Deoria", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
636	9601107202	K.G.B.V BHATPAR RANI	13	179	627	\N	K.G.B.V BHATPAR RANI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9601107202	{"id": "9601107202", "block": "Bhatpar Rani", "state": "Uttar Pradesh", "udise": "9601107202", "school": "K.G.B.V BHATPAR RANI", "district": "Deoria", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
637	9601701503	K.G.B.V.BARHAJ	13	179	628	\N	K.G.B.V.BARHAJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9601701503	{"id": "9601701503", "block": "Barahaj", "state": "Uttar Pradesh", "udise": "9601701503", "school": "K.G.B.V.BARHAJ", "district": "Deoria", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
638	9170608203	KGBV UPS PASIYAPUR JALESAR	13	180	629	\N	KGBV UPS PASIYAPUR JALESAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9170608203	{"id": "9170608203", "block": "Jalesar", "state": "Uttar Pradesh", "udise": "9170608203", "school": "KGBV UPS PASIYAPUR JALESAR", "district": "Etah", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
639	9171206902	KGBV UPS (DIET) SAKEET	13	180	630	\N	KGBV UPS (DIET) SAKEET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9171206902	{"id": "9171206902", "block": "Sakeet", "state": "Uttar Pradesh", "udise": "9171206902", "school": "KGBV UPS (DIET) SAKEET", "district": "Etah", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
640	9310901104	KGBV NAGAR ETAWAH	13	181	631	\N	KGBV NAGAR ETAWAH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9310901104	{"id": "9310901104", "block": "Etawah Nagar Chetra", "state": "Uttar Pradesh", "udise": "9310901104", "school": "KGBV NAGAR ETAWAH", "district": "Etawah", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
641	9290200107	KASTURBA GANDHI BALIKA VIDAYA SHAMSABAD FARRUKHABAD	13	182	632	\N	KASTURBA GANDHI BALIKA VIDAYA SHAMSABAD FARRUKHABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9290200107	{"id": "9290200107", "block": "Shamsabad", "state": "Uttar Pradesh", "udise": "9290200107", "school": "KASTURBA GANDHI BALIKA VIDAYA SHAMSABAD FARRUKHABAD", "district": "Farrukhabad", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
642	9420900127	KASTURBA GANDHI B.V. ASOTHAR	13	183	633	\N	KASTURBA GANDHI B.V. ASOTHAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9420900127	{"id": "9420900127", "block": "Ashothar", "state": "Uttar Pradesh", "udise": "9420900127", "school": "KASTURBA GANDHI B.V. ASOTHAR", "district": "Fatehpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
643	9161008503	K.G.B.V. T.A. FIROZABAD | FIROZABAD	13	184	634	\N	K.G.B.V. T.A. FIROZABAD | FIROZABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9161008503	{"id": "9161008503", "block": "T.a. Firozabad", "state": "Uttar Pradesh", "udise": "9161008503", "school": "K.G.B.V. T.A. FIROZABAD | FIROZABAD", "district": "Firozabad", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
644	9160900111	K.G.B.V EKA	13	184	635	\N	K.G.B.V EKA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9160900111	{"id": "9160900111", "block": "Eka", "state": "Uttar Pradesh", "udise": "9160900111", "school": "K.G.B.V EKA", "district": "Firozabad", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
645	9650500910	K.G.B.V.BIRNO	13	185	636	\N	K.G.B.V.BIRNO	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9650500910	{"id": "9650500910", "block": "Birno", "state": "Uttar Pradesh", "udise": "9650500910", "school": "K.G.B.V.BIRNO", "district": "Ghazipur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
646	9650715001	K.G.B.V. SAIDPUR	13	185	637	\N	K.G.B.V. SAIDPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9650715001	{"id": "9650715001", "block": "Saidpur", "state": "Uttar Pradesh", "udise": "9650715001", "school": "K.G.B.V. SAIDPUR", "district": "Ghazipur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
647	9532706602	K.G.B.V. MAHESHPUR	13	186	638	\N	K.G.B.V. MAHESHPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9532706602	{"id": "9532706602", "block": "Nawab Ganj", "state": "Uttar Pradesh", "udise": "9532706602", "school": "K.G.B.V. MAHESHPUR", "district": "Gonda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
648	9531801614	K.G.B.V. WAZIRGANJ	13	186	639	\N	K.G.B.V. WAZIRGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9531801614	{"id": "9531801614", "block": "Wazirganj", "state": "Uttar Pradesh", "udise": "9531801614", "school": "K.G.B.V. WAZIRGANJ", "district": "Gonda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
649	9530703606	K.G.B.V. PANDRI KRIPAL	13	186	640	\N	K.G.B.V. PANDRI KRIPAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9530703606	{"id": "9530703606", "block": "Pandri Kripal", "state": "Uttar Pradesh", "udise": "9530703606", "school": "K.G.B.V. PANDRI KRIPAL", "district": "Gonda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
650	9530501407	K.G.B.V. CHHAPIA MASKANWA	13	186	641	\N	K.G.B.V. CHHAPIA MASKANWA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9530501407	{"id": "9530501407", "block": "Chhapia", "state": "Uttar Pradesh", "udise": "9530501407", "school": "K.G.B.V. CHHAPIA MASKANWA", "district": "Gonda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
651	9530907904	K.G.B.V. JHANJHRI	13	186	642	\N	K.G.B.V. JHANJHRI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9530907904	{"id": "9530907904", "block": "Jhanjhri", "state": "Uttar Pradesh", "udise": "9530907904", "school": "K.G.B.V. JHANJHRI", "district": "Gonda", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
652	9580808401	KGBV. DUMARI COURT SARDAR NAGAR	13	187	643	\N	KGBV. DUMARI COURT SARDAR NAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9580808401	{"id": "9580808401", "block": "Sardarnagar", "state": "Uttar Pradesh", "udise": "9580808401", "school": "KGBV. DUMARI COURT SARDAR NAGAR", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
653	9580102808	KGBV. PIPRAULI	13	187	644	\N	KGBV. PIPRAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9580102808	{"id": "9580102808", "block": "Piprauli", "state": "Uttar Pradesh", "udise": "9580102808", "school": "KGBV. PIPRAULI", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
654	9581304604	KGBV. MINWAN PALLI	13	187	645	\N	KGBV. MINWAN PALLI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9581304604	{"id": "9581304604", "block": "Pali", "state": "Uttar Pradesh", "udise": "9581304604", "school": "KGBV. MINWAN PALLI", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
655	9581000406	KGBV. CHARGANWA [NARMAL CAMPS] GKP.	13	187	646	\N	KGBV. CHARGANWA [NARMAL CAMPS] GKP.	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9581000406	{"id": "9581000406", "block": "Charganwa", "state": "Uttar Pradesh", "udise": "9581000406", "school": "KGBV. CHARGANWA [NARMAL CAMPS] GKP.", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
656	9581612401	KGBV CAMPIARGANJ	13	187	647	\N	KGBV CAMPIARGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9581612401	{"id": "9581612401", "block": "Campiarganj", "state": "Uttar Pradesh", "udise": "9581612401", "school": "KGBV CAMPIARGANJ", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
657	9580606502	KGBV BRAMHPUR	13	187	648	\N	KGBV BRAMHPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9580606502	{"id": "9580606502", "block": "Brahampur", "state": "Uttar Pradesh", "udise": "9580606502", "school": "KGBV BRAMHPUR", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
658	9581700608	KGBV. BELGHAT	13	187	649	\N	KGBV. BELGHAT	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9581700608	{"id": "9581700608", "block": "Belghat", "state": "Uttar Pradesh", "udise": "9581700608", "school": "KGBV. BELGHAT", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
659	9580421410	K.G.B.V BANSGAW	13	187	650	\N	K.G.B.V BANSGAW	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9580421410	{"id": "9580421410", "block": "Bansgaon", "state": "Uttar Pradesh", "udise": "9580421410", "school": "K.G.B.V BANSGAW", "district": "Gorakhpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
660	9251707013	KGBV BILGRAM	13	188	651	\N	KGBV BILGRAM	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9251707013	{"id": "9251707013", "block": "Bilgram", "state": "Uttar Pradesh", "udise": "9251707013", "school": "KGBV BILGRAM", "district": "Hardoi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
661	9250401308	KGBV SURSA	13	188	652	\N	KGBV SURSA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9250401308	{"id": "9250401308", "block": "Sursa", "state": "Uttar Pradesh", "udise": "9250401308", "school": "KGBV SURSA", "district": "Hardoi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
662	9251400108	KGBV HARPALPUR	13	188	653	\N	KGBV HARPALPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9251400108	{"id": "9251400108", "block": "Harpalpur", "state": "Uttar Pradesh", "udise": "9251400108", "school": "KGBV HARPALPUR", "district": "Hardoi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
663	9251600204	KGBV KACHAUNA	13	188	654	\N	KGBV KACHAUNA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9251600204	{"id": "9251600204", "block": "Kachauna", "state": "Uttar Pradesh", "udise": "9251600204", "school": "KGBV KACHAUNA", "district": "Hardoi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
664	9130606441	KGBV SADABAD	13	189	655	\N	KGBV SADABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9130606441	{"id": "9130606441", "block": "Sadabad", "state": "Uttar Pradesh", "udise": "9130606441", "school": "KGBV SADABAD", "district": "Hathras", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
665	9641600108	KGBV BADLAPUR	13	190	656	\N	KGBV BADLAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9641600108	{"id": "9641600108", "block": "Badla Pur", "state": "Uttar Pradesh", "udise": "9641600108", "school": "KGBV BADLAPUR", "district": "Jaunpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
666	9641400104	K.G.B.V. SUJANGANJ	13	190	657	\N	K.G.B.V. SUJANGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9641400104	{"id": "9641400104", "block": "Sujanganj", "state": "Uttar Pradesh", "udise": "9641400104", "school": "K.G.B.V. SUJANGANJ", "district": "Jaunpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
667	9641217209	K.G.B.VIDYALAYA (SHRI NAITGANJ) MACHHALISHAHAR	13	190	658	\N	K.G.B.VIDYALAYA (SHRI NAITGANJ) MACHHALISHAHAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9641217209	{"id": "9641217209", "block": "Machhali Shahar", "state": "Uttar Pradesh", "udise": "9641217209", "school": "K.G.B.VIDYALAYA (SHRI NAITGANJ) MACHHALISHAHAR", "district": "Jaunpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
668	9641506606	K.G.B.V. JAIPALPUR RAMNAGAR	13	190	659	\N	K.G.B.V. JAIPALPUR RAMNAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9641506606	{"id": "9641506606", "block": "Mugra Badshah Pur", "state": "Uttar Pradesh", "udise": "9641506606", "school": "K.G.B.V. JAIPALPUR RAMNAGAR", "district": "Jaunpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
669	9360808104	K.G.B.V MAURANIPUR	13	191	660	\N	K.G.B.V MAURANIPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9360808104	{"id": "9360808104", "block": "Mauranipur", "state": "Uttar Pradesh", "udise": "9360808104", "school": "K.G.B.V MAURANIPUR", "district": "Jhansi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
670	9360608323	K.G.B.V GURSARIAN	13	191	661	\N	K.G.B.V GURSARIAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9360608323	{"id": "9360608323", "block": "Gursarai", "state": "Uttar Pradesh", "udise": "9360608323", "school": "K.G.B.V GURSARIAN", "district": "Jhansi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
671	9360504703	K.G.B.V CHIRGAON	13	191	662	\N	K.G.B.V CHIRGAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9360504703	{"id": "9360504703", "block": "Chirgaon", "state": "Uttar Pradesh", "udise": "9360504703", "school": "K.G.B.V CHIRGAON", "district": "Jhansi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
672	9360102004	KGBV FOREST VILLAGE	13	191	663	\N	KGBV FOREST VILLAGE	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9360102004	{"id": "9360102004", "block": "Babina", "state": "Uttar Pradesh", "udise": "9360102004", "school": "KGBV FOREST VILLAGE", "district": "Jhansi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
673	9300700110	KGBV JALALABAD	13	192	664	\N	KGBV JALALABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9300700110	{"id": "9300700110", "block": "Jalalabad", "state": "Uttar Pradesh", "udise": "9300700110", "school": "KGBV JALALABAD", "district": "Kannauj", "enrollment": 146}	teacher-training-schools	\N	\N	\N	1	f
674	9300411303	KGBV CHHIBRAMAU BADEPUR ROAD	13	192	665	\N	KGBV CHHIBRAMAU BADEPUR ROAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9300411303	{"id": "9300411303", "block": "Chhibramau", "state": "Uttar Pradesh", "udise": "9300411303", "school": "KGBV CHHIBRAMAU BADEPUR ROAD", "district": "Kannauj", "enrollment": 123}	teacher-training-schools	\N	\N	\N	1	f
675	9330211320	K.G.AVASIYA BALIKA VIDHYALAY	13	193	666	\N	K.G.AVASIYA BALIKA VIDHYALAY	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9330211320	{"id": "9330211320", "block": "Amaraudha", "state": "Uttar Pradesh", "udise": "9330211320", "school": "K.G.AVASIYA BALIKA VIDHYALAY", "district": "Kanpur Dehat", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
676	9721409837	KGBV SIDHPURA	13	194	667	\N	KGBV SIDHPURA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9721409837	{"id": "9721409837", "block": "Sidhpura", "state": "Uttar Pradesh", "udise": "9721409837", "school": "KGBV SIDHPURA", "district": "Kasganj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
677	9721101603	KGBV FAROLI SAHAVAR	13	194	668	\N	KGBV FAROLI SAHAVAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9721101603	{"id": "9721101603", "block": "Sahawar", "state": "Uttar Pradesh", "udise": "9721101603", "school": "KGBV FAROLI SAHAVAR", "district": "Kasganj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
678	9720404803	KGBV DHARAMPUR GANJDUNDAWARA	13	194	669	\N	KGBV DHARAMPUR GANJDUNDAWARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9720404803	{"id": "9720404803", "block": "Dundwara", "state": "Uttar Pradesh", "udise": "9720404803", "school": "KGBV DHARAMPUR GANJDUNDAWARA", "district": "Kasganj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
679	9440307706	KGVB SIRATHU	13	195	670	\N	KGVB SIRATHU	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9440307706	{"id": "9440307706", "block": "Sirathu", "state": "Uttar Pradesh", "udise": "9440307706", "school": "KGVB SIRATHU", "district": "Kaushambi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
680	9440405503	K.G.B.V. BALIKA VIDHALAYA	13	195	671	\N	K.G.B.V. BALIKA VIDHALAYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9440405503	{"id": "9440405503", "block": "Newada", "state": "Uttar Pradesh", "udise": "9440405503", "school": "K.G.B.V. BALIKA VIDHALAYA", "district": "Kaushambi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
681	9440107706	KGVB MANJHANPUR	13	195	672	\N	KGVB MANJHANPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9440107706	{"id": "9440107706", "block": "Manjhanpur", "state": "Uttar Pradesh", "udise": "9440107706", "school": "KGVB MANJHANPUR", "district": "Kaushambi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
682	9440207704	KGVB KAUSHAMBI	13	195	673	\N	KGVB KAUSHAMBI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9440207704	{"id": "9440207704", "block": "Kaushambi", "state": "Uttar Pradesh", "udise": "9440207704", "school": "KGVB KAUSHAMBI", "district": "Kaushambi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
683	9591305807	KGBV HIRNAHI	13	196	674	\N	KGBV HIRNAHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9591305807	{"id": "9591305807", "block": "Vishunpura", "state": "Uttar Pradesh", "udise": "9591305807", "school": "KGBV HIRNAHI", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
684	9590207406	KGBV SUKRAULI	13	196	675	\N	KGBV SUKRAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9590207406	{"id": "9590207406", "block": "Sukrauli", "state": "Uttar Pradesh", "udise": "9590207406", "school": "KGBV SUKRAULI", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
685	9591104304	KGBV SEORAHI	13	196	676	\N	KGBV SEORAHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9591104304	{"id": "9591104304", "block": "Seorahi", "state": "Uttar Pradesh", "udise": "9591104304", "school": "KGBV SEORAHI", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
686	9591000313	KGBV TAMKUHI	13	196	677	\N	KGBV TAMKUHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9591000313	{"id": "9591000313", "block": "Tamkuhi", "state": "Uttar Pradesh", "udise": "9591000313", "school": "KGBV TAMKUHI", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
687	9590702104	KGBV MATHAULI BAZAR MOTICHAK	13	196	678	\N	KGBV MATHAULI BAZAR MOTICHAK	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9590702104	{"id": "9590702104", "block": "Motichuk", "state": "Uttar Pradesh", "udise": "9590702104", "school": "KGBV MATHAULI BAZAR MOTICHAK", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
688	9590805709	KGBV KASYA	13	196	679	\N	KGBV KASYA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9590805709	{"id": "9590805709", "block": "Kasia", "state": "Uttar Pradesh", "udise": "9590805709", "school": "KGBV KASYA", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
689	9590403309	KGBV BODARWAR	13	196	680	\N	KGBV BODARWAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9590403309	{"id": "9590403309", "block": "Kaptanganj", "state": "Uttar Pradesh", "udise": "9590403309", "school": "KGBV BODARWAR", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
690	9590603005	KGBV HATA	13	196	681	\N	KGBV HATA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9590603005	{"id": "9590603005", "block": "Hata", "state": "Uttar Pradesh", "udise": "9590603005", "school": "KGBV HATA", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
691	9590900905	KGBV JAURA BAZAR	13	196	682	\N	KGBV JAURA BAZAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9590900905	{"id": "9590900905", "block": "Fazilnagar", "state": "Uttar Pradesh", "udise": "9590900905", "school": "KGBV JAURA BAZAR", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
692	9591200109	KGBV DUDAHI	13	196	683	\N	KGBV DUDAHI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9591200109	{"id": "9591200109", "block": "Dudahi", "state": "Uttar Pradesh", "udise": "9591200109", "school": "KGBV DUDAHI", "district": "Kushinagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
693	9230305802	K.G.B.V.DHAURAHARA	13	197	684	\N	K.G.B.V.DHAURAHARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9230305802	{"id": "9230305802", "block": "Dhourahra", "state": "Uttar Pradesh", "udise": "9230305802", "school": "K.G.B.V.DHAURAHARA", "district": "Lakhimpur Khiri", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
694	9370206610	KASTURBA AVASIYA BALIKA VDLYA BIRDHA LALITPUR	13	198	685	\N	KASTURBA AVASIYA BALIKA VDLYA BIRDHA LALITPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9370206610	{"id": "9370206610", "block": "Birdha", "state": "Uttar Pradesh", "udise": "9370206610", "school": "KASTURBA AVASIYA BALIKA VDLYA BIRDHA LALITPUR", "district": "Lalitpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
695	9370604906	KASTURBA GANDHI AVASIYA BALIKA Vidhalaya MADAWRA LALITPUR	13	198	686	\N	KASTURBA GANDHI AVASIYA BALIKA Vidhalaya MADAWRA LALITPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9370604906	{"id": "9370604906", "block": "Madawra", "state": "Uttar Pradesh", "udise": "9370604906", "school": "KASTURBA GANDHI AVASIYA BALIKA Vidhalaya MADAWRA LALITPUR", "district": "Lalitpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
696	9270704103	KGBV SAROJINI NAGAR	13	199	687	\N	KGBV SAROJINI NAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9270704103	{"id": "9270704103", "block": "Sarojni Nagar", "state": "Uttar Pradesh", "udise": "9270704103", "school": "KGBV SAROJINI NAGAR", "district": "Lucknow", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
697	9270203708	KASTURBA GANDHI BALIKA VIDYALA KAKORI KAKORI LUCKNOW	13	199	688	\N	KASTURBA GANDHI BALIKA VIDYALA KAKORI KAKORI LUCKNOW	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9270203708	{"id": "9270203708", "block": "Kakori", "state": "Uttar Pradesh", "udise": "9270203708", "school": "KASTURBA GANDHI BALIKA VIDYALA KAKORI KAKORI LUCKNOW", "district": "Lucknow", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
698	9270610301	KGBV GOSAIGANJ	13	199	689	\N	KGBV GOSAIGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9270610301	{"id": "9270610301", "block": "Gosaiganj", "state": "Uttar Pradesh", "udise": "9270610301", "school": "KGBV GOSAIGANJ", "district": "Lucknow", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
699	9270809912	K.G.B.V B.K.T	13	199	690	\N	K.G.B.V B.K.T	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9270809912	{"id": "9270809912", "block": "Bakshi Ka Talab", "state": "Uttar Pradesh", "udise": "9270809912", "school": "K.G.B.V B.K.T", "district": "Lucknow", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
700	9390311416	KGBV KABRAI	13	200	691	\N	KGBV KABRAI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9390311416	{"id": "9390311416", "block": "Kabrai", "state": "Uttar Pradesh", "udise": "9390311416", "school": "KGBV KABRAI", "district": "Mahoba", "enrollment": 192}	teacher-training-schools	\N	\N	\N	1	f
701	9570308901	KGBV SISWA BUJURG SISWA	13	201	692	\N	KGBV SISWA BUJURG SISWA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9570308901	{"id": "9570308901", "block": "Siswa", "state": "Uttar Pradesh", "udise": "9570308901", "school": "KGBV SISWA BUJURG SISWA", "district": "Mahrajganj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
702	9140308120	KGBV GOVERDHAN	13	202	693	\N	KGBV GOVERDHAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9140308120	{"id": "9140308120", "block": "Goverdhan", "state": "Uttar Pradesh", "udise": "9140308120", "school": "KGBV GOVERDHAN", "district": "Mathura", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
703	9140400131	KGBV CHHATA	13	202	694	\N	KGBV CHHATA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9140400131	{"id": "9140400131", "block": "Chhata", "state": "Uttar Pradesh", "udise": "9140400131", "school": "KGBV CHHATA", "district": "Mathura", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
704	9140500111	K.G.B.V. CHAUMUHAN	13	202	695	\N	K.G.B.V. CHAUMUHAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9140500111	{"id": "9140500111", "block": "Chaumuhan", "state": "Uttar Pradesh", "udise": "9140500111", "school": "K.G.B.V. CHAUMUHAN", "district": "Mathura", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
705	9620903824	KGBV DEITHAN KOPAGANJ	13	203	696	\N	KGBV DEITHAN KOPAGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9620903824	{"id": "9620903824", "block": "Kopaganj", "state": "Uttar Pradesh", "udise": "9620903824", "school": "KGBV DEITHAN KOPAGANJ", "district": "Mau", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
706	9620702611	K G B V BADRAON	13	203	697	\N	K G B V BADRAON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9620702611	{"id": "9620702611", "block": "Badraw", "state": "Uttar Pradesh", "udise": "9620702611", "school": "K G B V BADRAON", "district": "Mau", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
707	9620207325	K G B V MOHAMMADABAD	13	203	698	\N	K G B V MOHAMMADABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9620207325	{"id": "9620207325", "block": "Mohammadabad", "state": "Uttar Pradesh", "udise": "9620207325", "school": "K G B V MOHAMMADABAD", "district": "Mau", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
708	9690614403	K.G.B.V. RAJGARH	13	204	699	\N	K.G.B.V. RAJGARH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9690614403	{"id": "9690614403", "block": "Rajgarh", "state": "Uttar Pradesh", "udise": "9690614403", "school": "K.G.B.V. RAJGARH", "district": "Mirzapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
709	9690401904	K.G.B.V. PAHARI	13	204	700	\N	K.G.B.V. PAHARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9690401904	{"id": "9690401904", "block": "Pahari", "state": "Uttar Pradesh", "udise": "9690401904", "school": "K.G.B.V. PAHARI", "district": "Mirzapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
710	9042013410	KASTURBA GANDHI BALIKA VIDHYALAYA CHAJLET	13	205	701	\N	KASTURBA GANDHI BALIKA VIDHYALAYA CHAJLET	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9042013410	{"id": "9042013410", "block": "Chajlet", "state": "Uttar Pradesh", "udise": "9042013410", "school": "KASTURBA GANDHI BALIKA VIDHYALAYA CHAJLET", "district": "Moradabad", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
711	9040206704	KASTURBA GANDHI BALIKA VIDHYALAYA BHAGATPUR TANDA MORADABAD	13	205	702	\N	KASTURBA GANDHI BALIKA VIDHYALAYA BHAGATPUR TANDA MORADABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9040206704	{"id": "9040206704", "block": "Bhagatpur Tanda", "state": "Uttar Pradesh", "udise": "9040206704", "school": "KASTURBA GANDHI BALIKA VIDHYALAYA BHAGATPUR TANDA MORADABAD", "district": "Moradabad", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
712	9040908609	KASTURBA GANDHI BALIKA VIDHYALAYA MUNDAPANDAY MORADABAD	13	205	703	\N	KASTURBA GANDHI BALIKA VIDHYALAYA MUNDAPANDAY MORADABAD	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9040908609	{"id": "9040908609", "block": "Mundapanday", "state": "Uttar Pradesh", "udise": "9040908609", "school": "KASTURBA GANDHI BALIKA VIDHYALAYA MUNDAPANDAY MORADABAD", "district": "Moradabad", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
713	9431807106	KASTURBA GANDHI BALIKA VIDHYALAY GAURA PRATAPGARH UTTAR PRADESH	13	206	704	\N	KASTURBA GANDHI BALIKA VIDHYALAY GAURA PRATAPGARH UTTAR PRADESH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9431807106	{"id": "9431807106", "block": "Gaura", "state": "Uttar Pradesh", "udise": "9431807106", "school": "KASTURBA GANDHI BALIKA VIDHYALAY GAURA PRATAPGARH UTTAR PRADESH", "district": "Pratapgarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
736	9221405540	KGBV POWAYAN	13	212	727	\N	KGBV POWAYAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9221405540	{"id": "9221405540", "block": "Puwaya", "state": "Uttar Pradesh", "udise": "9221405540", "school": "KGBV POWAYAN", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
714	9431516401	KASTURBA GANDHI BALIKA VIDHYALAY SADWA-CHANDRIKA PRATAPGARH	13	206	705	\N	KASTURBA GANDHI BALIKA VIDHYALAY SADWA-CHANDRIKA PRATAPGARH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9431516401	{"id": "9431516401", "block": "Sadwa-chandrika", "state": "Uttar Pradesh", "udise": "9431516401", "school": "KASTURBA GANDHI BALIKA VIDHYALAY SADWA-CHANDRIKA PRATAPGARH", "district": "Pratapgarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
715	9430900203	KGBV JAMALPUR LAXMANPUR PRATAPGARH	13	206	706	\N	KGBV JAMALPUR LAXMANPUR PRATAPGARH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9430900203	{"id": "9430900203", "block": "Laxmanpur", "state": "Uttar Pradesh", "udise": "9430900203", "school": "KGBV JAMALPUR LAXMANPUR PRATAPGARH", "district": "Pratapgarh", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
716	9450706810	K.G.B.V. GOHARI	13	207	707	\N	K.G.B.V. GOHARI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9450706810	{"id": "9450706810", "block": "Soraon", "state": "Uttar Pradesh", "udise": "9450706810", "school": "K.G.B.V. GOHARI", "district": "Prayagraj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
717	9451910602	KASTOORABA GANDHI B.V. KAMALANAGAR	13	207	708	\N	KASTOORABA GANDHI B.V. KAMALANAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9451910602	{"id": "9451910602", "block": "Sahson", "state": "Uttar Pradesh", "udise": "9451910602", "school": "KASTOORABA GANDHI B.V. KAMALANAGAR", "district": "Prayagraj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
718	9452008202	K.G.B.V. HANDIA	13	207	709	\N	K.G.B.V. HANDIA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9452008202	{"id": "9452008202", "block": "Handia", "state": "Uttar Pradesh", "udise": "9452008202", "school": "K.G.B.V. HANDIA", "district": "Prayagraj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
719	9450100116	KGBV SHANKARGARH	13	207	710	\N	KGBV SHANKARGARH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9450100116	{"id": "9450100116", "block": "Shankar Garh", "state": "Uttar Pradesh", "udise": "9450100116", "school": "KGBV SHANKARGARH", "district": "Prayagraj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
720	9450205602	KGBV KAUNDHIYARA	13	207	711	\N	KGBV KAUNDHIYARA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9450205602	{"id": "9450205602", "block": "Kaundhiyara", "state": "Uttar Pradesh", "udise": "9450205602", "school": "KGBV KAUNDHIYARA", "district": "Prayagraj", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
721	9281300603	KGBV PATTI RAHAS KAITHWAL	13	208	712	\N	KGBV PATTI RAHAS KAITHWAL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9281300603	{"id": "9281300603", "block": "Unchahar", "state": "Uttar Pradesh", "udise": "9281300603", "school": "KGBV PATTI RAHAS KAITHWAL", "district": "Raebareli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
722	9281000104	KGBV ALAWAL PUR	13	208	713	\N	KGBV ALAWAL PUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9281000104	{"id": "9281000104", "block": "Gaura", "state": "Uttar Pradesh", "udise": "9281000104", "school": "KGBV ALAWAL PUR", "district": "Raebareli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
723	9282500104	KGBV SOOCHI SALON	13	208	714	\N	KGBV SOOCHI SALON	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9282500104	{"id": "9282500104", "block": "Salon", "state": "Uttar Pradesh", "udise": "9282500104", "school": "KGBV SOOCHI SALON", "district": "Raebareli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
724	9280601703	KGBV PARA KALA	13	208	715	\N	KGBV PARA KALA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9280601703	{"id": "9280601703", "block": "Mahrajganj", "state": "Uttar Pradesh", "udise": "9280601703", "school": "KGBV PARA KALA", "district": "Raebareli", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
725	9050402707	KGBV CHAMRUVA	13	209	716	\N	KGBV CHAMRUVA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9050402707	{"id": "9050402707", "block": "Chamrauva", "state": "Uttar Pradesh", "udise": "9050402707", "school": "KGBV CHAMRUVA", "district": "Rampur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
726	9011011105	KGBV PUNWARKA	13	210	717	\N	KGBV PUNWARKA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9011011105	{"id": "9011011105", "block": "Punwarka", "state": "Uttar Pradesh", "udise": "9011011105", "school": "KGBV PUNWARKA", "district": "Saharanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
727	9680500111	KGBV Baniyakhera	13	211	718	\N	KGBV Baniyakhera	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9680500111	{"id": "9680500111", "block": "Baniyakhera", "state": "Uttar Pradesh", "udise": "9680500111", "school": "KGBV Baniyakhera", "district": "Sambhal", "enrollment": 180}	teacher-training-schools	\N	\N	\N	1	f
728	9681700510	KGBV,RAJPURA	13	211	719	\N	KGBV,RAJPURA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9681700510	{"id": "9681700510", "block": "Rajpura", "state": "Uttar Pradesh", "udise": "9681700510", "school": "KGBV,RAJPURA", "district": "Sambhal", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
729	9220909715	KGBV KATRA KHUDAGANJ	13	212	720	\N	KGBV KATRA KHUDAGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9220909715	{"id": "9220909715", "block": "Katra Khudaganj", "state": "Uttar Pradesh", "udise": "9220909715", "school": "KGBV KATRA KHUDAGANJ", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
730	9221500507	KGBV T.A. SHAHJAHANPUR	13	212	721	\N	KGBV T.A. SHAHJAHANPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9221500507	{"id": "9221500507", "block": "T.a.shahjahanpur", "state": "Uttar Pradesh", "udise": "9221500507", "school": "KGBV T.A. SHAHJAHANPUR", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
731	9220806602	KGBV TILHAR	13	212	722	\N	KGBV TILHAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9220806602	{"id": "9220806602", "block": "Tilhar", "state": "Uttar Pradesh", "udise": "9220806602", "school": "KGBV TILHAR", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
732	9221201402	KGBV MIRJAPUR	13	212	723	\N	KGBV MIRJAPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9221201402	{"id": "9221201402", "block": "Mirjapur", "state": "Uttar Pradesh", "udise": "9221201402", "school": "KGBV MIRJAPUR", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
733	9221003404	KGBV KALAN	13	212	724	\N	KGBV KALAN	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9221003404	{"id": "9221003404", "block": "Kalan", "state": "Uttar Pradesh", "udise": "9221003404", "school": "KGBV KALAN", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
734	9220109902	KGBV DADRAUL	13	212	725	\N	KGBV DADRAUL	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9220109902	{"id": "9220109902", "block": "Dadraul", "state": "Uttar Pradesh", "udise": "9220109902", "school": "KGBV DADRAUL", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
735	9221101222	KGBV KANTH	13	212	726	\N	KGBV KANTH	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9221101222	{"id": "9221101222", "block": "Kanth", "state": "Uttar Pradesh", "udise": "9221101222", "school": "KGBV KANTH", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
737	9220207207	KGBV JAITIPUR	13	212	728	\N	KGBV JAITIPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9220207207	{"id": "9220207207", "block": "Jaitipur", "state": "Uttar Pradesh", "udise": "9220207207", "school": "KGBV JAITIPUR", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
738	9220511505	KGBV SINDHAULI	13	212	729	\N	KGBV SINDHAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9220511505	{"id": "9220511505", "block": "Sindhauli", "state": "Uttar Pradesh", "udise": "9220511505", "school": "KGBV SINDHAULI", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
739	9221600404	KGBV NC TILHAR	13	212	730	\N	KGBV NC TILHAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9221600404	{"id": "9221600404", "block": "T.a.tilhar", "state": "Uttar Pradesh", "udise": "9221600404", "school": "KGBV NC TILHAR", "district": "Shahjahanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
740	9541307103	K.G.B.V. USKA BAZAR	13	213	731	\N	K.G.B.V. USKA BAZAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9541307103	{"id": "9541307103", "block": "Uska Bazar", "state": "Uttar Pradesh", "udise": "9541307103", "school": "K.G.B.V. USKA BAZAR", "district": "Siddharthnagar", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
741	9241904403	KGBV SIDHAULI	13	214	732	\N	KGBV SIDHAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9241904403	{"id": "9241904403", "block": "Sidhauli", "state": "Uttar Pradesh", "udise": "9241904403", "school": "KGBV SIDHAULI", "district": "Sitapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
742	9241700107	KGBV REUSA	13	214	733	\N	KGBV REUSA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9241700107	{"id": "9241700107", "block": "Reusa", "state": "Uttar Pradesh", "udise": "9241700107", "school": "KGBV REUSA", "district": "Sitapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
743	9240211401	KGBV BEHTA	13	214	734	\N	KGBV BEHTA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9240211401	{"id": "9240211401", "block": "Behta", "state": "Uttar Pradesh", "udise": "9240211401", "school": "KGBV BEHTA", "district": "Sitapur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
744	9700300737	K.G.B.V ROBERTSGANJ	13	215	735	\N	K.G.B.V ROBERTSGANJ	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9700300737	{"id": "9700300737", "block": "Robertsganj", "state": "Uttar Pradesh", "udise": "9700300737", "school": "K.G.B.V ROBERTSGANJ", "district": "Sonbhadra", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
745	9491503706	KGBV KUREBHAR	13	216	736	\N	KGBV KUREBHAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9491503706	{"id": "9491503706", "block": "Kurebhar", "state": "Uttar Pradesh", "udise": "9491503706", "school": "KGBV KUREBHAR", "district": "Sultanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
746	9491412513	KGBV KADIPUR	13	216	737	\N	KGBV KADIPUR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9491412513	{"id": "9491412513", "block": "Kadipur", "state": "Uttar Pradesh", "udise": "9491412513", "school": "KGBV KADIPUR", "district": "Sultanpur", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
747	9261300109	KGBV HILAULI	13	217	738	\N	KGBV HILAULI	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9261300109	{"id": "9261300109", "block": "Hilouli", "state": "Uttar Pradesh", "udise": "9261300109", "school": "KGBV HILAULI", "district": "Unnao", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
748	9260400138	P.M.KASTURBA GANDHI BALIKA VIDHYAL SAFIPUR UNNAO	13	217	739	\N	P.M.KASTURBA GANDHI BALIKA VIDHYAL SAFIPUR UNNAO	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9260400138	{"id": "9260400138", "block": "Safipur", "state": "Uttar Pradesh", "udise": "9260400138", "school": "P.M.KASTURBA GANDHI BALIKA VIDHYAL SAFIPUR UNNAO", "district": "Unnao", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
749	9670800503	KGBV PINDRA	13	218	740	\N	KGBV PINDRA	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9670800503	{"id": "9670800503", "block": "Pindra", "state": "Uttar Pradesh", "udise": "9670800503", "school": "KGBV PINDRA", "district": "Varanasi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
750	9670905602	KGBV SHIVPUR NAGAR	13	218	741	\N	KGBV SHIVPUR NAGAR	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	9670905602	{"id": "9670905602", "block": ":nagar Nigam", "state": "Uttar Pradesh", "udise": "9670905602", "school": "KGBV SHIVPUR NAGAR", "district": "Varanasi", "enrollment": 200}	teacher-training-schools	\N	\N	\N	1	f
\.


--
-- Data for Name: m_stakeholder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_stakeholder (stakeholder_id, stakeholder_code, stakeholder_name, stakeholder_type, description, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: m_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.m_state (state_id, state_code, state_name, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	S1	Andhra Pradesh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
2	S2	Arunachal Pradesh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
3	S3	Assam	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
4	S4	Chhattisgarh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
5	S5	Gujarat	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
6	S6	Haryana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
7	S7	Jharkhand	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
8	S8	Karnataka	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
9	S9	Manipur	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
10	S10	Rajasthan	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
11	S11	Sikkim	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
12	S12	Telangana	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
13	S13	Uttar Pradesh	t	2026-10-27 15:54:39.128723+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: odoo_project_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.odoo_project_catalog (catalog_id, reference, project_name, sponsor_name, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	TT-2026	Teacher Training	ERNET India	ODOO-PRJ-001	{"id": "ODOO-PRJ-001", "name": "Teacher Training", "sponsor": "ERNET India", "reference": "TT-2026"}	teacher-training-odoo-project-catalog	\N	\N	\N	1	f
2	DC-2026	Digital Classrooms	Schoolnet India	ODOO-PRJ-002	{"id": "ODOO-PRJ-002", "name": "Digital Classrooms", "sponsor": "Schoolnet India", "reference": "DC-2026"}	teacher-training-odoo-project-catalog	\N	\N	\N	1	f
\.


--
-- Data for Name: pii_access_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pii_access_log (pii_access_id, user_id, pii_field_id, entity_id, action, purpose, ip_address, occurred_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: plan_resource_day; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_resource_day (link_day_id, link_id, day_no, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: plan_resource_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_resource_link (link_id, plan_id, resource_id, project_id, apply_existing, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: portal_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_collection (collection_key, table_name, pk_column, read_roles, write_roles) FROM stdin;
teacher-training-registrations	batch_enrollment	enrollment_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer}
teacher-training-attendance-records	attendance	attendance_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,trainer}
teacher-training-attendance-exclusions	attendance_exclusion	exclusion_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,trainer}
teacher-training-assessment-form-master	learning_resource	resource_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin}
teacher-training-assessment-records	assessment_attempt	attempt_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{trainee}
teacher-training-certificates	certificate_record	certificate_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,sponsor-admin,trainer}
teacher-training-eligible-students	school_eligibility	eligibility_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin}
teacher-training-audit	audit_log	audit_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}
teacher-training-trainer-audit	audit_log	audit_id	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer}	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer}
teacher-training-certificate-audit	audit_log	audit_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,sponsor-admin,trainer}
teacher-training-feedback-records	assessment_attempt	attempt_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{trainee}
teacher-training-certificate-templates	certificate_template	template_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,sponsor-admin}
teacher-training-projects	project	project_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin}
teacher-training-plans	training_plan	plan_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin}
teacher-training-trainer-availability	trainer_availability	availability_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,trainer}
teacher-training-trainees	trainee	trainee_id	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee}	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer}
teacher-training-holidays	m_holiday	holiday_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-state-access	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-cluster-master	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-approved-venues	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-school-eligibility	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-odoo-project-catalog	odoo_project_catalog	catalog_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-schools	m_school	school_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-learning-resources	learning_resource	resource_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,trainer}
teacher-training-resource-usage	resource_progress	progress_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{trainee,trainer}
teacher-training-external-course-records	external_course_record	record_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,trainee}
teacher-training-eligible-teachers	school_eligibility	eligibility_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin}
teacher-training-school-assignments	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-users	app_user	user_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-project-plan-associations	project_plan_association	association_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin}
teacher-training-batch-plan-uses	training_batch	batch_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer}
teacher-training-trainer-profiles	trainer	trainer_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin,schoolnet-project-admin,trainer}
teacher-training-school-access	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-school-admin-assignments	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-eligible-participants	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-holiday-policy	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
teacher-training-batch-dependent-records	portal_setting	portal_setting_id	{sponsor-admin,schoolnet-super-admin,schoolnet-project-admin,state-admin,school-admin,trainer,trainee,reporting-audit-user}	{schoolnet-super-admin}
\.


--
-- Data for Name: portal_setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_setting (portal_setting_id, setting_key, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	school-assignments	DEMO-SAMPLE-SCHOOL-ASSIGNMENT	{"id": "DEMO-SAMPLE-SCHOOL-ASSIGNMENT", "userId": "Demo5", "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolUdise": "28111102307"}	teacher-training-school-assignments	1	5	\N	1	f
\.


--
-- Data for Name: profile_change_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profile_change_log (change_id, user_id, field_name, old_value_masked, new_value_masked, changed_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project (project_id, project_code, project_name, start_date, end_date, description, odoo_ref, stakeholder_id, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	PRJ-DEMO-001	Digital Teaching Improvement Project	2026-01-01	2026-12-31	Sample project connecting trainer development to school based teacher training.	DEMO-TT-2026	\N	t	2026-10-27 15:54:39.335634+05:30	\N	2026-10-27 15:54:39.335634+05:30	\N	DEMO-SAMPLE-PROJECT-001	{"id": "DEMO-SAMPLE-PROJECT-001", "code": "PRJ-DEMO-001", "name": "Digital Teaching Improvement Project", "odooId": "DEMO-ODOO-001", "phases": [{"id": "DEMO-SAMPLE-PHASE-01", "name": "Planning and school onboarding", "status": "Completed", "endDate": "2026-03-31", "sequence": 1, "startDate": "2026-01-01"}, {"id": "DEMO-SAMPLE-PHASE-02", "name": "Teacher training delivery", "status": "In Progress", "endDate": "2026-12-31", "sequence": 2, "startDate": "2026-04-01"}], "states": ["Andhra Pradesh"], "status": "Active", "endDate": "2026-12-31", "sponsor": "Schoolnet India", "startDate": "2026-01-01", "description": "Sample project connecting trainer development to school based teacher training.", "assignedUsers": ["Demo2", "Demo3", "Demo4", "Demo5"], "odooReference": "DEMO-TT-2026", "trainingPlans": ["Digital Teaching Foundations"], "batchImportPolicy": "valid-rows", "selectedTrainingPlanIds": ["DEMO-SAMPLE-PLAN-001"]}	teacher-training-projects	1	\N	\N	1	f
3	TEST-d4496ff644	Integration verification	2026-01-01	2027-12-31	Automated integration fixture	TEST-d4496ff644	\N	t	2026-10-27 16:25:25.204374+05:30	\N	2026-10-27 16:25:25.475174+05:30	\N	TEST-PROJECT-d4496ff644	{"id": "TEST-PROJECT-d4496ff644", "code": "TEST-d4496ff644", "name": "Integration verification", "odooId": "TEST-d4496ff644", "phases": [], "states": ["Andhra Pradesh"], "status": "Active", "endDate": "2027-12-31", "sponsor": "Test", "startDate": "2026-01-01", "description": "Automated integration fixture", "assignedUsers": ["Demo2"], "odooReference": "TEST-d4496ff644", "trainingPlans": []}	teacher-training-projects	3	\N	\N	2	t
4	TEST-e9519e0e3d	Integration verification	2026-01-01	2027-12-31	Automated integration fixture	TEST-e9519e0e3d	\N	t	2026-10-27 16:56:56.636593+05:30	\N	2026-10-27 16:56:57.058209+05:30	\N	TEST-PROJECT-e9519e0e3d	{"id": "TEST-PROJECT-e9519e0e3d", "code": "TEST-e9519e0e3d", "name": "Integration verification", "odooId": "TEST-e9519e0e3d", "phases": [], "states": ["Andhra Pradesh"], "status": "Active", "endDate": "2027-12-31", "sponsor": "Test", "startDate": "2026-01-01", "description": "Automated integration fixture", "assignedUsers": ["Demo2"], "odooReference": "TEST-e9519e0e3d", "trainingPlans": []}	teacher-training-projects	4	\N	\N	2	t
5	TEST-92358f6105	Integration verification	2026-01-01	2027-12-31	Automated integration fixture	TEST-92358f6105	\N	t	2026-10-27 17:13:18.009519+05:30	\N	2026-10-27 17:13:18.473441+05:30	\N	TEST-PROJECT-92358f6105	{"id": "TEST-PROJECT-92358f6105", "code": "TEST-92358f6105", "name": "Integration verification", "odooId": "TEST-92358f6105", "phases": [], "states": ["Andhra Pradesh"], "status": "Active", "endDate": "2027-12-31", "sponsor": "Test", "startDate": "2026-01-01", "description": "Automated integration fixture", "assignedUsers": ["Demo2"], "odooReference": "TEST-92358f6105", "trainingPlans": []}	teacher-training-projects	5	\N	\N	2	t
2	TEST-7813160dd8	Integration verification	2026-01-01	2027-12-31	Automated integration fixture	TEST-7813160dd8	\N	t	2026-10-27 16:22:12.662971+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-PROJECT-7813160dd8	{"id": "TEST-PROJECT-7813160dd8", "code": "TEST-7813160dd8", "name": "Integration verification", "odooId": "TEST-7813160dd8", "phases": [], "states": ["Andhra Pradesh"], "status": "Active", "endDate": "2027-12-31", "sponsor": "Test", "startDate": "2026-01-01", "description": "Automated integration fixture", "assignedUsers": ["Demo2"], "odooReference": "TEST-7813160dd8", "trainingPlans": []}	teacher-training-projects	2	\N	\N	2	t
\.


--
-- Data for Name: project_phase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_phase (phase_id, project_id, phase_name, sequence_number, start_date, end_date, status, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	Planning and school onboarding	1	2026-01-01	2026-03-31	Completed	DEMO-SAMPLE-PHASE-01	{"id": "DEMO-SAMPLE-PHASE-01", "name": "Planning and school onboarding", "status": "Completed", "endDate": "2026-03-31", "sequence": 1, "startDate": "2026-01-01"}	\N	1	\N	\N	1	f
2	1	Teacher training delivery	2	2026-04-01	2026-12-31	In Progress	DEMO-SAMPLE-PHASE-02	{"id": "DEMO-SAMPLE-PHASE-02", "name": "Teacher training delivery", "status": "In Progress", "endDate": "2026-12-31", "sequence": 2, "startDate": "2026-04-01"}	\N	1	\N	\N	1	f
\.


--
-- Data for Name: project_plan_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_plan_association (association_id, project_id, plan_id, is_active, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	1	t	DEMO-SAMPLE-ASSOCIATION-001	{"id": "DEMO-SAMPLE-ASSOCIATION-001", "status": "Active", "createdAt": "2026-01-10T09:00:00Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "updatedAt": "2026-01-10T09:00:00Z", "trainingPlanId": "DEMO-SAMPLE-PLAN-001"}	teacher-training-project-plan-associations	1	\N	\N	1	f
2	1	2	t	TEST-ASSOC-d4496ff644	{"id": "TEST-ASSOC-d4496ff644", "status": "Active", "createdAt": "2026-10-27T10:55:25.729Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "updatedAt": "2026-10-27T10:55:25.729Z", "trainingPlanId": "TEST-PLAN-d4496ff644"}	teacher-training-project-plan-associations	1	\N	\N	2	t
3	1	3	t	TEST-ASSOC-e9519e0e3d	{"id": "TEST-ASSOC-e9519e0e3d", "status": "Active", "createdAt": "2026-10-27T11:26:57.454Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "updatedAt": "2026-10-27T11:26:57.454Z", "trainingPlanId": "TEST-PLAN-e9519e0e3d"}	teacher-training-project-plan-associations	1	\N	\N	2	t
4	1	7	t	TEST-ASSOC-92358f6105	{"id": "TEST-ASSOC-92358f6105", "status": "Active", "createdAt": "2026-10-27T11:43:18.867Z", "projectId": "DEMO-SAMPLE-PROJECT-001", "updatedAt": "2026-10-27T11:43:18.867Z", "trainingPlanId": "TEST-PLAN-92358f6105"}	teacher-training-project-plan-associations	1	\N	\N	2	t
\.


--
-- Data for Name: registration_otp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registration_otp (otp_id, batch_id, mobile_enc, mobile_hash, mobile_mask, email_enc, email_hash, email_mask, pii_key_version, otp_hash, created_at, expires_at, attempt_count, verified_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: resource_access_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_access_log (access_id, resource_id, user_id, accessed_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	2	2	2026-10-27 16:25:27.643805+05:30	\N	{}	\N	\N	\N	\N	1	f
2	2	2	2026-10-27 16:56:59.342722+05:30	\N	{}	\N	\N	\N	\N	1	f
3	2	2	2026-10-27 17:13:20.812018+05:30	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: resource_audience; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_audience (audience_id, resource_id, batch_id, trainee_id, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: resource_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_progress (progress_id, trainee_id, resource_id, first_viewed_at, last_viewed_at, last_position_seconds, percent_viewed, completed_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: role_creation_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_creation_rule (rule_id, creator_role_id, creatable_role_id, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permission (role_permission_id, role_id, module_id, can_view, can_create, can_edit, can_delete, can_approve, can_export, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: role_pii_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_pii_permission (role_pii_id, role_id, pii_field_id, view_mode, can_export_full, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: school_eligibility; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_eligibility (eligibility_id, school_id, project_id, beneficiary_type, eligible_count, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	1	teacher	24	DEMO-SAMPLE-ELIGIBLE-TEACHERS	{"id": "DEMO-SAMPLE-ELIGIBLE-TEACHERS", "count": 24, "eligible": true, "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolUdise": "28111102307", "participantType": "teacher"}	teacher-training-eligible-teachers	1	\N	\N	1	f
2	1	1	student	120	DEMO-SAMPLE-ELIGIBLE-STUDENTS	{"id": "DEMO-SAMPLE-ELIGIBLE-STUDENTS", "count": 120, "eligible": true, "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolUdise": "28111102307", "participantType": "student"}	teacher-training-eligible-students	1	\N	\N	1	f
\.


--
-- Data for Name: system_setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_setting (setting_id, project_id, attendance_threshold_pct, pass_score, assessment_required, feedback_required, registration_window, trainer_upload_allowed, propagate_resources, restrict_venue_to_scope, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teachers (id, first_name, last_name, email, password_hash, subject, phone_number, role, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trainee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trainee (trainee_id, trainee_code, full_name, mobile_enc, mobile_hash, mobile_mask, email_enc, email_hash, email_mask, pii_key_version, is_erased, erased_at, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	DEMO-SAMPLE-TRAINEE-007	Sample Trainee	\\x7b0d0a20202264617461223a2022567644795358365a7342647936774b664d757451222c0d0a20202273616c74223a20224d6a385a52577151395a456d325247512f78714b65413d3d222c0d0a2020226e6f6e6365223a202266676d6450327050657970646c36734b222c0d0a202022746167223a20226538336655363637783044664273776c7448334873513d3d222c0d0a2020226d61736b223a20222b392a2a2a2a2a2a2a2a2a2a2a3037222c0d0a20202268617368223a202230393233613263326133613031313233653236613536393764396536333639663334663766613934346636313734326439363334363935653165313439313762220d0a7d	0923a2c2a3a01123e26a5697d9e6369f34f7fa944f61742d9634695e1e14917b	+9***********07	\\x7b0d0a20202264617461223a2022514133634c464943524e78652f79466a735a6e62504a54586e7475354978363156513d3d222c0d0a20202273616c74223a20227041656e42323241345559652b374b55423573416e413d3d222c0d0a2020226e6f6e6365223a20226d4e32752f544d49716f385764776869222c0d0a202022746167223a20224c356d394730754e2f5473786b6b466d6443565677413d3d222c0d0a2020226d61736b223a2022642a2a2a2a2a406578616d706c652e6f7267222c0d0a20202268617368223a202234326634336361653031303463616231393339623131376362303664616664396236313638303366373232663338393864303937666232633437323132653130220d0a7d	42f43cae0104cab1939b117cb06dafd9b616803f722f3898d097fb2c47212e10	d*****@example.org	1	f	\N	t	2026-10-27 15:54:39.672381+05:30	\N	\N	\N	DEMO-SAMPLE-TRAINEE-007	{"id": "DEMO-SAMPLE-TRAINEE-007", "name": "Sample Trainee", "state": "Andhra Pradesh", "userId": "Demo7", "category": "Teacher", "district": "Srikakulam", "_contacts": {"email": {"tag": "L5m9G0uN/TsxkkFmdCVVwA==", "data": "QA3cLFICRNxe/yFjsZnbPJTXntu5Ix61VQ==", "hash": "42f43cae0104cab1939b117cb06dafd9b616803f722f3898d097fb2c47212e10", "mask": "d*****@example.org", "salt": "pAenB22A4UYe+7KUB5sAnA==", "nonce": "mN2u/TMIqo8Wdwhi"}, "phone": {"tag": "e83fU667x0DfBswltH3HsQ==", "data": "VvDySX6ZsBdy6wKfMutQ", "hash": "0923a2c2a3a01123e26a5697d9e6369f34f7fa944f61742d9634695e1e14917b", "mask": "+9***********07", "salt": "Mj8ZRWqQ9ZEm2RGQ/xqKeA==", "nonce": "fgmdP2pPeypdl6sK"}}, "createdAt": "2026-01-10T09:00:00Z", "createdBy": "Demo2", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-007", "schoolName": "KGBV BURJA", "schoolUdise": "28111102307", "consentProvided": true}	teacher-training-trainees	1	7	\N	1	f
2	DEMO-SAMPLE-TRAINEE-008	Sample Teacher Two	\\x7b0d0a20202264617461223a2022394a5130725862576843536e34652b73674e4230222c0d0a20202273616c74223a2022753463412b493178443944575445564a6a72414b63513d3d222c0d0a2020226e6f6e6365223a20227a7a575370396f535662794a71716471222c0d0a202022746167223a20227774356a323278334c49755355426264696d492f64413d3d222c0d0a2020226d61736b223a20222b392a2a2a2a2a2a2a2a2a2a2a3038222c0d0a20202268617368223a202239663734396331646465346135393964653562306261636662383562623336653136323537326331656130383463373538663661653834636337363066383961220d0a7d	9f749c1dde4a599de5b0bacfb85bb36e162572c1ea084c758f6ae84cc760f89a	+9***********08	\\x7b0d0a20202264617461223a20222f336d4241307756685370712b4247487a585169653334383866654b6e73733d222c0d0a20202273616c74223a2022364f4e306c2b44717770334543723375694a4e3075413d3d222c0d0a2020226e6f6e6365223a2022773861487151647448755579494d6b66222c0d0a202022746167223a20224c327a2f5068374a596135696c64397478314e4f4b513d3d222c0d0a2020226d61736b223a2022742a2a2a2a2a406578616d706c652e6f7267222c0d0a20202268617368223a202261636236653165346534346164373431363239343830376437366337633236386533393666383532616363643436376631363732303265643632323132633961220d0a7d	acb6e1e4e44ad7416294807d76c7c268e396f852accd467f167202ed62212c9a	t*****@example.org	1	f	\N	t	2026-10-27 15:54:39.708823+05:30	\N	\N	\N	DEMO-SAMPLE-TRAINEE-008	{"id": "DEMO-SAMPLE-TRAINEE-008", "name": "Sample Teacher Two", "state": "Andhra Pradesh", "category": "Teacher", "district": "Srikakulam", "_contacts": {"email": {"tag": "L2z/Ph7JYa5ild9tx1NOKQ==", "data": "/3mBA0wVhSpq+BGHzXQie3488feKnss=", "hash": "acb6e1e4e44ad7416294807d76c7c268e396f852accd467f167202ed62212c9a", "mask": "t*****@example.org", "salt": "6ON0l+Dqwp3ECr3uiJN0uA==", "nonce": "w8aHqQdtHuUyIMkf"}, "phone": {"tag": "wt5j22x3LIuSUBbdimI/dA==", "data": "9JQ0rXbWhCSn4e+sgNB0", "hash": "9f749c1dde4a599de5b0bacfb85bb36e162572c1ea084c758f6ae84cc760f89a", "mask": "+9***********08", "salt": "u4cA+I1xD9DWTEVJjrAKcQ==", "nonce": "zzWSp9oSVbyJqqdq"}}, "createdAt": "2026-10-20T09:00:00Z", "createdBy": "Demo6", "projectId": "DEMO-SAMPLE-PROJECT-001", "traineeId": "DEMO-SAMPLE-TRAINEE-008", "schoolName": "KGBV BURJA", "schoolUdise": "28111102307", "consentProvided": true}	teacher-training-trainees	1	\N	\N	1	f
3	TR-32707C0DF184	Sample OTP Trainee 37846807e0	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a2022504e34534f722f383645684a35316a38472b7a536c673d3d222c0d0a2020226e6f6e6365223a20225550794e4831615a6842327736536878222c0d0a202022746167223a2022547458546862486d396f6f4161693050495256677a413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a2022306366636852326e305963655a44593276674f65687a456a4767526e7555704c6b7a695a222c0d0a20202273616c74223a20224d443878764f6e7451477339446b3750325061334a773d3d222c0d0a2020226e6f6e6365223a2022664d78485666394b3553507571694e55222c0d0a202022746167223a20226478445762314d65386d336b692b3332587072686d673d3d222c0d0a2020226d61736b223a20226f2a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202264303738363730373131663734653833373539343734316631383630616265303264663363653937353362663464643263346531306532646463343630623565220d0a7d	d078670711f74e837594741f1860abe02df3ce9753bf4dd2c4e10e2ddc460b5e	o*****@example.test	1	f	\N	t	2026-10-27 17:00:44.097113+05:30	\N	2026-10-27 17:01:34.235374+05:30	\N	TR-32707C0DF184	{"id": "TR-32707C0DF184", "name": "Sample OTP Trainee 37846807e0", "userId": "TR-32707C0DF184", "category": "Teacher", "_contacts": {"email": {"tag": "dxDWb1Me8m3ki+32Xprhmg==", "data": "0cfchR2n0YceZDY2vgOehzEjGgRnuUpLkziZ", "hash": "d078670711f74e837594741f1860abe02df3ce9753bf4dd2c4e10e2ddc460b5e", "mask": "o*****@example.test", "salt": "MD8xvOntQGs9Dk7P2Pa3Jw==", "nonce": "fMxHVf9K5SPuqiNU"}, "phone": {"tag": "TtXThbHm9ooAai0PIRVgzA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "PN4SOr/86EhJ51j8G+zSlg==", "nonce": "UPyNH1aZhB2w6Shx"}}, "createdAt": "2026-10-27T11:30:44.059457Z", "traineeId": "TR-32707C0DF184"}	teacher-training-trainees	1	17	\N	2	f
4	TR-DAA3F8A0E3D1	Sample OTP Trainee 9dcc2f5d02	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a20227a466958715151455a6557784731363239615a6b4b773d3d222c0d0a2020226e6f6e6365223a2022414950773351386238456d31495a4343222c0d0a202022746167223a20226e6650656f70565063726e724a6d31774e78776f71413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a202239526d59414e5a4c304f4657544436546b4847544e67574631486f58426a694c4141414f222c0d0a20202273616c74223a2022523770574d39474a526f6c592f4e364f394d6c5455673d3d222c0d0a2020226e6f6e6365223a2022446c514b7551474246756d43557a4a78222c0d0a202022746167223a202244694e3638687356384c73595150344f6479435651673d3d222c0d0a2020226d61736b223a20226f2a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202239366461613766646364373863356466653630323636626433353530396463383263393638343438666130393032373262623934386439393634316436376530220d0a7d	96daa7fdcd78c5dfe60266bd35509dc82c968448fa090272bb948d99641d67e0	o*****@example.test	1	f	\N	t	2026-10-27 17:01:57.033231+05:30	\N	2026-10-27 17:01:57.033231+05:30	\N	TR-DAA3F8A0E3D1	{"id": "TR-DAA3F8A0E3D1", "name": "Sample OTP Trainee 9dcc2f5d02", "userId": "TR-DAA3F8A0E3D1", "category": "Teacher", "_contacts": {"email": {"tag": "DiN68hsV8LsYQP4OdyCVQg==", "data": "9RmYANZL0OFWTD6TkHGTNgWF1HoXBjiLAAAO", "hash": "96daa7fdcd78c5dfe60266bd35509dc82c968448fa090272bb948d99641d67e0", "mask": "o*****@example.test", "salt": "R7pWM9GJRolY/N6O9MlTUg==", "nonce": "DlQKuQGBFumCUzJx"}, "phone": {"tag": "nfPeopVPcrnrJm1wNxwoqA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "zFiXqQQEZeWxG1629aZkKw==", "nonce": "AIPw3Q8b8Em1IZCC"}}, "createdAt": "2026-10-27T11:31:56.989418Z", "traineeId": "TR-DAA3F8A0E3D1"}	teacher-training-trainees	1	18	\N	1	f
5	TR-5430D8AD810D	Sample registered teacher 1793100765860	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a20224f7955557531672f313152334b69684e6e6139556e773d3d222c0d0a2020226e6f6e6365223a2022614249754276786567463745364e456f222c0d0a202022746167223a20225449465a7432576d796668635a46697638686b4d75413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a20226832726e322f514967443269384c74537170496a664d32586a544b52384d716e463971695442414e4571677641513d3d222c0d0a20202273616c74223a2022676c5153574c454731657566354c4d474951347931413d3d222c0d0a2020226e6f6e6365223a2022504f4c446945424e5963313150586d6a222c0d0a202022746167223a202275764f757476345470345039434b6a4f35496b304e513d3d222c0d0a2020226d61736b223a2022622a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202236303339343566323364666561333633336137666262353362373431633130643935303437333661616531633636373066653864316136373562303231333435220d0a7d	603945f23dfea3633a7fbb53b741c10d9504736aae1c6670fe8d1a675b021345	b*****@example.test	1	f	\N	t	2026-10-27 17:02:46.213911+05:30	\N	2026-10-27 17:02:46.213911+05:30	\N	TR-5430D8AD810D	{"id": "TR-5430D8AD810D", "name": "Sample registered teacher 1793100765860", "userId": "TR-5430D8AD810D", "category": "Teacher", "_contacts": {"email": {"tag": "uvOutv4Tp4P9CKjO5Ik0NQ==", "data": "h2rn2/QIgD2i8LtSqpIjfM2XjTKR8MqnF9qiTBANEqgvAQ==", "hash": "603945f23dfea3633a7fbb53b741c10d9504736aae1c6670fe8d1a675b021345", "mask": "b*****@example.test", "salt": "glQSWLEG1euf5LMGIQ4y1A==", "nonce": "POLDiEBNYc11PXmj"}, "phone": {"tag": "TIFZt2WmyfhcZFiv8hkMuA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "OyUUu1g/11R3KihNna9Unw==", "nonce": "aBIuBvxegF7E6NEo"}}, "createdAt": "2026-10-27T11:32:46.1723926Z", "traineeId": "TR-5430D8AD810D"}	teacher-training-trainees	1	19	\N	1	f
6	TR-17AFCB419633	Sample OTP Trainee aee362e923	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a202250765565616a436772505553563864376e324a4d74513d3d222c0d0a2020226e6f6e6365223a2022353079696a332f3362493451434b7351222c0d0a202022746167223a20222f366f625634466c6e7472576f7a42325979664261413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a2022376f473452373968386536375a33703069316155636c394a655734314d6e756a4c674569222c0d0a20202273616c74223a20224f2f3238624a65553863312b64775644714d724c62513d3d222c0d0a2020226e6f6e6365223a202237666b392b4e467a4f39652b4b75766f222c0d0a202022746167223a2022685456536458614c69334a31564c36573566716736413d3d222c0d0a2020226d61736b223a20226f2a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202235653731373866346632326239396366346534636166343963303662303530623230333037306530336633333336356233396332353137643961653564666432220d0a7d	5e7178f4f22b99cf4e4caf49c06b050b203070e03f33365b39c2517d9ae5dfd2	o*****@example.test	1	f	\N	t	2026-10-27 17:05:46.964267+05:30	\N	2026-10-27 17:05:46.964267+05:30	\N	TR-17AFCB419633	{"id": "TR-17AFCB419633", "name": "Sample OTP Trainee aee362e923", "userId": "TR-17AFCB419633", "category": "Teacher", "_contacts": {"email": {"tag": "hTVSdXaLi3J1VL6W5fqg6A==", "data": "7oG4R79h8e67Z3p0i1aUcl9JeW41MnujLgEi", "hash": "5e7178f4f22b99cf4e4caf49c06b050b203070e03f33365b39c2517d9ae5dfd2", "mask": "o*****@example.test", "salt": "O/28bJeU8c1+dwVDqMrLbQ==", "nonce": "7fk9+NFzO9e+Kuvo"}, "phone": {"tag": "/6obV4FlntrWozB2YyfBaA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "PvUeajCgrPUSV8d7n2JMtQ==", "nonce": "50yij3/3bI4QCKsQ"}}, "createdAt": "2026-10-27T11:35:46.9253377Z", "traineeId": "TR-17AFCB419633"}	teacher-training-trainees	1	20	\N	1	f
7	TR-082AB5DF4B64	Sample registered teacher 1793100963044	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a2022417435574a78683131344166745450575654477434673d3d222c0d0a2020226e6f6e6365223a20227849384f5568314f746239317754666f222c0d0a202022746167223a20227237484964513661696f426c704557757766432b72413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a20224d4b4e2b626e4c7134786a6f486a4e5847487453363751576e743554644e34484f6e48714d693067694b48684f773d3d222c0d0a20202273616c74223a202247366d543977686c5352774d456874555378397771413d3d222c0d0a2020226e6f6e6365223a20224559354339502b65436c676f64685941222c0d0a202022746167223a2022793643447a6a64527668584430734d6831774c5376773d3d222c0d0a2020226d61736b223a2022622a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202239353534313430613035363134316236666633393866626165353465616266653139396532363463336563373962636661323133656235343637323832326338220d0a7d	9554140a056141b6ff398fbae54eabfe199e264c3ec79bcfa213eb54672822c8	b*****@example.test	1	f	\N	t	2026-10-27 17:06:03.392696+05:30	\N	2026-10-27 17:06:03.392696+05:30	\N	TR-082AB5DF4B64	{"id": "TR-082AB5DF4B64", "name": "Sample registered teacher 1793100963044", "userId": "TR-082AB5DF4B64", "category": "Teacher", "_contacts": {"email": {"tag": "y6CDzjdRvhXD0sMh1wLSvw==", "data": "MKN+bnLq4xjoHjNXGHtS67QWnt5TdN4HOnHqMi0giKHhOw==", "hash": "9554140a056141b6ff398fbae54eabfe199e264c3ec79bcfa213eb54672822c8", "mask": "b*****@example.test", "salt": "G6mT9whlSRwMEhtUSx9wqA==", "nonce": "EY5C9P+eClgodhYA"}, "phone": {"tag": "r7HIdQ6aioBlpEWuwfC+rA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "At5WJxh114AftTPWVTGt4g==", "nonce": "xI8OUh1Otb91wTfo"}}, "createdAt": "2026-10-27T11:36:03.3539977Z", "traineeId": "TR-082AB5DF4B64"}	teacher-training-trainees	1	21	\N	1	f
8	TR-7E4A208E6C96	Sample registered teacher 1793101133035	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a2022572b42314e73663270422f5a30773163464e352b41773d3d222c0d0a2020226e6f6e6365223a20222f4247464b39677a63745a5068684376222c0d0a202022746167223a2022706f5377345365726f45746f484a72514e63444a42413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a202258736a76374e4241674f5961646e785245413434565576787859764f535a7867525633426b4b73696d4b476e63673d3d222c0d0a20202273616c74223a2022594e4d30476c34336951444e6d34364735586e6439413d3d222c0d0a2020226e6f6e6365223a20227137374c2b48567352355a6e45354168222c0d0a202022746167223a20227947584f37364e634862374570633455424d554a72773d3d222c0d0a2020226d61736b223a2022622a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202232353763623761343232666631346461306365316234646266383664623433613438386137373864383033666436643266376266663838643663663532646137220d0a7d	257cb7a422ff14da0ce1b4dbf86db43a488a778d803fd6d2f7bff88d6cf52da7	b*****@example.test	1	f	\N	t	2026-10-27 17:08:53.407921+05:30	\N	2026-10-27 17:08:53.407921+05:30	\N	TR-7E4A208E6C96	{"id": "TR-7E4A208E6C96", "name": "Sample registered teacher 1793101133035", "userId": "TR-7E4A208E6C96", "category": "Teacher", "_contacts": {"email": {"tag": "yGXO76NcHb7Epc4UBMUJrw==", "data": "Xsjv7NBAgOYadnxREA44VUvxxYvOSZxgRV3BkKsimKGncg==", "hash": "257cb7a422ff14da0ce1b4dbf86db43a488a778d803fd6d2f7bff88d6cf52da7", "mask": "b*****@example.test", "salt": "YNM0Gl43iQDNm46G5Xnd9A==", "nonce": "q77L+HVsR5ZnE5Ah"}, "phone": {"tag": "poSw4SeroEtoHJrQNcDJBA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "W+B1Nsf2pB/Z0w1cFN5+Aw==", "nonce": "/BGFK9gzctZPhhCv"}}, "createdAt": "2026-10-27T11:38:53.3657713Z", "traineeId": "TR-7E4A208E6C96"}	teacher-training-trainees	1	22	\N	1	f
9	TR-D8BD7BE2B7A6	Sample OTP Trainee 27c6193462	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a202244322b363546697051524659397655456a6b656b65673d3d222c0d0a2020226e6f6e6365223a20224a62374e716a526264384a4277687844222c0d0a202022746167223a20223072347179395a4641475135386d546c384b5a7559513d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a2022666731326648702b61386d6975587064737a357279496641386e47623648316b34624247222c0d0a20202273616c74223a20227352424f3767505477496735495048496b7569786f513d3d222c0d0a2020226e6f6e6365223a2022767a4a566b322f7059345559762b3867222c0d0a202022746167223a20226944447371757a696f30464b544669696158473077673d3d222c0d0a2020226d61736b223a20226f2a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202231346337363334663736333830353562666461316434333839616634366536376661666166313965633064383939626532303166343437383631336239666233220d0a7d	14c7634f7638055bfda1d4389af46e67fafaf19ec0d899be201f4478613b9fb3	o*****@example.test	1	f	\N	t	2026-10-27 17:14:23.34919+05:30	\N	2026-10-27 17:14:23.34919+05:30	\N	TR-D8BD7BE2B7A6	{"id": "TR-D8BD7BE2B7A6", "name": "Sample OTP Trainee 27c6193462", "userId": "TR-D8BD7BE2B7A6", "category": "Teacher", "_contacts": {"email": {"tag": "iDDsquzio0FKTFiiaXG0wg==", "data": "fg12fHp+a8miuXpdsz5ryIfA8nGb6H1k4bBG", "hash": "14c7634f7638055bfda1d4389af46e67fafaf19ec0d899be201f4478613b9fb3", "mask": "o*****@example.test", "salt": "sRBO7gPTwIg5IPHIkuixoQ==", "nonce": "vzJVk2/pY4UYv+8g"}, "phone": {"tag": "0r4qy9ZFAGQ58mTl8KZuYQ==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "D2+65FipQRFY9vUEjkekeg==", "nonce": "Jb7NqjRbd8JBwhxD"}}, "createdAt": "2026-10-27T11:44:23.3109757Z", "traineeId": "TR-D8BD7BE2B7A6", "consentProvided": true}	teacher-training-trainees	1	23	\N	1	f
10	TR-A7F6B65E6871	Sample registered teacher 1793101526960	\\x7b0d0a20202264617461223a2022222c0d0a20202273616c74223a2022524454696a346d79647958497136726e75315a4d68413d3d222c0d0a2020226e6f6e6365223a202274474b7543667373797a353836662f4b222c0d0a202022746167223a20224236556e724163686e5a6c50313130433157427149413d3d222c0d0a2020226d61736b223a2022222c0d0a20202268617368223a202262383237613335636630343861323133316630623231653262373765393763326562646461623335346439303366353738643062326231356639643464363763220d0a7d	\N		\\x7b0d0a20202264617461223a20225146366b6d787a6b4c446b79374576627478307373306545326147765046414147516231454c2b766f68533038673d3d222c0d0a20202273616c74223a20227a7a35624431687636685650636a506a486c377550413d3d222c0d0a2020226e6f6e6365223a2022454648624c486f796a75764f2b50694f222c0d0a202022746167223a20222b644b374c396d2b576d74574a4162326530366554513d3d222c0d0a2020226d61736b223a2022622a2a2a2a2a406578616d706c652e74657374222c0d0a20202268617368223a202239616231393539643635343862376436326161356266646531316265356430653562633566633963323063666132373331313165363762303637616161656164220d0a7d	9ab1959d6548b7d62aa5bfde11be5d0e5bc5fc9c20cfa273111e67b067aaaead	b*****@example.test	1	f	\N	t	2026-10-27 17:15:27.351642+05:30	\N	2026-10-27 17:15:27.351642+05:30	\N	TR-A7F6B65E6871	{"id": "TR-A7F6B65E6871", "name": "Sample registered teacher 1793101526960", "userId": "TR-A7F6B65E6871", "category": "Teacher", "_contacts": {"email": {"tag": "+dK7L9m+WmtWJAb2e06eTQ==", "data": "QF6kmxzkLDky7Evbtx0ss0eE2aGvPFAAGQb1EL+vohS08g==", "hash": "9ab1959d6548b7d62aa5bfde11be5d0e5bc5fc9c20cfa273111e67b067aaaead", "mask": "b*****@example.test", "salt": "zz5bD1hv6hVPcjPjHl7uPA==", "nonce": "EFHbLHoyjuvO+PiO"}, "phone": {"tag": "B6UnrAchnZlP110C1WBqIA==", "data": "", "hash": "b827a35cf048a2131f0b21e2b77e97c2ebddab354d903f578d0b2b15f9d4d67c", "mask": "", "salt": "RDTij4mydyXIq6rnu1ZMhA==", "nonce": "tGKuCfssyz586f/K"}}, "createdAt": "2026-10-27T11:45:27.3094253Z", "traineeId": "TR-A7F6B65E6871", "consentProvided": true}	teacher-training-trainees	1	24	\N	1	f
\.


--
-- Data for Name: trainer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trainer (trainer_id, trainer_code, trainer_name, category, mobile_enc, mobile_hash, mobile_mask, email_enc, email_hash, email_mask, pii_key_version, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	TR-00001	Ananya Rao	EMPLOYEE	\\x7b0d0a20202264617461223a20224e504947794435524836357a614b65667a646c33222c0d0a20202273616c74223a202274394670466e454245324268364c67714a54416459773d3d222c0d0a2020226e6f6e6365223a202262543835484d413347736b54664a2b32222c0d0a202022746167223a202258425152705350456b6e4d3077304e543941757270513d3d222c0d0a2020226d61736b223a20222b392a2a2a2a2a2a2a2a2a2a2a3036222c0d0a20202268617368223a202234393462306435376436643165623333383735663164623864333630653132623432326265343465666162376364653838353034636436333533373139613933220d0a7d	494b0d57d6d1eb33875f1db8d360e12b422be44efab7cde88504cd6353719a93	+9***********06	\\x7b0d0a20202264617461223a20227a6974736b35346c4631634e724b6149436b526d53494a562b57584246413d3d222c0d0a20202273616c74223a2022496f3631593561734d7642764774767352526b4259413d3d222c0d0a2020226e6f6e6365223a20224c777637665268416434743553656444222c0d0a202022746167223a20224979422b4e72535841795637394f70546d78543449513d3d222c0d0a2020226d61736b223a2022612a2a2a2a2a406578616d706c652e6f7267222c0d0a20202268617368223a202236333137646433396661336235396232393564393631323932653838383635336131623532643061656161643538343162653962353931383433653265313837220d0a7d	6317dd39fa3b59b295d961292e888653a1b52d0aeaad5841be9b591843e2e187	a*****@example.org	1	t	2026-10-27 15:54:39.461629+05:30	\N	\N	\N	c8704cbb-2f66-4838-a18f-9b037a6e20b5	{"id": "c8704cbb-2f66-4838-a18f-9b037a6e20b5", "name": "Ananya Rao", "state": "Andhra Pradesh", "active": true, "userId": "Demo6", "category": "Employee", "district": "Srikakulam", "_contacts": {"email": {"tag": "IyB+NrSXAyV79OpTmxT4IQ==", "data": "zitsk54lF1cNrKaICkRmSIJV+WXBFA==", "hash": "6317dd39fa3b59b295d961292e888653a1b52d0aeaad5841be9b591843e2e187", "mask": "a*****@example.org", "salt": "Io61Y5asMvBvGtvsRRkBYA==", "nonce": "Lwv7fRhAd4t5SedD"}, "phone": {"tag": "XBQRpSPEknM0w0NT9AurpQ==", "data": "NPIGyD5RH65zaKefzdl3", "hash": "494b0d57d6d1eb33875f1db8d360e12b422be44efab7cde88504cd6353719a93", "mask": "+9***********06", "salt": "t9FpFnEBE2Bh6LgqJTAdYw==", "nonce": "bT85HMA3GskTfJ+2"}}, "languages": ["English", "Telugu"], "serviceArea": "KGBV BURJA", "trainerCode": "TR-00001", "competencies": ["Digital pedagogy", "Classroom technology"], "certifications": "Certified Teacher Trainer", "experienceYears": 8}	teacher-training-trainer-profiles	\N	6	\N	1	f
\.


--
-- Data for Name: trainer_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trainer_availability (availability_id, trainer_id, start_date, end_date, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	2026-11-10	2026-11-10	t	2026-10-27 15:54:39.495222+05:30	\N	\N	\N	DEMO-SAMPLE-AVAILABILITY-1	{"id": "DEMO-SAMPLE-AVAILABILITY-1", "date": "2026-11-10", "status": "Available", "endTime": "16:00", "remarks": "Sample batch availability", "createdBy": "Demo6", "startTime": "09:00", "updatedAt": "2026-10-01T09:00:00Z", "trainerCode": "Demo6"}	teacher-training-trainer-availability	\N	6	\N	1	f
2	1	2026-11-11	2026-11-11	t	2026-10-27 15:54:39.531142+05:30	\N	\N	\N	DEMO-SAMPLE-AVAILABILITY-2	{"id": "DEMO-SAMPLE-AVAILABILITY-2", "date": "2026-11-11", "status": "Available", "endTime": "16:00", "remarks": "Sample batch availability", "createdBy": "Demo6", "startTime": "09:00", "updatedAt": "2026-10-01T09:00:00Z", "trainerCode": "Demo6"}	teacher-training-trainer-availability	\N	6	\N	1	f
3	1	2026-11-12	2026-11-12	t	2026-10-27 15:54:39.567635+05:30	\N	\N	\N	DEMO-SAMPLE-AVAILABILITY-3	{"id": "DEMO-SAMPLE-AVAILABILITY-3", "date": "2026-11-12", "status": "Available", "endTime": "16:00", "remarks": "Sample batch availability", "createdBy": "Demo6", "startTime": "09:00", "updatedAt": "2026-10-01T09:00:00Z", "trainerCode": "Demo6"}	teacher-training-trainer-availability	\N	6	\N	1	f
\.


--
-- Data for Name: training_batch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.training_batch (batch_id, batch_code, project_id, plan_id, school_id, reference_location, actual_location, start_date, end_date, capacity, trainer_id, open_registration, is_closed, closed_at, plan_code_snapshot, plan_snapshot_json, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	BATCH-DEMO-PAST	1	1	1	KGBV BURJA	KGBV BURJA	2026-09-14	2026-09-16	30	1	f	f	\N	TP-DEMO-001	{"id": "DEMO-SAMPLE-PLAN-001", "code": "TP-DEMO-001", "days": 3, "name": "Digital Teaching Foundations", "type": "Hybrid", "_dbId": 1, "status": "Active", "_ownerId": null, "_version": 1, "createdAt": "2026-01-10T09:00:00Z", "resources": [], "description": "Sample program for practical digital teaching and classroom technology.", "beneficiaries": ["Teacher"], "learningResourceIds": ["video", "manual", "guide"], "resourceAssignments": [{"id": "DEMO-SAMPLE-RESOURCE-001", "toDay": 3, "fromDay": 1, "resource": "Teacher training manual", "throughProjectEnd": false}, {"id": "DEMO-SAMPLE-RESOURCE-002", "toDay": 1, "fromDay": 1, "resource": "Pre-assessment", "throughProjectEnd": false}, {"id": "DEMO-SAMPLE-RESOURCE-003", "toDay": 3, "fromDay": 3, "resource": "Feedback form", "throughProjectEnd": false}]}	t	2026-10-27 15:54:39.604019+05:30	\N	2026-10-27 15:54:39.604019+05:30	\N	DEMO-SAMPLE-BATCH-PAST	{"id": "DEMO-SAMPLE-BATCH-PAST", "name": "KGBV BURJA", "state": "Andhra Pradesh", "status": "Completed", "phaseId": "DEMO-SAMPLE-PHASE-02", "district": "Srikakulam", "location": "KGBV BURJA", "uniqueId": "BATCH-DEMO-PAST", "batchCode": "BATCH-DEMO-PAST", "createdAt": "2026-01-10T09:00:00Z", "createdBy": "Demo2", "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolName": "KGBV BURJA", "projectName": "Digital Teaching Improvement Project", "trainerCode": "Demo6", "trainerName": "Ananya Rao", "deliveryMode": "Hybrid", "trainingCycle": "2026 Cycle 1", "trainingDates": ["2026-09-14", "2026-09-15", "2026-09-16"], "assessmentCount": 1, "attendanceCount": 3, "trainingEndAuto": "2026-09-16", "trainingEndTime": "15:30", "openRegistration": false, "schoolUdiseVenue": "28111102307", "trainingDuration": 3, "trainingPlanCode": "TP-DEMO-001", "trainingPlanName": "Digital Teaching Foundations", "trainingStartDate": "2026-09-14", "trainingStartTime": "09:30", "trainerProfileCode": "TR-00001", "registrationCapacity": 30, "projectPlanAssociationId": "DEMO-SAMPLE-ASSOCIATION-001", "registrationWindowAfterDays": 0, "registrationWindowBeforeDays": 14}	teacher-training-batch-plan-uses	1	\N	1	1	f
2	BATCH-DEMO-NOV	1	1	1	KGBV BURJA	KGBV BURJA	2026-11-10	2026-11-12	30	1	t	f	\N	TP-DEMO-001	{"id": "DEMO-SAMPLE-PLAN-001", "code": "TP-DEMO-001", "days": 3, "name": "Digital Teaching Foundations", "type": "Hybrid", "_dbId": 1, "status": "Active", "_ownerId": null, "_version": 1, "createdAt": "2026-01-10T09:00:00Z", "resources": [], "description": "Sample program for practical digital teaching and classroom technology.", "beneficiaries": ["Teacher"], "learningResourceIds": ["video", "manual", "guide"], "resourceAssignments": [{"id": "DEMO-SAMPLE-RESOURCE-001", "toDay": 3, "fromDay": 1, "resource": "Teacher training manual", "throughProjectEnd": false}, {"id": "DEMO-SAMPLE-RESOURCE-002", "toDay": 1, "fromDay": 1, "resource": "Pre-assessment", "throughProjectEnd": false}, {"id": "DEMO-SAMPLE-RESOURCE-003", "toDay": 3, "fromDay": 3, "resource": "Feedback form", "throughProjectEnd": false}]}	t	2026-10-27 15:54:39.640732+05:30	\N	2026-10-27 15:54:39.640732+05:30	\N	DEMO-SAMPLE-BATCH-UPCOMING	{"id": "DEMO-SAMPLE-BATCH-UPCOMING", "name": "KGBV BURJA", "state": "Andhra Pradesh", "status": "Scheduled", "phaseId": "DEMO-SAMPLE-PHASE-02", "district": "Srikakulam", "location": "KGBV BURJA", "uniqueId": "BATCH-DEMO-NOV", "batchCode": "BATCH-DEMO-NOV", "createdAt": "2026-01-10T09:00:00Z", "createdBy": "Demo2", "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolName": "KGBV BURJA", "projectName": "Digital Teaching Improvement Project", "trainerCode": "Demo6", "trainerName": "Ananya Rao", "deliveryMode": "Hybrid", "trainingCycle": "2026 Cycle 2", "trainingDates": ["2026-11-10", "2026-11-11", "2026-11-12"], "assessmentCount": 0, "attendanceCount": 0, "trainingEndAuto": "2026-11-12", "trainingEndTime": "15:30", "openRegistration": true, "schoolUdiseVenue": "28111102307", "trainingDuration": 3, "trainingPlanCode": "TP-DEMO-001", "trainingPlanName": "Digital Teaching Foundations", "trainingStartDate": "2026-11-10", "trainingStartTime": "09:30", "trainerProfileCode": "TR-00001", "registrationCapacity": 30, "projectPlanAssociationId": "DEMO-SAMPLE-ASSOCIATION-001", "registrationWindowAfterDays": 0, "registrationWindowBeforeDays": 14}	teacher-training-batch-plan-uses	1	\N	2	1	f
3	TST-B-d4496ff644	1	2	1	KGBV BURJA	KGBV BURJA	2026-10-26	2026-10-27	30	1	f	f	\N	TST-d4496ff644	{"id": "TEST-PLAN-d4496ff644", "code": "TST-d4496ff644", "days": 2, "name": "Integration plan", "type": "Classroom", "_dbId": 2, "status": "Active", "_ownerId": null, "_version": 1, "createdAt": "2026-10-27T10:55:25.571Z", "resources": [], "description": "Verification", "beneficiaries": ["Teacher"], "completionCriteria": {"requireFeedback": true, "requireAssessments": true, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": 1, "minimumAttendancePercent": 100}, "learningResourceIds": [], "resourceAssignments": []}	t	2026-10-27 16:25:25.934544+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-BATCH-d4496ff644	{"id": "TEST-BATCH-d4496ff644", "name": "Integration batch", "state": "Andhra Pradesh", "status": "Cancelled", "district": "Srikakulam", "location": "KGBV BURJA", "uniqueId": "TST-B-d4496ff644", "batchCode": "TST-B-d4496ff644", "createdAt": "2026-10-27T10:55:25.882Z", "createdBy": "Demo2", "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolName": "KGBV BURJA", "trainerCode": "Demo6", "trainingDates": ["2026-10-26", "2026-10-27"], "trainingEndAuto": "2026-10-27", "trainingEndTime": "08:00", "openRegistration": false, "schoolUdiseVenue": "28111102307", "trainingDuration": 2, "trainingPlanCode": "TST-d4496ff644", "trainingStartDate": "2026-10-26", "trainingStartTime": "07:00", "trainerProfileCode": "TR-00001", "registrationCapacity": 30, "projectPlanAssociationId": "TEST-ASSOC-d4496ff644"}	teacher-training-batch-plan-uses	1	\N	3	3	t
4	TST-B-e9519e0e3d	1	3	1	KGBV BURJA	KGBV BURJA	2026-10-26	2026-10-27	30	1	f	f	\N	TST-e9519e0e3d	{"id": "TEST-PLAN-e9519e0e3d", "code": "TST-e9519e0e3d", "days": 2, "name": "Integration plan", "type": "Classroom", "_dbId": 3, "status": "Active", "_ownerId": null, "_version": 1, "createdAt": "2026-10-27T11:26:57.202Z", "resources": [], "description": "Verification", "beneficiaries": ["Teacher"], "completionCriteria": {"requireFeedback": true, "requireAssessments": true, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": 1, "minimumAttendancePercent": 100}, "learningResourceIds": [], "resourceAssignments": []}	t	2026-10-27 16:56:57.799884+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-BATCH-e9519e0e3d	{"id": "TEST-BATCH-e9519e0e3d", "name": "Integration batch", "state": "Andhra Pradesh", "status": "Cancelled", "district": "Srikakulam", "location": "KGBV BURJA", "uniqueId": "TST-B-e9519e0e3d", "batchCode": "TST-B-e9519e0e3d", "createdAt": "2026-10-27T11:26:57.702Z", "createdBy": "Demo2", "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolName": "KGBV BURJA", "trainerCode": "Demo6", "trainingDates": ["2026-10-26", "2026-10-27"], "trainingEndAuto": "2026-10-27", "trainingEndTime": "08:00", "openRegistration": false, "schoolUdiseVenue": "28111102307", "trainingDuration": 2, "trainingPlanCode": "TST-e9519e0e3d", "trainingStartDate": "2026-10-26", "trainingStartTime": "07:00", "trainerProfileCode": "TR-00001", "registrationCapacity": 30, "projectPlanAssociationId": "TEST-ASSOC-e9519e0e3d"}	teacher-training-batch-plan-uses	1	\N	4	3	t
5	TST-B-92358f6105	1	7	1	KGBV BURJA	KGBV BURJA	2026-10-26	2026-10-27	30	1	f	f	\N	TST-92358f6105	{"id": "TEST-PLAN-92358f6105", "code": "TST-92358f6105", "days": 2, "name": "Integration plan", "type": "Classroom", "_dbId": 7, "status": "Active", "_ownerId": null, "_version": 1, "createdAt": "2026-10-27T11:43:18.634Z", "resources": [], "description": "Verification", "beneficiaries": ["Teacher"], "completionCriteria": {"requireFeedback": true, "requireAssessments": true, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": 1, "minimumAttendancePercent": 100}, "learningResourceIds": [], "resourceAssignments": []}	t	2026-10-27 17:13:19.146519+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-BATCH-92358f6105	{"id": "TEST-BATCH-92358f6105", "name": "Integration batch", "state": "Andhra Pradesh", "status": "Cancelled", "district": "Srikakulam", "location": "KGBV BURJA", "uniqueId": "TST-B-92358f6105", "batchCode": "TST-B-92358f6105", "createdAt": "2026-10-27T11:43:19.096Z", "createdBy": "Demo2", "projectId": "DEMO-SAMPLE-PROJECT-001", "schoolName": "KGBV BURJA", "trainerCode": "Demo6", "trainingDates": ["2026-10-26", "2026-10-27"], "trainingEndAuto": "2026-10-27", "trainingEndTime": "08:00", "openRegistration": false, "schoolUdiseVenue": "28111102307", "trainingDuration": 2, "trainingPlanCode": "TST-92358f6105", "trainingStartDate": "2026-10-26", "trainingStartTime": "07:00", "trainerProfileCode": "TR-00001", "registrationCapacity": 30, "projectPlanAssociationId": "TEST-ASSOC-92358f6105"}	teacher-training-batch-plan-uses	1	\N	5	3	t
\.


--
-- Data for Name: training_plan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.training_plan (plan_id, project_id, plan_code, plan_name, training_type, total_days, description, status, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	\N	TP-DEMO-001	Digital Teaching Foundations	INDUCTION	3	Sample program for practical digital teaching and classroom technology.	ACTIVE	t	2026-10-27 15:54:39.386965+05:30	\N	\N	\N	DEMO-SAMPLE-PLAN-001	{"id": "DEMO-SAMPLE-PLAN-001", "code": "TP-DEMO-001", "days": 3, "name": "Digital Teaching Foundations", "type": "Hybrid", "status": "Active", "createdAt": "2026-01-10T09:00:00Z", "resources": [], "description": "Sample program for practical digital teaching and classroom technology.", "beneficiaries": ["Teacher"], "learningResourceIds": ["video", "manual", "guide"], "resourceAssignments": [{"id": "DEMO-SAMPLE-RESOURCE-001", "toDay": 3, "fromDay": 1, "resource": "Teacher training manual", "throughProjectEnd": false}, {"id": "DEMO-SAMPLE-RESOURCE-002", "toDay": 1, "fromDay": 1, "resource": "Pre-assessment", "throughProjectEnd": false}, {"id": "DEMO-SAMPLE-RESOURCE-003", "toDay": 3, "fromDay": 3, "resource": "Feedback form", "throughProjectEnd": false}]}	teacher-training-plans	\N	\N	\N	1	f
4	\N	TP-00645	Sample workshop 1793100764631	INDUCTION	4		DRAFT	t	2026-10-27 17:02:44.954445+05:30	\N	\N	\N	e10eb5c6-ed0f-499d-8e97-9e1b1d583a4a	{"id": "e10eb5c6-ed0f-499d-8e97-9e1b1d583a4a", "code": "TP-00645", "days": 4, "name": "Sample workshop 1793100764631", "type": "Classroom", "status": "Draft", "createdAt": "2026-10-27T11:32:44.898Z", "resources": [], "description": "", "beneficiaries": [], "completionCriteria": {"requireFeedback": false, "requireAssessments": false, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": null, "minimumAttendancePercent": 0}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	1	f
5	\N	TP-00646	Sample workshop 1793100961817	INDUCTION	4		DRAFT	t	2026-10-27 17:06:02.157465+05:30	\N	\N	\N	2a2b50db-5146-430d-a230-1acd50587491	{"id": "2a2b50db-5146-430d-a230-1acd50587491", "code": "TP-00646", "days": 4, "name": "Sample workshop 1793100961817", "type": "Classroom", "status": "Draft", "createdAt": "2026-10-27T11:36:02.095Z", "resources": [], "description": "", "beneficiaries": [], "completionCriteria": {"requireFeedback": false, "requireAssessments": false, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": null, "minimumAttendancePercent": 0}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	1	f
6	\N	TP-00647	Sample workshop 1793101131734	INDUCTION	4		DRAFT	t	2026-10-27 17:08:52.114338+05:30	\N	\N	\N	63287176-647a-45d6-903f-ce85d82a194f	{"id": "63287176-647a-45d6-903f-ce85d82a194f", "code": "TP-00647", "days": 4, "name": "Sample workshop 1793101131734", "type": "Classroom", "status": "Draft", "createdAt": "2026-10-27T11:38:52.038Z", "resources": [], "description": "", "beneficiaries": [], "completionCriteria": {"requireFeedback": false, "requireAssessments": false, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": null, "minimumAttendancePercent": 0}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	1	f
8	\N	TP-06106	Sample workshop 1793101525764	INDUCTION	4		DRAFT	t	2026-10-27 17:15:26.084598+05:30	\N	\N	\N	5c4b02e0-6b82-4c3b-befa-9723f8d73012	{"id": "5c4b02e0-6b82-4c3b-befa-9723f8d73012", "code": "TP-06106", "days": 4, "name": "Sample workshop 1793101525764", "type": "Classroom", "status": "Draft", "createdAt": "2026-10-27T11:45:26.036Z", "resources": [], "description": "", "beneficiaries": [], "completionCriteria": {"requireFeedback": false, "requireAssessments": false, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": null, "minimumAttendancePercent": 0}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	1	f
2	\N	TST-d4496ff644	Integration plan	INDUCTION	2	Verification	ACTIVE	t	2026-10-27 16:25:25.627936+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-PLAN-d4496ff644	{"id": "TEST-PLAN-d4496ff644", "code": "TST-d4496ff644", "days": 2, "name": "Integration plan", "type": "Classroom", "status": "Active", "createdAt": "2026-10-27T10:55:25.571Z", "resources": [], "description": "Verification", "beneficiaries": ["Teacher"], "completionCriteria": {"requireFeedback": true, "requireAssessments": true, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": 1, "minimumAttendancePercent": 100}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	2	t
3	\N	TST-e9519e0e3d	Integration plan	INDUCTION	2	Verification	ACTIVE	t	2026-10-27 16:56:57.283691+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-PLAN-e9519e0e3d	{"id": "TEST-PLAN-e9519e0e3d", "code": "TST-e9519e0e3d", "days": 2, "name": "Integration plan", "type": "Classroom", "status": "Active", "createdAt": "2026-10-27T11:26:57.202Z", "resources": [], "description": "Verification", "beneficiaries": ["Teacher"], "completionCriteria": {"requireFeedback": true, "requireAssessments": true, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": 1, "minimumAttendancePercent": 100}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	2	t
7	\N	TST-92358f6105	Integration plan	INDUCTION	2	Verification	ACTIVE	t	2026-10-27 17:13:18.687602+05:30	\N	2026-10-27 17:17:11.869743+05:30	\N	TEST-PLAN-92358f6105	{"id": "TEST-PLAN-92358f6105", "code": "TST-92358f6105", "days": 2, "name": "Integration plan", "type": "Classroom", "status": "Active", "createdAt": "2026-10-27T11:43:18.634Z", "resources": [], "description": "Verification", "beneficiaries": ["Teacher"], "completionCriteria": {"requireFeedback": true, "requireAssessments": true, "mandatoryTrainingDays": [], "requireExternalCourse": false, "minimumAssessmentMarks": 1, "minimumAttendancePercent": 100}, "learningResourceIds": [], "resourceAssignments": []}	teacher-training-plans	\N	\N	\N	2	t
\.


--
-- Data for Name: training_plan_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.training_plan_activity (activity_id, plan_day_id, seq_no, activity_type, title, description, start_time, duration_minutes, resource_id, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Data for Name: training_plan_day; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.training_plan_day (plan_day_id, plan_id, day_no, day_title, objective, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	1	Day 1	\N	t	2026-10-27 15:54:39.386965+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
2	1	2	Day 2	\N	t	2026-10-27 15:54:39.386965+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
3	1	3	Day 3	\N	t	2026-10-27 15:54:39.386965+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
4	2	1	Day 1	\N	t	2026-10-27 16:25:25.627936+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
5	2	2	Day 2	\N	t	2026-10-27 16:25:25.627936+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
6	3	1	Day 1	\N	t	2026-10-27 16:56:57.283691+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
7	3	2	Day 2	\N	t	2026-10-27 16:56:57.283691+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
8	4	1	Day 1	\N	t	2026-10-27 17:02:44.954445+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
9	4	2	Day 2	\N	t	2026-10-27 17:02:44.954445+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
10	4	3	Day 3	\N	t	2026-10-27 17:02:44.954445+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
11	4	4	Day 4	\N	t	2026-10-27 17:02:44.954445+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
12	5	1	Day 1	\N	t	2026-10-27 17:06:02.157465+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
13	5	2	Day 2	\N	t	2026-10-27 17:06:02.157465+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
14	5	3	Day 3	\N	t	2026-10-27 17:06:02.157465+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
15	5	4	Day 4	\N	t	2026-10-27 17:06:02.157465+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
16	6	1	Day 1	\N	t	2026-10-27 17:08:52.114338+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
17	6	2	Day 2	\N	t	2026-10-27 17:08:52.114338+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
18	6	3	Day 3	\N	t	2026-10-27 17:08:52.114338+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
19	6	4	Day 4	\N	t	2026-10-27 17:08:52.114338+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
20	7	1	Day 1	\N	t	2026-10-27 17:13:18.687602+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
21	7	2	Day 2	\N	t	2026-10-27 17:13:18.687602+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
22	8	1	Day 1	\N	t	2026-10-27 17:15:26.084598+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
23	8	2	Day 2	\N	t	2026-10-27 17:15:26.084598+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
24	8	3	Day 3	\N	t	2026-10-27 17:15:26.084598+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
25	8	4	Day 4	\N	t	2026-10-27 17:15:26.084598+05:30	2	\N	\N	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: user_access_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_access_scope (scope_id, user_id, project_id, state_id, district_id, block_id, cluster_id, school_id, valid_from, valid_to, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	2	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:39.335634+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
2	3	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:39.335634+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
3	4	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:39.335634+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
4	5	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:39.335634+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
5	1	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:40.118141+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
6	8	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:40.118141+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
7	6	1	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 15:54:40.118141+05:30	\N	\N	\N	\N	{}	\N	\N	\N	\N	1	f
8	2	2	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 16:22:12.662971+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
9	2	3	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 16:25:25.204374+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
10	2	4	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 16:56:56.636593+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
11	2	5	\N	\N	\N	\N	\N	\N	\N	t	2026-10-27 17:13:18.009519+05:30	2	\N	\N	\N	{}	project-assignment	\N	\N	\N	1	f
\.


--
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_activity_log (activity_id, user_id, login_id_tried, activity_type, result, ip_address, occurred_at, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
1	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 16:22:10.718232+05:30	\N	{}	\N	\N	\N	\N	1	f
2	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:22:10.940318+05:30	\N	{}	\N	\N	\N	\N	1	f
3	3	Demo3	LOGIN	SUCCESS	\N	2026-10-27 16:22:11.02726+05:30	\N	{}	\N	\N	\N	\N	1	f
4	4	Demo4	LOGIN	SUCCESS	\N	2026-10-27 16:22:11.103607+05:30	\N	{}	\N	\N	\N	\N	1	f
5	5	Demo5	LOGIN	SUCCESS	\N	2026-10-27 16:22:11.159315+05:30	\N	{}	\N	\N	\N	\N	1	f
6	6	Demo6	LOGIN	SUCCESS	\N	2026-10-27 16:22:11.214096+05:30	\N	{}	\N	\N	\N	\N	1	f
7	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 16:22:11.266792+05:30	\N	{}	\N	\N	\N	\N	1	f
8	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 16:22:11.319173+05:30	\N	{}	\N	\N	\N	\N	1	f
9	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 16:22:42.427112+05:30	\N	{}	\N	\N	\N	\N	1	f
10	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:22:42.486765+05:30	\N	{}	\N	\N	\N	\N	1	f
11	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 16:25:23.732767+05:30	\N	{}	\N	\N	\N	\N	1	f
12	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:25:23.862799+05:30	\N	{}	\N	\N	\N	\N	1	f
13	3	Demo3	LOGIN	SUCCESS	\N	2026-10-27 16:25:23.93579+05:30	\N	{}	\N	\N	\N	\N	1	f
14	4	Demo4	LOGIN	SUCCESS	\N	2026-10-27 16:25:24.002302+05:30	\N	{}	\N	\N	\N	\N	1	f
15	5	Demo5	LOGIN	SUCCESS	\N	2026-10-27 16:25:24.069397+05:30	\N	{}	\N	\N	\N	\N	1	f
16	6	Demo6	LOGIN	SUCCESS	\N	2026-10-27 16:25:24.133141+05:30	\N	{}	\N	\N	\N	\N	1	f
17	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 16:25:24.189541+05:30	\N	{}	\N	\N	\N	\N	1	f
18	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 16:25:24.257715+05:30	\N	{}	\N	\N	\N	\N	1	f
19	\N	NoSuchAccount	LOGIN	FAILED	\N	2026-10-27 16:25:27.766677+05:30	\N	{}	\N	\N	\N	\N	1	f
20	8	\N	LOGOUT	SUCCESS	\N	2026-10-27 16:25:27.785543+05:30	\N	{}	\N	\N	\N	\N	1	f
21	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:25:28.778428+05:30	\N	{}	\N	\N	\N	\N	1	f
22	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 16:27:33.879103+05:30	\N	{}	\N	\N	\N	\N	1	f
23	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.129705+05:30	\N	{}	\N	\N	\N	\N	1	f
24	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.141917+05:30	\N	{}	\N	\N	\N	\N	1	f
25	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.281793+05:30	\N	{}	\N	\N	\N	\N	1	f
26	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.283487+05:30	\N	{}	\N	\N	\N	\N	1	f
27	3	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.343793+05:30	\N	{}	\N	\N	\N	\N	1	f
28	3	Demo3	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.345811+05:30	\N	{}	\N	\N	\N	\N	1	f
29	4	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.400139+05:30	\N	{}	\N	\N	\N	\N	1	f
30	4	Demo4	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.401415+05:30	\N	{}	\N	\N	\N	\N	1	f
31	5	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.465685+05:30	\N	{}	\N	\N	\N	\N	1	f
32	5	Demo5	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.467841+05:30	\N	{}	\N	\N	\N	\N	1	f
33	6	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.52704+05:30	\N	{}	\N	\N	\N	\N	1	f
34	6	Demo6	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.528463+05:30	\N	{}	\N	\N	\N	\N	1	f
35	7	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.58899+05:30	\N	{}	\N	\N	\N	\N	1	f
36	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.591093+05:30	\N	{}	\N	\N	\N	\N	1	f
37	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:56:55.648195+05:30	\N	{}	\N	\N	\N	\N	1	f
38	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 16:56:55.649524+05:30	\N	{}	\N	\N	\N	\N	1	f
39	\N	NoSuchAccount	LOGIN	FAILED	\N	2026-10-27 16:56:59.416432+05:30	\N	{}	\N	\N	\N	\N	1	f
40	8	\N	LOGOUT	SUCCESS	\N	2026-10-27 16:56:59.430258+05:30	\N	{}	\N	\N	\N	\N	1	f
41	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:57:00.268389+05:30	\N	{}	\N	\N	\N	\N	1	f
42	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:57:00.269812+05:30	\N	{}	\N	\N	\N	\N	1	f
43	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:23.735921+05:30	\N	{}	\N	\N	\N	\N	1	f
44	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 16:58:23.737427+05:30	\N	{}	\N	\N	\N	\N	1	f
45	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:29.216543+05:30	\N	{}	\N	\N	\N	\N	1	f
46	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 16:58:29.218957+05:30	\N	{}	\N	\N	\N	\N	1	f
47	3	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:38.728196+05:30	\N	{}	\N	\N	\N	\N	1	f
48	3	Demo3	LOGIN	SUCCESS	\N	2026-10-27 16:58:38.730258+05:30	\N	{}	\N	\N	\N	\N	1	f
49	4	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:43.392992+05:30	\N	{}	\N	\N	\N	\N	1	f
50	4	Demo4	LOGIN	SUCCESS	\N	2026-10-27 16:58:43.394252+05:30	\N	{}	\N	\N	\N	\N	1	f
51	5	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:47.441516+05:30	\N	{}	\N	\N	\N	\N	1	f
52	5	Demo5	LOGIN	SUCCESS	\N	2026-10-27 16:58:47.444241+05:30	\N	{}	\N	\N	\N	\N	1	f
53	6	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:51.456292+05:30	\N	{}	\N	\N	\N	\N	1	f
54	6	Demo6	LOGIN	SUCCESS	\N	2026-10-27 16:58:51.457735+05:30	\N	{}	\N	\N	\N	\N	1	f
55	7	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:58:56.270932+05:30	\N	{}	\N	\N	\N	\N	1	f
56	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 16:58:56.273491+05:30	\N	{}	\N	\N	\N	\N	1	f
57	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 16:59:00.917804+05:30	\N	{}	\N	\N	\N	\N	1	f
58	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 16:59:00.919188+05:30	\N	{}	\N	\N	\N	\N	1	f
59	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:00:43.887092+05:30	\N	{}	\N	\N	\N	\N	1	f
60	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:00:43.890898+05:30	\N	{}	\N	\N	\N	\N	1	f
61	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:00:44.032886+05:30	\N	{}	\N	\N	\N	\N	1	f
62	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 17:00:44.034144+05:30	\N	{}	\N	\N	\N	\N	1	f
63	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:00:44.058664+05:30	\N	{}	\N	\N	\N	\N	1	f
64	17	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:00:44.23217+05:30	\N	{}	\N	\N	\N	\N	1	f
65	17	TR-32707C0DF184	LOGIN	SUCCESS	\N	2026-10-27 17:00:44.233417+05:30	\N	{}	\N	\N	\N	\N	1	f
66	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:01:56.312502+05:30	\N	{}	\N	\N	\N	\N	1	f
67	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:01:56.31946+05:30	\N	{}	\N	\N	\N	\N	1	f
68	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:01:56.948969+05:30	\N	{}	\N	\N	\N	\N	1	f
69	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 17:01:56.950869+05:30	\N	{}	\N	\N	\N	\N	1	f
70	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:01:56.987857+05:30	\N	{}	\N	\N	\N	\N	1	f
71	18	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:01:57.217212+05:30	\N	{}	\N	\N	\N	\N	1	f
72	18	TR-DAA3F8A0E3D1	LOGIN	SUCCESS	\N	2026-10-27 17:01:57.218705+05:30	\N	{}	\N	\N	\N	\N	1	f
73	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:02:44.239223+05:30	\N	{}	\N	\N	\N	\N	1	f
74	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:02:44.24073+05:30	\N	{}	\N	\N	\N	\N	1	f
75	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:02:46.171225+05:30	\N	{}	\N	\N	\N	\N	1	f
76	19	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:02:46.85621+05:30	\N	{}	\N	\N	\N	\N	1	f
77	19	TR-5430D8AD810D	LOGIN	SUCCESS	\N	2026-10-27 17:02:46.858393+05:30	\N	{}	\N	\N	\N	\N	1	f
78	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:46.363811+05:30	\N	{}	\N	\N	\N	\N	1	f
79	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:05:46.374504+05:30	\N	{}	\N	\N	\N	\N	1	f
80	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:46.891047+05:30	\N	{}	\N	\N	\N	\N	1	f
81	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 17:05:46.892755+05:30	\N	{}	\N	\N	\N	\N	1	f
82	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:46.923912+05:30	\N	{}	\N	\N	\N	\N	1	f
83	20	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:47.120489+05:30	\N	{}	\N	\N	\N	\N	1	f
84	20	TR-17AFCB419633	LOGIN	SUCCESS	\N	2026-10-27 17:05:47.122113+05:30	\N	{}	\N	\N	\N	\N	1	f
85	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:47.557969+05:30	\N	{}	\N	\N	\N	\N	1	f
86	20	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:47.589506+05:30	\N	{}	\N	\N	\N	\N	1	f
87	20	\N	PASSWORD_RESET	SUCCESS	\N	2026-10-27 17:05:47.629098+05:30	\N	{}	\N	\N	\N	\N	1	f
88	20	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:47.707607+05:30	\N	{}	\N	\N	\N	\N	1	f
89	20	TR-17AFCB419633	LOGIN	SUCCESS	\N	2026-10-27 17:05:47.708989+05:30	\N	{}	\N	\N	\N	\N	1	f
90	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:47.728915+05:30	\N	{}	\N	\N	\N	\N	1	f
91	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:05:47.788868+05:30	\N	{}	\N	\N	\N	\N	1	f
92	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 17:05:47.790312+05:30	\N	{}	\N	\N	\N	\N	1	f
93	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:06:01.40351+05:30	\N	{}	\N	\N	\N	\N	1	f
94	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:06:01.405038+05:30	\N	{}	\N	\N	\N	\N	1	f
95	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:06:03.353061+05:30	\N	{}	\N	\N	\N	\N	1	f
96	21	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:06:04.036609+05:30	\N	{}	\N	\N	\N	\N	1	f
97	21	TR-082AB5DF4B64	LOGIN	SUCCESS	\N	2026-10-27 17:06:04.038106+05:30	\N	{}	\N	\N	\N	\N	1	f
98	21	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:06:05.370423+05:30	\N	{}	\N	\N	\N	\N	1	f
99	21	\N	PASSWORD_RESET	SUCCESS	\N	2026-10-27 17:06:05.411792+05:30	\N	{}	\N	\N	\N	\N	1	f
100	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:08:50.855842+05:30	\N	{}	\N	\N	\N	\N	1	f
101	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:08:50.864591+05:30	\N	{}	\N	\N	\N	\N	1	f
102	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:08:53.36437+05:30	\N	{}	\N	\N	\N	\N	1	f
103	22	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:08:54.046827+05:30	\N	{}	\N	\N	\N	\N	1	f
104	22	TR-7E4A208E6C96	LOGIN	SUCCESS	\N	2026-10-27 17:08:54.048356+05:30	\N	{}	\N	\N	\N	\N	1	f
105	22	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:08:55.520576+05:30	\N	{}	\N	\N	\N	\N	1	f
106	22	\N	PASSWORD_RESET	SUCCESS	\N	2026-10-27 17:08:55.563725+05:30	\N	{}	\N	\N	\N	\N	1	f
107	22	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:08:56.161299+05:30	\N	{}	\N	\N	\N	\N	1	f
108	22	TR-7E4A208E6C96	LOGIN	SUCCESS	\N	2026-10-27 17:08:56.16481+05:30	\N	{}	\N	\N	\N	\N	1	f
109	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:16.61883+05:30	\N	{}	\N	\N	\N	\N	1	f
110	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 17:13:16.625165+05:30	\N	{}	\N	\N	\N	\N	1	f
111	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:16.708591+05:30	\N	{}	\N	\N	\N	\N	1	f
112	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:13:16.710216+05:30	\N	{}	\N	\N	\N	\N	1	f
113	3	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:16.771076+05:30	\N	{}	\N	\N	\N	\N	1	f
114	3	Demo3	LOGIN	SUCCESS	\N	2026-10-27 17:13:16.772448+05:30	\N	{}	\N	\N	\N	\N	1	f
115	4	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:16.83358+05:30	\N	{}	\N	\N	\N	\N	1	f
116	4	Demo4	LOGIN	SUCCESS	\N	2026-10-27 17:13:16.835021+05:30	\N	{}	\N	\N	\N	\N	1	f
117	5	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:16.893891+05:30	\N	{}	\N	\N	\N	\N	1	f
118	5	Demo5	LOGIN	SUCCESS	\N	2026-10-27 17:13:16.895548+05:30	\N	{}	\N	\N	\N	\N	1	f
119	6	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:16.95678+05:30	\N	{}	\N	\N	\N	\N	1	f
120	6	Demo6	LOGIN	SUCCESS	\N	2026-10-27 17:13:16.958173+05:30	\N	{}	\N	\N	\N	\N	1	f
121	7	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:17.017657+05:30	\N	{}	\N	\N	\N	\N	1	f
122	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 17:13:17.018998+05:30	\N	{}	\N	\N	\N	\N	1	f
123	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:17.077682+05:30	\N	{}	\N	\N	\N	\N	1	f
124	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 17:13:17.079556+05:30	\N	{}	\N	\N	\N	\N	1	f
125	\N	NoSuchAccount	LOGIN	FAILED	\N	2026-10-27 17:13:20.863187+05:30	\N	{}	\N	\N	\N	\N	1	f
126	8	\N	LOGOUT	SUCCESS	\N	2026-10-27 17:13:20.873815+05:30	\N	{}	\N	\N	\N	\N	1	f
127	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:13:22.902243+05:30	\N	{}	\N	\N	\N	\N	1	f
128	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:13:22.90369+05:30	\N	{}	\N	\N	\N	\N	1	f
129	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:23.153988+05:30	\N	{}	\N	\N	\N	\N	1	f
130	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:14:23.156712+05:30	\N	{}	\N	\N	\N	\N	1	f
131	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:23.28088+05:30	\N	{}	\N	\N	\N	\N	1	f
132	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 17:14:23.282459+05:30	\N	{}	\N	\N	\N	\N	1	f
133	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:23.309964+05:30	\N	{}	\N	\N	\N	\N	1	f
134	23	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:23.468477+05:30	\N	{}	\N	\N	\N	\N	1	f
135	23	TR-D8BD7BE2B7A6	LOGIN	SUCCESS	\N	2026-10-27 17:14:23.469895+05:30	\N	{}	\N	\N	\N	\N	1	f
136	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:23.892781+05:30	\N	{}	\N	\N	\N	\N	1	f
137	23	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:23.924774+05:30	\N	{}	\N	\N	\N	\N	1	f
138	23	\N	PASSWORD_RESET	SUCCESS	\N	2026-10-27 17:14:23.966521+05:30	\N	{}	\N	\N	\N	\N	1	f
139	23	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:24.029617+05:30	\N	{}	\N	\N	\N	\N	1	f
140	23	TR-D8BD7BE2B7A6	LOGIN	SUCCESS	\N	2026-10-27 17:14:24.030881+05:30	\N	{}	\N	\N	\N	\N	1	f
141	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:24.051468+05:30	\N	{}	\N	\N	\N	\N	1	f
142	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:14:24.108265+05:30	\N	{}	\N	\N	\N	\N	1	f
143	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 17:14:24.109644+05:30	\N	{}	\N	\N	\N	\N	1	f
144	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:15:25.376331+05:30	\N	{}	\N	\N	\N	\N	1	f
145	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:15:25.377678+05:30	\N	{}	\N	\N	\N	\N	1	f
146	\N	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:15:27.308464+05:30	\N	{}	\N	\N	\N	\N	1	f
147	24	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:15:27.891775+05:30	\N	{}	\N	\N	\N	\N	1	f
148	24	TR-A7F6B65E6871	LOGIN	SUCCESS	\N	2026-10-27 17:15:27.893128+05:30	\N	{}	\N	\N	\N	\N	1	f
149	24	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:15:29.2092+05:30	\N	{}	\N	\N	\N	\N	1	f
150	24	\N	PASSWORD_RESET	SUCCESS	\N	2026-10-27 17:15:29.248575+05:30	\N	{}	\N	\N	\N	\N	1	f
151	24	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:15:29.674061+05:30	\N	{}	\N	\N	\N	\N	1	f
152	24	TR-A7F6B65E6871	LOGIN	SUCCESS	\N	2026-10-27 17:15:29.675535+05:30	\N	{}	\N	\N	\N	\N	1	f
153	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:16:31.314951+05:30	\N	{}	\N	\N	\N	\N	1	f
154	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 17:16:31.316466+05:30	\N	{}	\N	\N	\N	\N	1	f
155	2	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:16:36.712843+05:30	\N	{}	\N	\N	\N	\N	1	f
156	2	Demo2	LOGIN	SUCCESS	\N	2026-10-27 17:16:36.71408+05:30	\N	{}	\N	\N	\N	\N	1	f
157	3	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:16:46.225498+05:30	\N	{}	\N	\N	\N	\N	1	f
158	3	Demo3	LOGIN	SUCCESS	\N	2026-10-27 17:16:46.226792+05:30	\N	{}	\N	\N	\N	\N	1	f
159	4	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:16:51.089762+05:30	\N	{}	\N	\N	\N	\N	1	f
160	4	Demo4	LOGIN	SUCCESS	\N	2026-10-27 17:16:51.092429+05:30	\N	{}	\N	\N	\N	\N	1	f
161	5	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:16:55.18803+05:30	\N	{}	\N	\N	\N	\N	1	f
162	5	Demo5	LOGIN	SUCCESS	\N	2026-10-27 17:16:55.189802+05:30	\N	{}	\N	\N	\N	\N	1	f
163	6	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:16:59.319025+05:30	\N	{}	\N	\N	\N	\N	1	f
164	6	Demo6	LOGIN	SUCCESS	\N	2026-10-27 17:16:59.320368+05:30	\N	{}	\N	\N	\N	\N	1	f
165	7	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:17:04.11717+05:30	\N	{}	\N	\N	\N	\N	1	f
166	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 17:17:04.118623+05:30	\N	{}	\N	\N	\N	\N	1	f
167	8	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:17:08.981095+05:30	\N	{}	\N	\N	\N	\N	1	f
168	8	Demo8	LOGIN	SUCCESS	\N	2026-10-27 17:17:08.982498+05:30	\N	{}	\N	\N	\N	\N	1	f
169	7	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:18:52.718549+05:30	\N	{}	\N	\N	\N	\N	1	f
170	7	Demo7	LOGIN	SUCCESS	\N	2026-10-27 17:18:52.724368+05:30	\N	{}	\N	\N	\N	\N	1	f
171	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:20:59.89278+05:30	\N	{}	\N	\N	\N	\N	1	f
172	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 17:20:59.895018+05:30	\N	{}	\N	\N	\N	\N	1	f
173	1	\N	OTP_VERIFY	SUCCESS	\N	2026-10-27 17:21:08.409957+05:30	\N	{}	\N	\N	\N	\N	1	f
174	1	Demo1	LOGIN	SUCCESS	\N	2026-10-27 17:21:08.412057+05:30	\N	{}	\N	\N	\N	\N	1	f
\.


--
-- Data for Name: user_pii_override; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_pii_override (override_id, user_id, pii_field_id, view_mode, reason, valid_from, valid_to, is_active, created_at, created_by, updated_at, updated_by, external_id, ui_data, portal_collection, portal_project_id, portal_owner_user_id, portal_batch_id, row_version, portal_deleted) FROM stdin;
\.


--
-- Name: app_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_user_user_id_seq', 32, true);


--
-- Name: assessment_attempt_attempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assessment_attempt_attempt_id_seq', 6, true);


--
-- Name: attendance_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_attendance_id_seq', 7, true);


--
-- Name: attendance_exclusion_exclusion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_exclusion_exclusion_id_seq', 1, false);


--
-- Name: audit_log_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_audit_id_seq', 92, true);


--
-- Name: batch_day_activity_batch_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_day_activity_batch_activity_id_seq', 1, false);


--
-- Name: batch_day_batch_day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_day_batch_day_id_seq', 18, true);


--
-- Name: batch_enrollment_enrollment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_enrollment_enrollment_id_seq', 14, true);


--
-- Name: batch_registration_link_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_registration_link_link_id_seq', 1, false);


--
-- Name: bulk_upload_log_upload_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bulk_upload_log_upload_id_seq', 1, false);


--
-- Name: certificate_record_certificate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.certificate_record_certificate_id_seq', 2, true);


--
-- Name: certificate_template_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.certificate_template_template_id_seq', 3, true);


--
-- Name: completion_review_completion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.completion_review_completion_id_seq', 4, true);


--
-- Name: consent_record_consent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consent_record_consent_id_seq', 5, true);


--
-- Name: data_subject_request_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.data_subject_request_request_id_seq', 1, false);


--
-- Name: external_course_record_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.external_course_record_record_id_seq', 1, false);


--
-- Name: form_question_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.form_question_question_id_seq', 8, true);


--
-- Name: form_submission_submission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.form_submission_submission_id_seq', 6, true);


--
-- Name: learning_resource_resource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.learning_resource_resource_id_seq', 13, true);


--
-- Name: m_block_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_block_block_id_seq', 741, true);


--
-- Name: m_cluster_cluster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_cluster_cluster_id_seq', 1, false);


--
-- Name: m_district_district_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_district_district_id_seq', 218, true);


--
-- Name: m_holiday_holiday_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_holiday_holiday_id_seq', 2, true);


--
-- Name: m_module_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_module_module_id_seq', 1, false);


--
-- Name: m_pii_field_pii_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_pii_field_pii_field_id_seq', 1, false);


--
-- Name: m_role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_role_role_id_seq', 32, true);


--
-- Name: m_school_school_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_school_school_id_seq', 2250, true);


--
-- Name: m_stakeholder_stakeholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_stakeholder_stakeholder_id_seq', 1, false);


--
-- Name: m_state_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.m_state_state_id_seq', 13, true);


--
-- Name: odoo_project_catalog_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.odoo_project_catalog_catalog_id_seq', 2, true);


--
-- Name: pii_access_log_pii_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pii_access_log_pii_access_id_seq', 1, false);


--
-- Name: plan_resource_day_link_day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_resource_day_link_day_id_seq', 1, false);


--
-- Name: plan_resource_link_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_resource_link_link_id_seq', 1, false);


--
-- Name: portal_setting_portal_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.portal_setting_portal_setting_id_seq', 1, true);


--
-- Name: profile_change_log_change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.profile_change_log_change_id_seq', 1, false);


--
-- Name: project_phase_phase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_phase_phase_id_seq', 2, true);


--
-- Name: project_plan_association_association_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_plan_association_association_id_seq', 4, true);


--
-- Name: project_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_project_id_seq', 5, true);


--
-- Name: registration_otp_otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.registration_otp_otp_id_seq', 1, false);


--
-- Name: resource_access_log_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resource_access_log_access_id_seq', 3, true);


--
-- Name: resource_audience_audience_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resource_audience_audience_id_seq', 1, false);


--
-- Name: resource_progress_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resource_progress_progress_id_seq', 1, false);


--
-- Name: role_creation_rule_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_creation_rule_rule_id_seq', 1, false);


--
-- Name: role_permission_role_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permission_role_permission_id_seq', 1, false);


--
-- Name: role_pii_permission_role_pii_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_pii_permission_role_pii_id_seq', 1, false);


--
-- Name: school_eligibility_eligibility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.school_eligibility_eligibility_id_seq', 2, true);


--
-- Name: system_setting_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_setting_setting_id_seq', 1, false);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teachers_id_seq', 1, false);


--
-- Name: trainee_trainee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trainee_trainee_id_seq', 10, true);


--
-- Name: trainer_availability_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trainer_availability_availability_id_seq', 3, true);


--
-- Name: trainer_trainer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trainer_trainer_id_seq', 1, true);


--
-- Name: training_batch_batch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.training_batch_batch_id_seq', 5, true);


--
-- Name: training_plan_activity_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.training_plan_activity_activity_id_seq', 1, false);


--
-- Name: training_plan_day_plan_day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.training_plan_day_plan_day_id_seq', 25, true);


--
-- Name: training_plan_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.training_plan_plan_id_seq', 8, true);


--
-- Name: user_access_scope_scope_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_access_scope_scope_id_seq', 11, true);


--
-- Name: user_activity_log_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_activity_log_activity_id_seq', 174, true);


--
-- Name: user_pii_override_override_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_pii_override_override_id_seq', 1, false);


--
-- Name: app_auth_session app_auth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_auth_session
    ADD CONSTRAINT app_auth_session_pkey PRIMARY KEY (user_id);


--
-- Name: app_auth_session app_auth_session_token_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_auth_session
    ADD CONSTRAINT app_auth_session_token_id_key UNIQUE (token_id);


--
-- Name: app_user app_user_login_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_login_id_key UNIQUE (login_id);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (user_id);


--
-- Name: assessment_attempt assessment_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_attempt
    ADD CONSTRAINT assessment_attempt_pkey PRIMARY KEY (attempt_id);


--
-- Name: assessment_start assessment_start_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_pkey PRIMARY KEY (start_id);


--
-- Name: attendance_exclusion attendance_exclusion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_exclusion
    ADD CONSTRAINT attendance_exclusion_pkey PRIMARY KEY (exclusion_id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (attendance_id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (audit_id);


--
-- Name: batch_day_activity batch_day_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day_activity
    ADD CONSTRAINT batch_day_activity_pkey PRIMARY KEY (batch_activity_id);


--
-- Name: batch_day batch_day_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day
    ADD CONSTRAINT batch_day_pkey PRIMARY KEY (batch_day_id);


--
-- Name: batch_enrollment batch_enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT batch_enrollment_pkey PRIMARY KEY (enrollment_id);


--
-- Name: batch_registration_link batch_registration_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT batch_registration_link_pkey PRIMARY KEY (link_id);


--
-- Name: batch_registration_link batch_registration_link_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT batch_registration_link_token_key UNIQUE (token);


--
-- Name: bulk_upload_log bulk_upload_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT bulk_upload_log_pkey PRIMARY KEY (upload_id);


--
-- Name: certificate_record certificate_record_certificate_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT certificate_record_certificate_number_key UNIQUE (certificate_number);


--
-- Name: certificate_record certificate_record_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT certificate_record_pkey PRIMARY KEY (certificate_id);


--
-- Name: certificate_template certificate_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT certificate_template_pkey PRIMARY KEY (template_id);


--
-- Name: certificate_template certificate_template_template_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT certificate_template_template_code_key UNIQUE (template_code);


--
-- Name: completion_review completion_review_enrollment_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT completion_review_enrollment_id_key UNIQUE (enrollment_id);


--
-- Name: completion_review completion_review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT completion_review_pkey PRIMARY KEY (completion_id);


--
-- Name: consent_record consent_record_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_record
    ADD CONSTRAINT consent_record_pkey PRIMARY KEY (consent_id);


--
-- Name: data_subject_request data_subject_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_request
    ADD CONSTRAINT data_subject_request_pkey PRIMARY KEY (request_id);


--
-- Name: external_course_record external_course_record_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_course_record
    ADD CONSTRAINT external_course_record_pkey PRIMARY KEY (record_id);


--
-- Name: form_question form_question_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT form_question_pkey PRIMARY KEY (question_id);


--
-- Name: form_submission form_submission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submission
    ADD CONSTRAINT form_submission_pkey PRIMARY KEY (submission_id);


--
-- Name: learning_resource learning_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT learning_resource_pkey PRIMARY KEY (resource_id);


--
-- Name: learning_resource learning_resource_resource_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT learning_resource_resource_code_key UNIQUE (resource_code);


--
-- Name: m_block m_block_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT m_block_pkey PRIMARY KEY (block_id);


--
-- Name: m_cluster m_cluster_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT m_cluster_pkey PRIMARY KEY (cluster_id);


--
-- Name: m_district m_district_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT m_district_pkey PRIMARY KEY (district_id);


--
-- Name: m_holiday m_holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT m_holiday_pkey PRIMARY KEY (holiday_id);


--
-- Name: m_module m_module_module_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT m_module_module_code_key UNIQUE (module_code);


--
-- Name: m_module m_module_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT m_module_pkey PRIMARY KEY (module_id);


--
-- Name: m_pii_field m_pii_field_field_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT m_pii_field_field_code_key UNIQUE (field_code);


--
-- Name: m_pii_field m_pii_field_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT m_pii_field_pkey PRIMARY KEY (pii_field_id);


--
-- Name: m_role m_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT m_role_pkey PRIMARY KEY (role_id);


--
-- Name: m_role m_role_role_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT m_role_role_code_key UNIQUE (role_code);


--
-- Name: m_role m_role_role_rank_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT m_role_role_rank_key UNIQUE (role_rank);


--
-- Name: m_school m_school_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT m_school_pkey PRIMARY KEY (school_id);


--
-- Name: m_school m_school_udise_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT m_school_udise_code_key UNIQUE (udise_code);


--
-- Name: m_stakeholder m_stakeholder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT m_stakeholder_pkey PRIMARY KEY (stakeholder_id);


--
-- Name: m_stakeholder m_stakeholder_stakeholder_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT m_stakeholder_stakeholder_code_key UNIQUE (stakeholder_code);


--
-- Name: m_state m_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT m_state_pkey PRIMARY KEY (state_id);


--
-- Name: m_state m_state_state_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT m_state_state_code_key UNIQUE (state_code);


--
-- Name: m_state m_state_state_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT m_state_state_name_key UNIQUE (state_name);


--
-- Name: odoo_project_catalog odoo_project_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odoo_project_catalog
    ADD CONSTRAINT odoo_project_catalog_pkey PRIMARY KEY (catalog_id);


--
-- Name: odoo_project_catalog odoo_project_catalog_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odoo_project_catalog
    ADD CONSTRAINT odoo_project_catalog_reference_key UNIQUE (reference);


--
-- Name: pii_access_log pii_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pii_access_log
    ADD CONSTRAINT pii_access_log_pkey PRIMARY KEY (pii_access_id);


--
-- Name: plan_resource_day plan_resource_day_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_day
    ADD CONSTRAINT plan_resource_day_pkey PRIMARY KEY (link_day_id);


--
-- Name: plan_resource_link plan_resource_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT plan_resource_link_pkey PRIMARY KEY (link_id);


--
-- Name: portal_collection portal_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_collection
    ADD CONSTRAINT portal_collection_pkey PRIMARY KEY (collection_key);


--
-- Name: portal_otp_challenge portal_otp_challenge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_otp_challenge
    ADD CONSTRAINT portal_otp_challenge_pkey PRIMARY KEY (challenge_id);


--
-- Name: portal_recovery_request portal_recovery_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_recovery_request
    ADD CONSTRAINT portal_recovery_request_pkey PRIMARY KEY (request_id);


--
-- Name: portal_setting portal_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_setting
    ADD CONSTRAINT portal_setting_pkey PRIMARY KEY (portal_setting_id);


--
-- Name: profile_change_log profile_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_change_log
    ADD CONSTRAINT profile_change_log_pkey PRIMARY KEY (change_id);


--
-- Name: project_phase project_phase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase
    ADD CONSTRAINT project_phase_pkey PRIMARY KEY (phase_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (project_id);


--
-- Name: project_plan_association project_plan_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_pkey PRIMARY KEY (association_id);


--
-- Name: project_plan_association project_plan_association_project_id_plan_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_project_id_plan_id_key UNIQUE (project_id, plan_id);


--
-- Name: project project_project_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_project_code_key UNIQUE (project_code);


--
-- Name: registration_otp registration_otp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_otp
    ADD CONSTRAINT registration_otp_pkey PRIMARY KEY (otp_id);


--
-- Name: resource_access_log resource_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_access_log
    ADD CONSTRAINT resource_access_log_pkey PRIMARY KEY (access_id);


--
-- Name: resource_audience resource_audience_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT resource_audience_pkey PRIMARY KEY (audience_id);


--
-- Name: resource_progress resource_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_progress
    ADD CONSTRAINT resource_progress_pkey PRIMARY KEY (progress_id);


--
-- Name: role_creation_rule role_creation_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT role_creation_rule_pkey PRIMARY KEY (rule_id);


--
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (role_permission_id);


--
-- Name: role_pii_permission role_pii_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT role_pii_permission_pkey PRIMARY KEY (role_pii_id);


--
-- Name: school_eligibility school_eligibility_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_eligibility
    ADD CONSTRAINT school_eligibility_pkey PRIMARY KEY (eligibility_id);


--
-- Name: system_setting system_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT system_setting_pkey PRIMARY KEY (setting_id);


--
-- Name: system_setting system_setting_project_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT system_setting_project_id_key UNIQUE (project_id);


--
-- Name: teacher_auth_tokens teacher_auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_auth_tokens
    ADD CONSTRAINT teacher_auth_tokens_pkey PRIMARY KEY (teacher_id);


--
-- Name: teacher_auth_tokens teacher_auth_tokens_token_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_auth_tokens
    ADD CONSTRAINT teacher_auth_tokens_token_id_key UNIQUE (token_id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: trainee trainee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT trainee_pkey PRIMARY KEY (trainee_id);


--
-- Name: trainee trainee_trainee_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT trainee_trainee_code_key UNIQUE (trainee_code);


--
-- Name: trainer_availability trainer_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT trainer_availability_pkey PRIMARY KEY (availability_id);


--
-- Name: trainer trainer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT trainer_pkey PRIMARY KEY (trainer_id);


--
-- Name: trainer trainer_trainer_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT trainer_trainer_code_key UNIQUE (trainer_code);


--
-- Name: training_batch training_batch_batch_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT training_batch_batch_code_key UNIQUE (batch_code);


--
-- Name: training_batch training_batch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT training_batch_pkey PRIMARY KEY (batch_id);


--
-- Name: training_plan_activity training_plan_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT training_plan_activity_pkey PRIMARY KEY (activity_id);


--
-- Name: training_plan_day training_plan_day_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT training_plan_day_pkey PRIMARY KEY (plan_day_id);


--
-- Name: training_plan training_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT training_plan_pkey PRIMARY KEY (plan_id);


--
-- Name: training_plan training_plan_plan_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT training_plan_plan_code_key UNIQUE (plan_code);


--
-- Name: user_access_scope user_access_scope_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT user_access_scope_pkey PRIMARY KEY (scope_id);


--
-- Name: user_activity_log user_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_pkey PRIMARY KEY (activity_id);


--
-- Name: user_pii_override user_pii_override_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT user_pii_override_pkey PRIMARY KEY (override_id);


--
-- Name: ix_app_user_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_created_by ON public.app_user USING btree (created_by);


--
-- Name: ix_app_user_parent_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_parent_user_id ON public.app_user USING btree (parent_user_id);


--
-- Name: ix_app_user_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_role_id ON public.app_user USING btree (role_id);


--
-- Name: ix_app_user_stakeholder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_stakeholder_id ON public.app_user USING btree (stakeholder_id);


--
-- Name: ix_app_user_trainee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_trainee_id ON public.app_user USING btree (trainee_id);


--
-- Name: ix_app_user_trainer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_trainer_id ON public.app_user USING btree (trainer_id);


--
-- Name: ix_app_user_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_user_updated_by ON public.app_user USING btree (updated_by);


--
-- Name: ix_attendance_enrollment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_enrollment_id ON public.attendance USING btree (enrollment_id);


--
-- Name: ix_attendance_marked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_marked_by ON public.attendance USING btree (marked_by);


--
-- Name: ix_attendance_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_updated_by ON public.attendance USING btree (updated_by);


--
-- Name: ix_audit_log_actor_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_actor_user_id ON public.audit_log USING btree (actor_user_id);


--
-- Name: ix_audit_log_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_project_id ON public.audit_log USING btree (project_id);


--
-- Name: ix_batch_day_activity_batch_day_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_day_activity_batch_day_id ON public.batch_day_activity USING btree (batch_day_id);


--
-- Name: ix_batch_day_activity_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_day_activity_resource_id ON public.batch_day_activity USING btree (resource_id);


--
-- Name: ix_batch_day_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_day_batch_id ON public.batch_day USING btree (batch_id);


--
-- Name: ix_batch_enrollment_approved_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_approved_by ON public.batch_enrollment USING btree (approved_by);


--
-- Name: ix_batch_enrollment_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_batch_id ON public.batch_enrollment USING btree (batch_id);


--
-- Name: ix_batch_enrollment_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_created_by ON public.batch_enrollment USING btree (created_by);


--
-- Name: ix_batch_enrollment_registration_link_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_registration_link_id ON public.batch_enrollment USING btree (registration_link_id);


--
-- Name: ix_batch_enrollment_trainee_block_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_trainee_block_id ON public.batch_enrollment USING btree (trainee_block_id);


--
-- Name: ix_batch_enrollment_trainee_cluster_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_trainee_cluster_id ON public.batch_enrollment USING btree (trainee_cluster_id);


--
-- Name: ix_batch_enrollment_trainee_district_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_trainee_district_id ON public.batch_enrollment USING btree (trainee_district_id);


--
-- Name: ix_batch_enrollment_trainee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_trainee_id ON public.batch_enrollment USING btree (trainee_id);


--
-- Name: ix_batch_enrollment_trainee_school_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_trainee_school_id ON public.batch_enrollment USING btree (trainee_school_id);


--
-- Name: ix_batch_enrollment_trainee_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_trainee_state_id ON public.batch_enrollment USING btree (trainee_state_id);


--
-- Name: ix_batch_enrollment_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_enrollment_updated_by ON public.batch_enrollment USING btree (updated_by);


--
-- Name: ix_batch_registration_link_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_registration_link_batch_id ON public.batch_registration_link USING btree (batch_id);


--
-- Name: ix_batch_registration_link_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_registration_link_created_by ON public.batch_registration_link USING btree (created_by);


--
-- Name: ix_batch_registration_link_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_batch_registration_link_updated_by ON public.batch_registration_link USING btree (updated_by);


--
-- Name: ix_bulk_upload_log_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bulk_upload_log_batch_id ON public.bulk_upload_log USING btree (batch_id);


--
-- Name: ix_bulk_upload_log_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bulk_upload_log_project_id ON public.bulk_upload_log USING btree (project_id);


--
-- Name: ix_bulk_upload_log_uploaded_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bulk_upload_log_uploaded_by ON public.bulk_upload_log USING btree (uploaded_by);


--
-- Name: ix_certificate_record_enrollment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_certificate_record_enrollment_id ON public.certificate_record USING btree (enrollment_id);


--
-- Name: ix_certificate_record_issued_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_certificate_record_issued_by ON public.certificate_record USING btree (issued_by);


--
-- Name: ix_certificate_record_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_certificate_record_template_id ON public.certificate_record USING btree (template_id);


--
-- Name: ix_certificate_template_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_certificate_template_created_by ON public.certificate_template USING btree (created_by);


--
-- Name: ix_certificate_template_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_certificate_template_project_id ON public.certificate_template USING btree (project_id);


--
-- Name: ix_certificate_template_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_certificate_template_updated_by ON public.certificate_template USING btree (updated_by);


--
-- Name: ix_completion_review_enrollment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_completion_review_enrollment_id ON public.completion_review USING btree (enrollment_id);


--
-- Name: ix_completion_review_reviewed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_completion_review_reviewed_by ON public.completion_review USING btree (reviewed_by);


--
-- Name: ix_consent_record_trainee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consent_record_trainee_id ON public.consent_record USING btree (trainee_id);


--
-- Name: ix_data_subject_request_handled_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_data_subject_request_handled_by ON public.data_subject_request USING btree (handled_by);


--
-- Name: ix_data_subject_request_trainee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_data_subject_request_trainee_id ON public.data_subject_request USING btree (trainee_id);


--
-- Name: ix_form_question_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_form_question_created_by ON public.form_question USING btree (created_by);


--
-- Name: ix_form_question_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_form_question_resource_id ON public.form_question USING btree (resource_id);


--
-- Name: ix_form_question_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_form_question_updated_by ON public.form_question USING btree (updated_by);


--
-- Name: ix_form_submission_enrollment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_form_submission_enrollment_id ON public.form_submission USING btree (enrollment_id);


--
-- Name: ix_form_submission_question_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_form_submission_question_id ON public.form_submission USING btree (question_id);


--
-- Name: ix_learning_resource_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_learning_resource_created_by ON public.learning_resource USING btree (created_by);


--
-- Name: ix_learning_resource_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_learning_resource_project_id ON public.learning_resource USING btree (project_id);


--
-- Name: ix_learning_resource_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_learning_resource_updated_by ON public.learning_resource USING btree (updated_by);


--
-- Name: ix_learning_resource_uploaded_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_learning_resource_uploaded_by ON public.learning_resource USING btree (uploaded_by);


--
-- Name: ix_m_block_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_block_created_by ON public.m_block USING btree (created_by);


--
-- Name: ix_m_block_district_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_block_district_id ON public.m_block USING btree (district_id);


--
-- Name: ix_m_block_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_block_updated_by ON public.m_block USING btree (updated_by);


--
-- Name: ix_m_cluster_block_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_cluster_block_id ON public.m_cluster USING btree (block_id);


--
-- Name: ix_m_cluster_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_cluster_created_by ON public.m_cluster USING btree (created_by);


--
-- Name: ix_m_cluster_district_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_cluster_district_id ON public.m_cluster USING btree (district_id);


--
-- Name: ix_m_cluster_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_cluster_updated_by ON public.m_cluster USING btree (updated_by);


--
-- Name: ix_m_district_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_district_created_by ON public.m_district USING btree (created_by);


--
-- Name: ix_m_district_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_district_state_id ON public.m_district USING btree (state_id);


--
-- Name: ix_m_district_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_district_updated_by ON public.m_district USING btree (updated_by);


--
-- Name: ix_m_holiday_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_holiday_created_by ON public.m_holiday USING btree (created_by);


--
-- Name: ix_m_holiday_district_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_holiday_district_id ON public.m_holiday USING btree (district_id);


--
-- Name: ix_m_holiday_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_holiday_project_id ON public.m_holiday USING btree (project_id);


--
-- Name: ix_m_holiday_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_holiday_state_id ON public.m_holiday USING btree (state_id);


--
-- Name: ix_m_holiday_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_holiday_updated_by ON public.m_holiday USING btree (updated_by);


--
-- Name: ix_m_module_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_module_created_by ON public.m_module USING btree (created_by);


--
-- Name: ix_m_module_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_module_updated_by ON public.m_module USING btree (updated_by);


--
-- Name: ix_m_pii_field_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_pii_field_created_by ON public.m_pii_field USING btree (created_by);


--
-- Name: ix_m_pii_field_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_pii_field_updated_by ON public.m_pii_field USING btree (updated_by);


--
-- Name: ix_m_role_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_role_created_by ON public.m_role USING btree (created_by);


--
-- Name: ix_m_role_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_role_updated_by ON public.m_role USING btree (updated_by);


--
-- Name: ix_m_school_block_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_school_block_id ON public.m_school USING btree (block_id);


--
-- Name: ix_m_school_cluster_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_school_cluster_id ON public.m_school USING btree (cluster_id);


--
-- Name: ix_m_school_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_school_created_by ON public.m_school USING btree (created_by);


--
-- Name: ix_m_school_district_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_school_district_id ON public.m_school USING btree (district_id);


--
-- Name: ix_m_school_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_school_state_id ON public.m_school USING btree (state_id);


--
-- Name: ix_m_school_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_school_updated_by ON public.m_school USING btree (updated_by);


--
-- Name: ix_m_stakeholder_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_stakeholder_created_by ON public.m_stakeholder USING btree (created_by);


--
-- Name: ix_m_stakeholder_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_stakeholder_updated_by ON public.m_stakeholder USING btree (updated_by);


--
-- Name: ix_m_state_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_state_created_by ON public.m_state USING btree (created_by);


--
-- Name: ix_m_state_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_m_state_updated_by ON public.m_state USING btree (updated_by);


--
-- Name: ix_pii_access_log_pii_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pii_access_log_pii_field_id ON public.pii_access_log USING btree (pii_field_id);


--
-- Name: ix_pii_access_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pii_access_log_user_id ON public.pii_access_log USING btree (user_id);


--
-- Name: ix_plan_resource_day_link_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plan_resource_day_link_id ON public.plan_resource_day USING btree (link_id);


--
-- Name: ix_plan_resource_link_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plan_resource_link_created_by ON public.plan_resource_link USING btree (created_by);


--
-- Name: ix_plan_resource_link_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plan_resource_link_plan_id ON public.plan_resource_link USING btree (plan_id);


--
-- Name: ix_plan_resource_link_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plan_resource_link_project_id ON public.plan_resource_link USING btree (project_id);


--
-- Name: ix_plan_resource_link_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plan_resource_link_resource_id ON public.plan_resource_link USING btree (resource_id);


--
-- Name: ix_plan_resource_link_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plan_resource_link_updated_by ON public.plan_resource_link USING btree (updated_by);


--
-- Name: ix_portal_app_user_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_app_user_scope ON public.app_user USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_assessment_attempt_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_assessment_attempt_scope ON public.assessment_attempt USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_assessment_start_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_assessment_start_scope ON public.assessment_start USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_attendance_exclusion_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_attendance_exclusion_scope ON public.attendance_exclusion USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_attendance_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_attendance_scope ON public.attendance USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_audit_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_audit_log_scope ON public.audit_log USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_batch_day_activity_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_batch_day_activity_scope ON public.batch_day_activity USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_batch_day_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_batch_day_scope ON public.batch_day USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_batch_enrollment_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_batch_enrollment_scope ON public.batch_enrollment USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_batch_registration_link_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_batch_registration_link_scope ON public.batch_registration_link USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_bulk_upload_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_bulk_upload_log_scope ON public.bulk_upload_log USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_certificate_record_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_certificate_record_scope ON public.certificate_record USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_certificate_template_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_certificate_template_scope ON public.certificate_template USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_completion_review_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_completion_review_scope ON public.completion_review USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_consent_record_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_consent_record_scope ON public.consent_record USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_data_subject_request_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_data_subject_request_scope ON public.data_subject_request USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_external_course_record_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_external_course_record_scope ON public.external_course_record USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_form_question_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_form_question_scope ON public.form_question USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_form_submission_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_form_submission_scope ON public.form_submission USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_learning_resource_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_learning_resource_scope ON public.learning_resource USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_block_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_block_scope ON public.m_block USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_cluster_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_cluster_scope ON public.m_cluster USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_district_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_district_scope ON public.m_district USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_holiday_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_holiday_scope ON public.m_holiday USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_module_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_module_scope ON public.m_module USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_pii_field_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_pii_field_scope ON public.m_pii_field USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_role_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_role_scope ON public.m_role USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_school_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_school_scope ON public.m_school USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_stakeholder_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_stakeholder_scope ON public.m_stakeholder USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_m_state_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_m_state_scope ON public.m_state USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_odoo_project_catalog_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_odoo_project_catalog_scope ON public.odoo_project_catalog USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_otp_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_otp_recipient ON public.portal_otp_challenge USING btree (recipient_hash, created_at);


--
-- Name: ix_portal_pii_access_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_pii_access_log_scope ON public.pii_access_log USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_plan_resource_day_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_plan_resource_day_scope ON public.plan_resource_day USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_plan_resource_link_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_plan_resource_link_scope ON public.plan_resource_link USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_portal_otp_challenge_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_portal_otp_challenge_scope ON public.portal_otp_challenge USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_portal_recovery_request_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_portal_recovery_request_scope ON public.portal_recovery_request USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_portal_setting_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_portal_setting_scope ON public.portal_setting USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_profile_change_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_profile_change_log_scope ON public.profile_change_log USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_project_phase_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_project_phase_scope ON public.project_phase USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_project_plan_association_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_project_plan_association_scope ON public.project_plan_association USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_project_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_project_scope ON public.project USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_registration_otp_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_registration_otp_scope ON public.registration_otp USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_resource_access_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_resource_access_log_scope ON public.resource_access_log USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_resource_audience_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_resource_audience_scope ON public.resource_audience USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_resource_progress_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_resource_progress_scope ON public.resource_progress USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_role_creation_rule_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_role_creation_rule_scope ON public.role_creation_rule USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_role_permission_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_role_permission_scope ON public.role_permission USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_role_pii_permission_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_role_pii_permission_scope ON public.role_pii_permission USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_school_eligibility_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_school_eligibility_scope ON public.school_eligibility USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_session_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_session_expiry ON public.app_auth_session USING btree (expires_at);


--
-- Name: ix_portal_system_setting_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_system_setting_scope ON public.system_setting USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_trainee_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_trainee_scope ON public.trainee USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_trainer_availability_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_trainer_availability_scope ON public.trainer_availability USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_trainer_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_trainer_scope ON public.trainer USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_training_batch_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_training_batch_scope ON public.training_batch USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_training_plan_activity_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_training_plan_activity_scope ON public.training_plan_activity USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_training_plan_day_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_training_plan_day_scope ON public.training_plan_day USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_training_plan_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_training_plan_scope ON public.training_plan USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_user_access_scope_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_user_access_scope_scope ON public.user_access_scope USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_user_activity_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_user_activity_log_scope ON public.user_activity_log USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_portal_user_pii_override_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portal_user_pii_override_scope ON public.user_pii_override USING btree (portal_project_id, portal_collection) WHERE (NOT portal_deleted);


--
-- Name: ix_profile_change_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_profile_change_log_user_id ON public.profile_change_log USING btree (user_id);


--
-- Name: ix_project_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_created_by ON public.project USING btree (created_by);


--
-- Name: ix_project_stakeholder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_stakeholder_id ON public.project USING btree (stakeholder_id);


--
-- Name: ix_project_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_updated_by ON public.project USING btree (updated_by);


--
-- Name: ix_registration_otp_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_registration_otp_batch_id ON public.registration_otp USING btree (batch_id);


--
-- Name: ix_resource_access_log_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_access_log_resource_id ON public.resource_access_log USING btree (resource_id);


--
-- Name: ix_resource_access_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_access_log_user_id ON public.resource_access_log USING btree (user_id);


--
-- Name: ix_resource_audience_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_audience_batch_id ON public.resource_audience USING btree (batch_id);


--
-- Name: ix_resource_audience_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_audience_created_by ON public.resource_audience USING btree (created_by);


--
-- Name: ix_resource_audience_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_audience_resource_id ON public.resource_audience USING btree (resource_id);


--
-- Name: ix_resource_audience_trainee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_audience_trainee_id ON public.resource_audience USING btree (trainee_id);


--
-- Name: ix_resource_audience_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_audience_updated_by ON public.resource_audience USING btree (updated_by);


--
-- Name: ix_resource_progress_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_progress_resource_id ON public.resource_progress USING btree (resource_id);


--
-- Name: ix_resource_progress_trainee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_progress_trainee_id ON public.resource_progress USING btree (trainee_id);


--
-- Name: ix_role_creation_rule_creatable_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_creation_rule_creatable_role_id ON public.role_creation_rule USING btree (creatable_role_id);


--
-- Name: ix_role_creation_rule_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_creation_rule_created_by ON public.role_creation_rule USING btree (created_by);


--
-- Name: ix_role_creation_rule_creator_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_creation_rule_creator_role_id ON public.role_creation_rule USING btree (creator_role_id);


--
-- Name: ix_role_creation_rule_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_creation_rule_updated_by ON public.role_creation_rule USING btree (updated_by);


--
-- Name: ix_role_permission_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_permission_created_by ON public.role_permission USING btree (created_by);


--
-- Name: ix_role_permission_module_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_permission_module_id ON public.role_permission USING btree (module_id);


--
-- Name: ix_role_permission_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_permission_role_id ON public.role_permission USING btree (role_id);


--
-- Name: ix_role_permission_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_permission_updated_by ON public.role_permission USING btree (updated_by);


--
-- Name: ix_role_pii_permission_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_pii_permission_created_by ON public.role_pii_permission USING btree (created_by);


--
-- Name: ix_role_pii_permission_pii_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_pii_permission_pii_field_id ON public.role_pii_permission USING btree (pii_field_id);


--
-- Name: ix_role_pii_permission_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_pii_permission_role_id ON public.role_pii_permission USING btree (role_id);


--
-- Name: ix_role_pii_permission_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_role_pii_permission_updated_by ON public.role_pii_permission USING btree (updated_by);


--
-- Name: ix_system_setting_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_setting_created_by ON public.system_setting USING btree (created_by);


--
-- Name: ix_system_setting_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_setting_project_id ON public.system_setting USING btree (project_id);


--
-- Name: ix_system_setting_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_setting_updated_by ON public.system_setting USING btree (updated_by);


--
-- Name: ix_trainee_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainee_created_by ON public.trainee USING btree (created_by);


--
-- Name: ix_trainee_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainee_updated_by ON public.trainee USING btree (updated_by);


--
-- Name: ix_trainer_availability_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_availability_created_by ON public.trainer_availability USING btree (created_by);


--
-- Name: ix_trainer_availability_trainer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_availability_trainer_id ON public.trainer_availability USING btree (trainer_id);


--
-- Name: ix_trainer_availability_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_availability_updated_by ON public.trainer_availability USING btree (updated_by);


--
-- Name: ix_trainer_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_created_by ON public.trainer USING btree (created_by);


--
-- Name: ix_trainer_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_updated_by ON public.trainer USING btree (updated_by);


--
-- Name: ix_training_batch_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_batch_created_by ON public.training_batch USING btree (created_by);


--
-- Name: ix_training_batch_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_batch_plan_id ON public.training_batch USING btree (plan_id);


--
-- Name: ix_training_batch_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_batch_project_id ON public.training_batch USING btree (project_id);


--
-- Name: ix_training_batch_school_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_batch_school_id ON public.training_batch USING btree (school_id);


--
-- Name: ix_training_batch_trainer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_batch_trainer_id ON public.training_batch USING btree (trainer_id);


--
-- Name: ix_training_batch_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_batch_updated_by ON public.training_batch USING btree (updated_by);


--
-- Name: ix_training_plan_activity_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_activity_created_by ON public.training_plan_activity USING btree (created_by);


--
-- Name: ix_training_plan_activity_plan_day_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_activity_plan_day_id ON public.training_plan_activity USING btree (plan_day_id);


--
-- Name: ix_training_plan_activity_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_activity_resource_id ON public.training_plan_activity USING btree (resource_id);


--
-- Name: ix_training_plan_activity_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_activity_updated_by ON public.training_plan_activity USING btree (updated_by);


--
-- Name: ix_training_plan_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_created_by ON public.training_plan USING btree (created_by);


--
-- Name: ix_training_plan_day_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_day_created_by ON public.training_plan_day USING btree (created_by);


--
-- Name: ix_training_plan_day_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_day_plan_id ON public.training_plan_day USING btree (plan_id);


--
-- Name: ix_training_plan_day_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_day_updated_by ON public.training_plan_day USING btree (updated_by);


--
-- Name: ix_training_plan_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_project_id ON public.training_plan USING btree (project_id);


--
-- Name: ix_training_plan_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_training_plan_updated_by ON public.training_plan USING btree (updated_by);


--
-- Name: ix_user_access_scope_block_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_block_id ON public.user_access_scope USING btree (block_id);


--
-- Name: ix_user_access_scope_cluster_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_cluster_id ON public.user_access_scope USING btree (cluster_id);


--
-- Name: ix_user_access_scope_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_created_by ON public.user_access_scope USING btree (created_by);


--
-- Name: ix_user_access_scope_district_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_district_id ON public.user_access_scope USING btree (district_id);


--
-- Name: ix_user_access_scope_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_project_id ON public.user_access_scope USING btree (project_id);


--
-- Name: ix_user_access_scope_school_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_school_id ON public.user_access_scope USING btree (school_id);


--
-- Name: ix_user_access_scope_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_state_id ON public.user_access_scope USING btree (state_id);


--
-- Name: ix_user_access_scope_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_updated_by ON public.user_access_scope USING btree (updated_by);


--
-- Name: ix_user_access_scope_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_access_scope_user_id ON public.user_access_scope USING btree (user_id);


--
-- Name: ix_user_activity_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_activity_log_user_id ON public.user_activity_log USING btree (user_id);


--
-- Name: ix_user_pii_override_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_pii_override_created_by ON public.user_pii_override USING btree (created_by);


--
-- Name: ix_user_pii_override_pii_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_pii_override_pii_field_id ON public.user_pii_override USING btree (pii_field_id);


--
-- Name: ix_user_pii_override_updated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_pii_override_updated_by ON public.user_pii_override USING btree (updated_by);


--
-- Name: ix_user_pii_override_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_pii_override_user_id ON public.user_pii_override USING btree (user_id);


--
-- Name: ux_attendance_enrollment_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_attendance_enrollment_date ON public.attendance USING btree (enrollment_id, attendance_date);


--
-- Name: ux_batch_day_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_batch_day_number ON public.batch_day USING btree (batch_id, day_no);


--
-- Name: ux_current_certificate; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_current_certificate ON public.certificate_record USING btree (enrollment_id) WHERE ((NOT portal_deleted) AND (COALESCE((ui_data ->> 'status'::text), 'Issued'::text) <> ALL (ARRAY['Superseded'::text, 'Reissued'::text, 'Revoked'::text])));


--
-- Name: ux_enrollment_batch_trainee; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_enrollment_batch_trainee ON public.batch_enrollment USING btree (batch_id, trainee_id);


--
-- Name: ux_plan_day_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_plan_day_number ON public.training_plan_day USING btree (plan_id, day_no);


--
-- Name: ux_portal_app_user_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_app_user_external ON public.app_user USING btree (external_id);


--
-- Name: ux_portal_assessment_attempt_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_assessment_attempt_external ON public.assessment_attempt USING btree (external_id);


--
-- Name: ux_portal_assessment_start_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_assessment_start_external ON public.assessment_start USING btree (external_id);


--
-- Name: ux_portal_attendance_exclusion_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_attendance_exclusion_external ON public.attendance_exclusion USING btree (external_id);


--
-- Name: ux_portal_attendance_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_attendance_external ON public.attendance USING btree (external_id);


--
-- Name: ux_portal_audit_log_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_audit_log_external ON public.audit_log USING btree (external_id);


--
-- Name: ux_portal_batch_day_activity_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_batch_day_activity_external ON public.batch_day_activity USING btree (external_id);


--
-- Name: ux_portal_batch_day_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_batch_day_external ON public.batch_day USING btree (external_id);


--
-- Name: ux_portal_batch_enrollment_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_batch_enrollment_external ON public.batch_enrollment USING btree (external_id);


--
-- Name: ux_portal_batch_registration_link_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_batch_registration_link_external ON public.batch_registration_link USING btree (external_id);


--
-- Name: ux_portal_bulk_upload_log_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_bulk_upload_log_external ON public.bulk_upload_log USING btree (external_id);


--
-- Name: ux_portal_certificate_record_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_certificate_record_external ON public.certificate_record USING btree (external_id);


--
-- Name: ux_portal_certificate_template_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_certificate_template_external ON public.certificate_template USING btree (external_id);


--
-- Name: ux_portal_completion_review_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_completion_review_external ON public.completion_review USING btree (external_id);


--
-- Name: ux_portal_consent_record_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_consent_record_external ON public.consent_record USING btree (external_id);


--
-- Name: ux_portal_data_subject_request_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_data_subject_request_external ON public.data_subject_request USING btree (external_id);


--
-- Name: ux_portal_external_course_record_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_external_course_record_external ON public.external_course_record USING btree (external_id);


--
-- Name: ux_portal_form_question_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_form_question_external ON public.form_question USING btree (external_id);


--
-- Name: ux_portal_form_submission_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_form_submission_external ON public.form_submission USING btree (external_id);


--
-- Name: ux_portal_learning_resource_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_learning_resource_external ON public.learning_resource USING btree (external_id);


--
-- Name: ux_portal_m_block_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_block_external ON public.m_block USING btree (external_id);


--
-- Name: ux_portal_m_cluster_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_cluster_external ON public.m_cluster USING btree (external_id);


--
-- Name: ux_portal_m_district_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_district_external ON public.m_district USING btree (external_id);


--
-- Name: ux_portal_m_holiday_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_holiday_external ON public.m_holiday USING btree (external_id);


--
-- Name: ux_portal_m_module_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_module_external ON public.m_module USING btree (external_id);


--
-- Name: ux_portal_m_pii_field_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_pii_field_external ON public.m_pii_field USING btree (external_id);


--
-- Name: ux_portal_m_role_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_role_external ON public.m_role USING btree (external_id);


--
-- Name: ux_portal_m_school_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_school_external ON public.m_school USING btree (external_id);


--
-- Name: ux_portal_m_stakeholder_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_stakeholder_external ON public.m_stakeholder USING btree (external_id);


--
-- Name: ux_portal_m_state_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_m_state_external ON public.m_state USING btree (external_id);


--
-- Name: ux_portal_odoo_project_catalog_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_odoo_project_catalog_external ON public.odoo_project_catalog USING btree (external_id);


--
-- Name: ux_portal_pii_access_log_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_pii_access_log_external ON public.pii_access_log USING btree (external_id);


--
-- Name: ux_portal_plan_resource_day_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_plan_resource_day_external ON public.plan_resource_day USING btree (external_id);


--
-- Name: ux_portal_plan_resource_link_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_plan_resource_link_external ON public.plan_resource_link USING btree (external_id);


--
-- Name: ux_portal_portal_otp_challenge_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_portal_otp_challenge_external ON public.portal_otp_challenge USING btree (external_id);


--
-- Name: ux_portal_portal_recovery_request_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_portal_recovery_request_external ON public.portal_recovery_request USING btree (external_id);


--
-- Name: ux_portal_portal_setting_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_portal_setting_external ON public.portal_setting USING btree (external_id);


--
-- Name: ux_portal_profile_change_log_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_profile_change_log_external ON public.profile_change_log USING btree (external_id);


--
-- Name: ux_portal_project_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_project_external ON public.project USING btree (external_id);


--
-- Name: ux_portal_project_phase_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_project_phase_external ON public.project_phase USING btree (external_id);


--
-- Name: ux_portal_project_plan_association_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_project_plan_association_external ON public.project_plan_association USING btree (external_id);


--
-- Name: ux_portal_registration_otp_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_registration_otp_external ON public.registration_otp USING btree (external_id);


--
-- Name: ux_portal_resource_access_log_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_resource_access_log_external ON public.resource_access_log USING btree (external_id);


--
-- Name: ux_portal_resource_audience_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_resource_audience_external ON public.resource_audience USING btree (external_id);


--
-- Name: ux_portal_resource_progress_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_resource_progress_external ON public.resource_progress USING btree (external_id);


--
-- Name: ux_portal_role_creation_rule_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_role_creation_rule_external ON public.role_creation_rule USING btree (external_id);


--
-- Name: ux_portal_role_permission_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_role_permission_external ON public.role_permission USING btree (external_id);


--
-- Name: ux_portal_role_pii_permission_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_role_pii_permission_external ON public.role_pii_permission USING btree (external_id);


--
-- Name: ux_portal_school_eligibility_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_school_eligibility_external ON public.school_eligibility USING btree (external_id);


--
-- Name: ux_portal_system_setting_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_system_setting_external ON public.system_setting USING btree (external_id);


--
-- Name: ux_portal_trainee_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_trainee_external ON public.trainee USING btree (external_id);


--
-- Name: ux_portal_trainer_availability_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_trainer_availability_external ON public.trainer_availability USING btree (external_id);


--
-- Name: ux_portal_trainer_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_trainer_external ON public.trainer USING btree (external_id);


--
-- Name: ux_portal_training_batch_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_training_batch_external ON public.training_batch USING btree (external_id);


--
-- Name: ux_portal_training_plan_activity_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_training_plan_activity_external ON public.training_plan_activity USING btree (external_id);


--
-- Name: ux_portal_training_plan_day_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_training_plan_day_external ON public.training_plan_day USING btree (external_id);


--
-- Name: ux_portal_training_plan_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_training_plan_external ON public.training_plan USING btree (external_id);


--
-- Name: ux_portal_user_access_scope_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_user_access_scope_external ON public.user_access_scope USING btree (external_id);


--
-- Name: ux_portal_user_activity_log_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_user_activity_log_external ON public.user_activity_log USING btree (external_id);


--
-- Name: ux_portal_user_pii_override_external; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_portal_user_pii_override_external ON public.user_pii_override USING btree (external_id);


--
-- Name: ux_teachers_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_teachers_email ON public.teachers USING btree (lower((email)::text));


--
-- Name: ux_trainee_email_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_trainee_email_hash ON public.trainee USING btree (email_hash) WHERE (email_hash IS NOT NULL);


--
-- Name: ux_trainee_mobile_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_trainee_mobile_hash ON public.trainee USING btree (mobile_hash) WHERE (mobile_hash IS NOT NULL);


--
-- Name: v_project_status _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.v_project_status AS
 SELECT p.project_id,
    p.project_code,
    p.project_name,
    p.start_date,
    p.end_date,
        CASE
            WHEN (CURRENT_DATE < p.start_date) THEN 'Upcoming'::text
            WHEN (CURRENT_DATE > p.end_date) THEN 'Completed'::text
            ELSE 'Ongoing'::text
        END AS project_status,
    count(b.batch_id) AS batch_count
   FROM (public.project p
     LEFT JOIN public.training_batch b ON (((b.project_id = p.project_id) AND (NOT b.portal_deleted))))
  WHERE (NOT p.portal_deleted)
  GROUP BY p.project_id;


--
-- Name: app_user trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.app_user FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: attendance trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.attendance FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: batch_enrollment trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.batch_enrollment FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: batch_registration_link trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.batch_registration_link FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: certificate_template trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.certificate_template FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: form_question trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.form_question FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: learning_resource trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.learning_resource FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_block trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_block FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_cluster trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_cluster FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_district trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_district FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_holiday trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_holiday FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_module trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_module FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_pii_field trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_pii_field FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_role trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_role FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_school trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_school FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_stakeholder trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_stakeholder FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: m_state trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.m_state FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: plan_resource_link trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.plan_resource_link FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: project trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.project FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: resource_audience trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.resource_audience FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: role_creation_rule trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.role_creation_rule FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: role_permission trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.role_permission FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: role_pii_permission trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.role_pii_permission FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: system_setting trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.system_setting FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: teachers trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.teachers FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: trainee trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.trainee FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: trainer trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.trainer FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: trainer_availability trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.trainer_availability FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: training_batch trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.training_batch FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: training_plan trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.training_plan FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: training_plan_activity trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.training_plan_activity FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: training_plan_day trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.training_plan_day FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: user_access_scope trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.user_access_scope FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: user_pii_override trg_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_updated_at BEFORE UPDATE ON public.user_pii_override FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: assessment_attempt trg_validate_assessment_attempt; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_validate_assessment_attempt BEFORE INSERT ON public.assessment_attempt FOR EACH ROW EXECUTE FUNCTION public.trg_validate_assessment_attempt();


--
-- Name: app_auth_session app_auth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_auth_session
    ADD CONSTRAINT app_auth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: app_user app_user_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: app_user app_user_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: app_user app_user_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: assessment_attempt assessment_attempt_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_attempt
    ADD CONSTRAINT assessment_attempt_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: assessment_attempt assessment_attempt_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_attempt
    ADD CONSTRAINT assessment_attempt_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: assessment_attempt assessment_attempt_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_attempt
    ADD CONSTRAINT assessment_attempt_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: assessment_attempt assessment_attempt_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_attempt
    ADD CONSTRAINT assessment_attempt_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: assessment_attempt assessment_attempt_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_attempt
    ADD CONSTRAINT assessment_attempt_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: assessment_start assessment_start_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: assessment_start assessment_start_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: assessment_start assessment_start_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: assessment_start assessment_start_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: assessment_start assessment_start_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: assessment_start assessment_start_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessment_start
    ADD CONSTRAINT assessment_start_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: attendance_exclusion attendance_exclusion_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_exclusion
    ADD CONSTRAINT attendance_exclusion_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.app_user(user_id);


--
-- Name: attendance_exclusion attendance_exclusion_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_exclusion
    ADD CONSTRAINT attendance_exclusion_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: attendance_exclusion attendance_exclusion_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_exclusion
    ADD CONSTRAINT attendance_exclusion_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: attendance_exclusion attendance_exclusion_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_exclusion
    ADD CONSTRAINT attendance_exclusion_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: attendance_exclusion attendance_exclusion_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_exclusion
    ADD CONSTRAINT attendance_exclusion_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: attendance attendance_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: attendance attendance_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: attendance attendance_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: audit_log audit_log_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: audit_log audit_log_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: audit_log audit_log_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: batch_day_activity batch_day_activity_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day_activity
    ADD CONSTRAINT batch_day_activity_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_day_activity batch_day_activity_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day_activity
    ADD CONSTRAINT batch_day_activity_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: batch_day_activity batch_day_activity_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day_activity
    ADD CONSTRAINT batch_day_activity_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: batch_day batch_day_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day
    ADD CONSTRAINT batch_day_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_day batch_day_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day
    ADD CONSTRAINT batch_day_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: batch_day batch_day_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day
    ADD CONSTRAINT batch_day_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: batch_enrollment batch_enrollment_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT batch_enrollment_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_enrollment batch_enrollment_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT batch_enrollment_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: batch_enrollment batch_enrollment_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT batch_enrollment_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: batch_registration_link batch_registration_link_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT batch_registration_link_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_registration_link batch_registration_link_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT batch_registration_link_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: batch_registration_link batch_registration_link_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT batch_registration_link_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: bulk_upload_log bulk_upload_log_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT bulk_upload_log_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: bulk_upload_log bulk_upload_log_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT bulk_upload_log_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: bulk_upload_log bulk_upload_log_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT bulk_upload_log_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: certificate_record certificate_record_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT certificate_record_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: certificate_record certificate_record_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT certificate_record_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: certificate_record certificate_record_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT certificate_record_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: certificate_template certificate_template_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT certificate_template_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: certificate_template certificate_template_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT certificate_template_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: certificate_template certificate_template_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT certificate_template_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: completion_review completion_review_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT completion_review_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: completion_review completion_review_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT completion_review_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: completion_review completion_review_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT completion_review_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: consent_record consent_record_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_record
    ADD CONSTRAINT consent_record_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: consent_record consent_record_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_record
    ADD CONSTRAINT consent_record_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: consent_record consent_record_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_record
    ADD CONSTRAINT consent_record_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: data_subject_request data_subject_request_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_request
    ADD CONSTRAINT data_subject_request_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: data_subject_request data_subject_request_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_request
    ADD CONSTRAINT data_subject_request_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: data_subject_request data_subject_request_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_request
    ADD CONSTRAINT data_subject_request_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: external_course_record external_course_record_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_course_record
    ADD CONSTRAINT external_course_record_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: external_course_record external_course_record_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_course_record
    ADD CONSTRAINT external_course_record_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: external_course_record external_course_record_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_course_record
    ADD CONSTRAINT external_course_record_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: external_course_record external_course_record_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_course_record
    ADD CONSTRAINT external_course_record_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: app_user fk_app_user_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: app_user fk_app_user_parent_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_parent_user_id FOREIGN KEY (parent_user_id) REFERENCES public.app_user(user_id);


--
-- Name: app_user fk_app_user_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_role_id FOREIGN KEY (role_id) REFERENCES public.m_role(role_id);


--
-- Name: app_user fk_app_user_stakeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_stakeholder_id FOREIGN KEY (stakeholder_id) REFERENCES public.m_stakeholder(stakeholder_id);


--
-- Name: app_user fk_app_user_trainee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_trainee_id FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: app_user fk_app_user_trainer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_trainer_id FOREIGN KEY (trainer_id) REFERENCES public.trainer(trainer_id);


--
-- Name: app_user fk_app_user_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: attendance fk_attendance_enrollment_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT fk_attendance_enrollment_id FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: attendance fk_attendance_marked_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT fk_attendance_marked_by FOREIGN KEY (marked_by) REFERENCES public.app_user(user_id);


--
-- Name: attendance fk_attendance_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT fk_attendance_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: audit_log fk_audit_log_actor_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT fk_audit_log_actor_user_id FOREIGN KEY (actor_user_id) REFERENCES public.app_user(user_id);


--
-- Name: audit_log fk_audit_log_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT fk_audit_log_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: batch_day_activity fk_batch_day_activity_batch_day_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day_activity
    ADD CONSTRAINT fk_batch_day_activity_batch_day_id FOREIGN KEY (batch_day_id) REFERENCES public.batch_day(batch_day_id);


--
-- Name: batch_day_activity fk_batch_day_activity_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day_activity
    ADD CONSTRAINT fk_batch_day_activity_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: batch_day fk_batch_day_batch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_day
    ADD CONSTRAINT fk_batch_day_batch_id FOREIGN KEY (batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_enrollment fk_batch_enrollment_approved_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_approved_by FOREIGN KEY (approved_by) REFERENCES public.app_user(user_id);


--
-- Name: batch_enrollment fk_batch_enrollment_batch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_batch_id FOREIGN KEY (batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_enrollment fk_batch_enrollment_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: batch_enrollment fk_batch_enrollment_registration_link_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_registration_link_id FOREIGN KEY (registration_link_id) REFERENCES public.batch_registration_link(link_id);


--
-- Name: batch_enrollment fk_batch_enrollment_trainee_block_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_trainee_block_id FOREIGN KEY (trainee_block_id) REFERENCES public.m_block(block_id);


--
-- Name: batch_enrollment fk_batch_enrollment_trainee_cluster_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_trainee_cluster_id FOREIGN KEY (trainee_cluster_id) REFERENCES public.m_cluster(cluster_id);


--
-- Name: batch_enrollment fk_batch_enrollment_trainee_district_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_trainee_district_id FOREIGN KEY (trainee_district_id) REFERENCES public.m_district(district_id);


--
-- Name: batch_enrollment fk_batch_enrollment_trainee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_trainee_id FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: batch_enrollment fk_batch_enrollment_trainee_school_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_trainee_school_id FOREIGN KEY (trainee_school_id) REFERENCES public.m_school(school_id);


--
-- Name: batch_enrollment fk_batch_enrollment_trainee_state_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_trainee_state_id FOREIGN KEY (trainee_state_id) REFERENCES public.m_state(state_id);


--
-- Name: batch_enrollment fk_batch_enrollment_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_enrollment
    ADD CONSTRAINT fk_batch_enrollment_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: batch_registration_link fk_batch_registration_link_batch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT fk_batch_registration_link_batch_id FOREIGN KEY (batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: batch_registration_link fk_batch_registration_link_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT fk_batch_registration_link_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: batch_registration_link fk_batch_registration_link_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_registration_link
    ADD CONSTRAINT fk_batch_registration_link_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: bulk_upload_log fk_bulk_upload_log_batch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT fk_bulk_upload_log_batch_id FOREIGN KEY (batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: bulk_upload_log fk_bulk_upload_log_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT fk_bulk_upload_log_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: bulk_upload_log fk_bulk_upload_log_uploaded_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_upload_log
    ADD CONSTRAINT fk_bulk_upload_log_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES public.app_user(user_id);


--
-- Name: certificate_record fk_certificate_record_enrollment_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT fk_certificate_record_enrollment_id FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: certificate_record fk_certificate_record_issued_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT fk_certificate_record_issued_by FOREIGN KEY (issued_by) REFERENCES public.app_user(user_id);


--
-- Name: certificate_record fk_certificate_record_template_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_record
    ADD CONSTRAINT fk_certificate_record_template_id FOREIGN KEY (template_id) REFERENCES public.certificate_template(template_id);


--
-- Name: certificate_template fk_certificate_template_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT fk_certificate_template_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: certificate_template fk_certificate_template_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT fk_certificate_template_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: certificate_template fk_certificate_template_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate_template
    ADD CONSTRAINT fk_certificate_template_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: completion_review fk_completion_review_enrollment_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT fk_completion_review_enrollment_id FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: completion_review fk_completion_review_reviewed_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completion_review
    ADD CONSTRAINT fk_completion_review_reviewed_by FOREIGN KEY (reviewed_by) REFERENCES public.app_user(user_id);


--
-- Name: consent_record fk_consent_record_trainee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_record
    ADD CONSTRAINT fk_consent_record_trainee_id FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: data_subject_request fk_data_subject_request_handled_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_request
    ADD CONSTRAINT fk_data_subject_request_handled_by FOREIGN KEY (handled_by) REFERENCES public.app_user(user_id);


--
-- Name: data_subject_request fk_data_subject_request_trainee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_request
    ADD CONSTRAINT fk_data_subject_request_trainee_id FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: form_question fk_form_question_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT fk_form_question_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: form_question fk_form_question_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT fk_form_question_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: form_question fk_form_question_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT fk_form_question_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: form_submission fk_form_submission_enrollment_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submission
    ADD CONSTRAINT fk_form_submission_enrollment_id FOREIGN KEY (enrollment_id) REFERENCES public.batch_enrollment(enrollment_id);


--
-- Name: form_submission fk_form_submission_question_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submission
    ADD CONSTRAINT fk_form_submission_question_id FOREIGN KEY (question_id) REFERENCES public.form_question(question_id);


--
-- Name: learning_resource fk_learning_resource_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT fk_learning_resource_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: learning_resource fk_learning_resource_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT fk_learning_resource_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: learning_resource fk_learning_resource_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT fk_learning_resource_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: learning_resource fk_learning_resource_uploaded_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT fk_learning_resource_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES public.app_user(user_id);


--
-- Name: m_block fk_m_block_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT fk_m_block_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_block fk_m_block_district_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT fk_m_block_district_id FOREIGN KEY (district_id) REFERENCES public.m_district(district_id);


--
-- Name: m_block fk_m_block_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT fk_m_block_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_cluster fk_m_cluster_block_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT fk_m_cluster_block_id FOREIGN KEY (block_id) REFERENCES public.m_block(block_id);


--
-- Name: m_cluster fk_m_cluster_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT fk_m_cluster_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_cluster fk_m_cluster_district_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT fk_m_cluster_district_id FOREIGN KEY (district_id) REFERENCES public.m_district(district_id);


--
-- Name: m_cluster fk_m_cluster_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT fk_m_cluster_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_district fk_m_district_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT fk_m_district_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_district fk_m_district_state_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT fk_m_district_state_id FOREIGN KEY (state_id) REFERENCES public.m_state(state_id);


--
-- Name: m_district fk_m_district_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT fk_m_district_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_holiday fk_m_holiday_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT fk_m_holiday_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_holiday fk_m_holiday_district_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT fk_m_holiday_district_id FOREIGN KEY (district_id) REFERENCES public.m_district(district_id);


--
-- Name: m_holiday fk_m_holiday_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT fk_m_holiday_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: m_holiday fk_m_holiday_state_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT fk_m_holiday_state_id FOREIGN KEY (state_id) REFERENCES public.m_state(state_id);


--
-- Name: m_holiday fk_m_holiday_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT fk_m_holiday_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_module fk_m_module_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT fk_m_module_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_module fk_m_module_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT fk_m_module_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_pii_field fk_m_pii_field_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT fk_m_pii_field_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_pii_field fk_m_pii_field_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT fk_m_pii_field_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_role fk_m_role_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT fk_m_role_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_role fk_m_role_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT fk_m_role_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_school fk_m_school_block_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT fk_m_school_block_id FOREIGN KEY (block_id) REFERENCES public.m_block(block_id);


--
-- Name: m_school fk_m_school_cluster_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT fk_m_school_cluster_id FOREIGN KEY (cluster_id) REFERENCES public.m_cluster(cluster_id);


--
-- Name: m_school fk_m_school_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT fk_m_school_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_school fk_m_school_district_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT fk_m_school_district_id FOREIGN KEY (district_id) REFERENCES public.m_district(district_id);


--
-- Name: m_school fk_m_school_state_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT fk_m_school_state_id FOREIGN KEY (state_id) REFERENCES public.m_state(state_id);


--
-- Name: m_school fk_m_school_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT fk_m_school_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_stakeholder fk_m_stakeholder_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT fk_m_stakeholder_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_stakeholder fk_m_stakeholder_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT fk_m_stakeholder_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: m_state fk_m_state_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT fk_m_state_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: m_state fk_m_state_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT fk_m_state_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: pii_access_log fk_pii_access_log_pii_field_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pii_access_log
    ADD CONSTRAINT fk_pii_access_log_pii_field_id FOREIGN KEY (pii_field_id) REFERENCES public.m_pii_field(pii_field_id);


--
-- Name: pii_access_log fk_pii_access_log_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pii_access_log
    ADD CONSTRAINT fk_pii_access_log_user_id FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: plan_resource_day fk_plan_resource_day_link_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_day
    ADD CONSTRAINT fk_plan_resource_day_link_id FOREIGN KEY (link_id) REFERENCES public.plan_resource_link(link_id);


--
-- Name: plan_resource_link fk_plan_resource_link_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT fk_plan_resource_link_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: plan_resource_link fk_plan_resource_link_plan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT fk_plan_resource_link_plan_id FOREIGN KEY (plan_id) REFERENCES public.training_plan(plan_id);


--
-- Name: plan_resource_link fk_plan_resource_link_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT fk_plan_resource_link_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: plan_resource_link fk_plan_resource_link_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT fk_plan_resource_link_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: plan_resource_link fk_plan_resource_link_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT fk_plan_resource_link_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: profile_change_log fk_profile_change_log_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_change_log
    ADD CONSTRAINT fk_profile_change_log_user_id FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: project fk_project_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT fk_project_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: project fk_project_stakeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT fk_project_stakeholder_id FOREIGN KEY (stakeholder_id) REFERENCES public.m_stakeholder(stakeholder_id);


--
-- Name: project fk_project_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT fk_project_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: registration_otp fk_registration_otp_batch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_otp
    ADD CONSTRAINT fk_registration_otp_batch_id FOREIGN KEY (batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: resource_access_log fk_resource_access_log_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_access_log
    ADD CONSTRAINT fk_resource_access_log_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: resource_access_log fk_resource_access_log_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_access_log
    ADD CONSTRAINT fk_resource_access_log_user_id FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: resource_audience fk_resource_audience_batch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT fk_resource_audience_batch_id FOREIGN KEY (batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: resource_audience fk_resource_audience_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT fk_resource_audience_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: resource_audience fk_resource_audience_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT fk_resource_audience_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: resource_audience fk_resource_audience_trainee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT fk_resource_audience_trainee_id FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: resource_audience fk_resource_audience_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT fk_resource_audience_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: resource_progress fk_resource_progress_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_progress
    ADD CONSTRAINT fk_resource_progress_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: resource_progress fk_resource_progress_trainee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_progress
    ADD CONSTRAINT fk_resource_progress_trainee_id FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: role_creation_rule fk_role_creation_rule_creatable_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT fk_role_creation_rule_creatable_role_id FOREIGN KEY (creatable_role_id) REFERENCES public.m_role(role_id);


--
-- Name: role_creation_rule fk_role_creation_rule_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT fk_role_creation_rule_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: role_creation_rule fk_role_creation_rule_creator_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT fk_role_creation_rule_creator_role_id FOREIGN KEY (creator_role_id) REFERENCES public.m_role(role_id);


--
-- Name: role_creation_rule fk_role_creation_rule_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT fk_role_creation_rule_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: role_permission fk_role_permission_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT fk_role_permission_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: role_permission fk_role_permission_module_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT fk_role_permission_module_id FOREIGN KEY (module_id) REFERENCES public.m_module(module_id);


--
-- Name: role_permission fk_role_permission_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT fk_role_permission_role_id FOREIGN KEY (role_id) REFERENCES public.m_role(role_id);


--
-- Name: role_permission fk_role_permission_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT fk_role_permission_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: role_pii_permission fk_role_pii_permission_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT fk_role_pii_permission_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: role_pii_permission fk_role_pii_permission_pii_field_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT fk_role_pii_permission_pii_field_id FOREIGN KEY (pii_field_id) REFERENCES public.m_pii_field(pii_field_id);


--
-- Name: role_pii_permission fk_role_pii_permission_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT fk_role_pii_permission_role_id FOREIGN KEY (role_id) REFERENCES public.m_role(role_id);


--
-- Name: role_pii_permission fk_role_pii_permission_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT fk_role_pii_permission_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: system_setting fk_system_setting_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT fk_system_setting_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: system_setting fk_system_setting_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT fk_system_setting_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: system_setting fk_system_setting_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT fk_system_setting_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: trainee fk_trainee_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT fk_trainee_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: trainee fk_trainee_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT fk_trainee_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: trainer_availability fk_trainer_availability_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT fk_trainer_availability_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: trainer_availability fk_trainer_availability_trainer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT fk_trainer_availability_trainer_id FOREIGN KEY (trainer_id) REFERENCES public.trainer(trainer_id);


--
-- Name: trainer_availability fk_trainer_availability_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT fk_trainer_availability_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: trainer fk_trainer_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT fk_trainer_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: trainer fk_trainer_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT fk_trainer_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: training_batch fk_training_batch_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT fk_training_batch_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: training_batch fk_training_batch_plan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT fk_training_batch_plan_id FOREIGN KEY (plan_id) REFERENCES public.training_plan(plan_id);


--
-- Name: training_batch fk_training_batch_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT fk_training_batch_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: training_batch fk_training_batch_school_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT fk_training_batch_school_id FOREIGN KEY (school_id) REFERENCES public.m_school(school_id);


--
-- Name: training_batch fk_training_batch_trainer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT fk_training_batch_trainer_id FOREIGN KEY (trainer_id) REFERENCES public.trainer(trainer_id);


--
-- Name: training_batch fk_training_batch_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT fk_training_batch_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: training_plan_activity fk_training_plan_activity_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT fk_training_plan_activity_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: training_plan_activity fk_training_plan_activity_plan_day_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT fk_training_plan_activity_plan_day_id FOREIGN KEY (plan_day_id) REFERENCES public.training_plan_day(plan_day_id);


--
-- Name: training_plan_activity fk_training_plan_activity_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT fk_training_plan_activity_resource_id FOREIGN KEY (resource_id) REFERENCES public.learning_resource(resource_id);


--
-- Name: training_plan_activity fk_training_plan_activity_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT fk_training_plan_activity_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: training_plan fk_training_plan_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT fk_training_plan_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: training_plan_day fk_training_plan_day_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT fk_training_plan_day_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: training_plan_day fk_training_plan_day_plan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT fk_training_plan_day_plan_id FOREIGN KEY (plan_id) REFERENCES public.training_plan(plan_id);


--
-- Name: training_plan_day fk_training_plan_day_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT fk_training_plan_day_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: training_plan fk_training_plan_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT fk_training_plan_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: training_plan fk_training_plan_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT fk_training_plan_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: user_access_scope fk_user_access_scope_block_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_block_id FOREIGN KEY (block_id) REFERENCES public.m_block(block_id);


--
-- Name: user_access_scope fk_user_access_scope_cluster_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_cluster_id FOREIGN KEY (cluster_id) REFERENCES public.m_cluster(cluster_id);


--
-- Name: user_access_scope fk_user_access_scope_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: user_access_scope fk_user_access_scope_district_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_district_id FOREIGN KEY (district_id) REFERENCES public.m_district(district_id);


--
-- Name: user_access_scope fk_user_access_scope_project_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_project_id FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: user_access_scope fk_user_access_scope_school_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_school_id FOREIGN KEY (school_id) REFERENCES public.m_school(school_id);


--
-- Name: user_access_scope fk_user_access_scope_state_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_state_id FOREIGN KEY (state_id) REFERENCES public.m_state(state_id);


--
-- Name: user_access_scope fk_user_access_scope_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: user_access_scope fk_user_access_scope_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT fk_user_access_scope_user_id FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: user_activity_log fk_user_activity_log_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT fk_user_activity_log_user_id FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: user_pii_override fk_user_pii_override_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT fk_user_pii_override_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(user_id);


--
-- Name: user_pii_override fk_user_pii_override_pii_field_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT fk_user_pii_override_pii_field_id FOREIGN KEY (pii_field_id) REFERENCES public.m_pii_field(pii_field_id);


--
-- Name: user_pii_override fk_user_pii_override_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT fk_user_pii_override_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(user_id);


--
-- Name: user_pii_override fk_user_pii_override_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT fk_user_pii_override_user_id FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: form_question form_question_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT form_question_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: form_question form_question_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT form_question_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: form_question form_question_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_question
    ADD CONSTRAINT form_question_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: form_submission form_submission_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submission
    ADD CONSTRAINT form_submission_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: form_submission form_submission_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submission
    ADD CONSTRAINT form_submission_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: form_submission form_submission_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submission
    ADD CONSTRAINT form_submission_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: learning_resource learning_resource_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT learning_resource_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: learning_resource learning_resource_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT learning_resource_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: learning_resource learning_resource_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.learning_resource
    ADD CONSTRAINT learning_resource_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_block m_block_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT m_block_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_block m_block_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT m_block_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_block m_block_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_block
    ADD CONSTRAINT m_block_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_cluster m_cluster_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT m_cluster_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_cluster m_cluster_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT m_cluster_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_cluster m_cluster_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_cluster
    ADD CONSTRAINT m_cluster_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_district m_district_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT m_district_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_district m_district_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT m_district_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_district m_district_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_district
    ADD CONSTRAINT m_district_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_holiday m_holiday_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT m_holiday_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_holiday m_holiday_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT m_holiday_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_holiday m_holiday_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_holiday
    ADD CONSTRAINT m_holiday_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_module m_module_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT m_module_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_module m_module_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT m_module_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_module m_module_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_module
    ADD CONSTRAINT m_module_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_pii_field m_pii_field_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT m_pii_field_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_pii_field m_pii_field_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT m_pii_field_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_pii_field m_pii_field_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_pii_field
    ADD CONSTRAINT m_pii_field_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_role m_role_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT m_role_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_role m_role_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT m_role_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_role m_role_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_role
    ADD CONSTRAINT m_role_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_school m_school_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT m_school_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_school m_school_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT m_school_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_school m_school_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_school
    ADD CONSTRAINT m_school_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_stakeholder m_stakeholder_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT m_stakeholder_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_stakeholder m_stakeholder_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT m_stakeholder_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_stakeholder m_stakeholder_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_stakeholder
    ADD CONSTRAINT m_stakeholder_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: m_state m_state_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT m_state_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: m_state m_state_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT m_state_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: m_state m_state_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.m_state
    ADD CONSTRAINT m_state_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: odoo_project_catalog odoo_project_catalog_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odoo_project_catalog
    ADD CONSTRAINT odoo_project_catalog_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: odoo_project_catalog odoo_project_catalog_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odoo_project_catalog
    ADD CONSTRAINT odoo_project_catalog_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: odoo_project_catalog odoo_project_catalog_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.odoo_project_catalog
    ADD CONSTRAINT odoo_project_catalog_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: pii_access_log pii_access_log_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pii_access_log
    ADD CONSTRAINT pii_access_log_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: pii_access_log pii_access_log_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pii_access_log
    ADD CONSTRAINT pii_access_log_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: pii_access_log pii_access_log_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pii_access_log
    ADD CONSTRAINT pii_access_log_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: plan_resource_day plan_resource_day_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_day
    ADD CONSTRAINT plan_resource_day_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: plan_resource_day plan_resource_day_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_day
    ADD CONSTRAINT plan_resource_day_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: plan_resource_day plan_resource_day_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_day
    ADD CONSTRAINT plan_resource_day_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: plan_resource_link plan_resource_link_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT plan_resource_link_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: plan_resource_link plan_resource_link_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT plan_resource_link_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: plan_resource_link plan_resource_link_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resource_link
    ADD CONSTRAINT plan_resource_link_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: portal_otp_challenge portal_otp_challenge_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_otp_challenge
    ADD CONSTRAINT portal_otp_challenge_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: portal_otp_challenge portal_otp_challenge_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_otp_challenge
    ADD CONSTRAINT portal_otp_challenge_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: portal_otp_challenge portal_otp_challenge_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_otp_challenge
    ADD CONSTRAINT portal_otp_challenge_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: portal_otp_challenge portal_otp_challenge_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_otp_challenge
    ADD CONSTRAINT portal_otp_challenge_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_user(user_id);


--
-- Name: portal_recovery_request portal_recovery_request_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_recovery_request
    ADD CONSTRAINT portal_recovery_request_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: portal_recovery_request portal_recovery_request_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_recovery_request
    ADD CONSTRAINT portal_recovery_request_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: portal_recovery_request portal_recovery_request_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_recovery_request
    ADD CONSTRAINT portal_recovery_request_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: portal_recovery_request portal_recovery_request_trainee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_recovery_request
    ADD CONSTRAINT portal_recovery_request_trainee_id_fkey FOREIGN KEY (trainee_id) REFERENCES public.trainee(trainee_id);


--
-- Name: portal_setting portal_setting_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_setting
    ADD CONSTRAINT portal_setting_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: portal_setting portal_setting_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_setting
    ADD CONSTRAINT portal_setting_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: portal_setting portal_setting_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_setting
    ADD CONSTRAINT portal_setting_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: profile_change_log profile_change_log_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_change_log
    ADD CONSTRAINT profile_change_log_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: profile_change_log profile_change_log_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_change_log
    ADD CONSTRAINT profile_change_log_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: profile_change_log profile_change_log_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_change_log
    ADD CONSTRAINT profile_change_log_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: project_phase project_phase_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase
    ADD CONSTRAINT project_phase_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: project_phase project_phase_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase
    ADD CONSTRAINT project_phase_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: project_phase project_phase_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase
    ADD CONSTRAINT project_phase_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: project_phase project_phase_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase
    ADD CONSTRAINT project_phase_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: project_plan_association project_plan_association_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.training_plan(plan_id);


--
-- Name: project_plan_association project_plan_association_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: project_plan_association project_plan_association_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: project_plan_association project_plan_association_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: project_plan_association project_plan_association_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_plan_association
    ADD CONSTRAINT project_plan_association_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: project project_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: project project_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: project project_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: registration_otp registration_otp_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_otp
    ADD CONSTRAINT registration_otp_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: registration_otp registration_otp_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_otp
    ADD CONSTRAINT registration_otp_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: registration_otp registration_otp_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_otp
    ADD CONSTRAINT registration_otp_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: resource_access_log resource_access_log_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_access_log
    ADD CONSTRAINT resource_access_log_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: resource_access_log resource_access_log_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_access_log
    ADD CONSTRAINT resource_access_log_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: resource_access_log resource_access_log_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_access_log
    ADD CONSTRAINT resource_access_log_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: resource_audience resource_audience_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT resource_audience_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: resource_audience resource_audience_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT resource_audience_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: resource_audience resource_audience_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_audience
    ADD CONSTRAINT resource_audience_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: resource_progress resource_progress_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_progress
    ADD CONSTRAINT resource_progress_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: resource_progress resource_progress_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_progress
    ADD CONSTRAINT resource_progress_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: resource_progress resource_progress_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_progress
    ADD CONSTRAINT resource_progress_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: role_creation_rule role_creation_rule_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT role_creation_rule_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: role_creation_rule role_creation_rule_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT role_creation_rule_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: role_creation_rule role_creation_rule_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_creation_rule
    ADD CONSTRAINT role_creation_rule_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: role_permission role_permission_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: role_permission role_permission_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: role_permission role_permission_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: role_pii_permission role_pii_permission_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT role_pii_permission_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: role_pii_permission role_pii_permission_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT role_pii_permission_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: role_pii_permission role_pii_permission_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_pii_permission
    ADD CONSTRAINT role_pii_permission_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: school_eligibility school_eligibility_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_eligibility
    ADD CONSTRAINT school_eligibility_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: school_eligibility school_eligibility_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_eligibility
    ADD CONSTRAINT school_eligibility_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: school_eligibility school_eligibility_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_eligibility
    ADD CONSTRAINT school_eligibility_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: school_eligibility school_eligibility_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_eligibility
    ADD CONSTRAINT school_eligibility_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(project_id);


--
-- Name: school_eligibility school_eligibility_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_eligibility
    ADD CONSTRAINT school_eligibility_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.m_school(school_id);


--
-- Name: system_setting system_setting_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT system_setting_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: system_setting system_setting_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT system_setting_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: system_setting system_setting_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT system_setting_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: teacher_auth_tokens teacher_auth_tokens_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_auth_tokens
    ADD CONSTRAINT teacher_auth_tokens_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teachers(id) ON DELETE CASCADE;


--
-- Name: trainee trainee_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT trainee_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: trainee trainee_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT trainee_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: trainee trainee_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainee
    ADD CONSTRAINT trainee_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: trainer_availability trainer_availability_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT trainer_availability_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: trainer_availability trainer_availability_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT trainer_availability_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: trainer_availability trainer_availability_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_availability
    ADD CONSTRAINT trainer_availability_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: trainer trainer_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT trainer_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: trainer trainer_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT trainer_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: trainer trainer_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer
    ADD CONSTRAINT trainer_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: training_batch training_batch_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT training_batch_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: training_batch training_batch_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT training_batch_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: training_batch training_batch_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_batch
    ADD CONSTRAINT training_batch_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: training_plan_activity training_plan_activity_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT training_plan_activity_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: training_plan_activity training_plan_activity_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT training_plan_activity_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: training_plan_activity training_plan_activity_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_activity
    ADD CONSTRAINT training_plan_activity_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: training_plan_day training_plan_day_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT training_plan_day_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: training_plan_day training_plan_day_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT training_plan_day_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: training_plan_day training_plan_day_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan_day
    ADD CONSTRAINT training_plan_day_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: training_plan training_plan_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT training_plan_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: training_plan training_plan_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT training_plan_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: training_plan training_plan_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_plan
    ADD CONSTRAINT training_plan_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: user_access_scope user_access_scope_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT user_access_scope_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: user_access_scope user_access_scope_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT user_access_scope_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: user_access_scope user_access_scope_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_scope
    ADD CONSTRAINT user_access_scope_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: user_activity_log user_activity_log_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: user_activity_log user_activity_log_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: user_activity_log user_activity_log_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- Name: user_pii_override user_pii_override_portal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT user_pii_override_portal_batch_id_fkey FOREIGN KEY (portal_batch_id) REFERENCES public.training_batch(batch_id);


--
-- Name: user_pii_override user_pii_override_portal_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT user_pii_override_portal_owner_user_id_fkey FOREIGN KEY (portal_owner_user_id) REFERENCES public.app_user(user_id);


--
-- Name: user_pii_override user_pii_override_portal_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_pii_override
    ADD CONSTRAINT user_pii_override_portal_project_id_fkey FOREIGN KEY (portal_project_id) REFERENCES public.project(project_id);


--
-- PostgreSQL database dump complete
--

\unrestrict aqGS4kXTRgu6izbZdatioKkpqj4YxMEV4jjEVsD54tbXRxXcOtFj6aBLIC60Cwl

